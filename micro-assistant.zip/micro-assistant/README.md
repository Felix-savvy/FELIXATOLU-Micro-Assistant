# Micro Assistant (Milestone 1: wake word)

Say "Jarvis" -> phone vibrates. Runs as a foreground service.

1. Get a free AccessKey at console.picovoice.ai
2. Push this folder to a GitHub repo (branch: main)
3. GitHub builds the APK -> Releases page -> download app-debug.apk -> install
4. Open app, paste AccessKey, tap Start listening
