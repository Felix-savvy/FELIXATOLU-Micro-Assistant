plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.felix.microassistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.felix.microassistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 13
        versionName = "1.1"
    }

    // Fixed debug key so every GitHub build is signed the same way.
    // This lets new versions install OVER the old one (keeps the speech model).
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Vosk: offline speech recognition (no account, no key)
    implementation("com.alphacephei:vosk-android:0.3.47")
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("androidx.core:core-ktx:1.12.0")
}
