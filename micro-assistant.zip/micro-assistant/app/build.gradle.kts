plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.felix.microassistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.felix.microassistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Wake word detection (Picovoice Porcupine)
    implementation("ai.picovoice:porcupine-android:3.0.2")
    implementation("androidx.core:core-ktx:1.12.0")
}
