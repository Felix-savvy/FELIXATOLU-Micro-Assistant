package com.felix.microassistant

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

class HomeScreen(act: MainActivity) : Screen(act) {

    private lateinit var orb: OrbView
    private lateinit var title: TextView
    private lateinit var sub: TextView
    private lateinit var heardTv: TextView
    private lateinit var replyTv: TextView
    private lateinit var pillDot: View
    private lateinit var pillText: TextView
    private lateinit var hService: HealthItem
    private lateinit var hModel: HealthItem
    private lateinit var hVoice: HealthItem

    override val view: View by lazy { build() }

    private fun build(): View {
        val ctx: Context = act
        val pal = Theme.c

        val col = ctx.vbox()
        col.setPadding(ctx.dp(20), ctx.dp(16), ctx.dp(20), ctx.dp(24))

        // ---- Header: logo, name, service pill ----
        val header = ctx.hbox()
        header.addView(LogoView(ctx, true), LinearLayout.LayoutParams(ctx.dp(40), ctx.dp(40)))
        val names = ctx.vbox()
        names.addView(ctx.label("FexAi", 19f, pal.text, 2))
        names.addView(ctx.label("Assistant", 11f, pal.text2, 0))
        header.addView(names, ctx.lpd(w = WRAP, l = 10))
        header.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))

        val pill = ctx.hbox()
        pill.background = ctx.shape(pal.surface, 16f, pal.border, 1)
        pill.setPadding(ctx.dp(10), ctx.dp(6), ctx.dp(12), ctx.dp(6))
        pillDot = ctx.dot(pal.text2)
        val pdLp = LinearLayout.LayoutParams(ctx.dp(8), ctx.dp(8))
        pdLp.rightMargin = ctx.dp(7)
        pill.addView(pillDot, pdLp)
        pillText = ctx.label("Service off", 12f, pal.text, 1)
        pill.addView(pillText)
        header.addView(pill, ctx.lpd(w = WRAP))
        col.addView(header, ctx.lpd())

        // ---- Status text ----
        title = ctx.label("Assistant is off", 22f, pal.text, 1)
        title.gravity = Gravity.CENTER
        col.addView(title, ctx.lpd(t = 28))
        sub = ctx.label("", 14f, pal.text2, 0)
        sub.gravity = Gravity.CENTER
        col.addView(sub, ctx.lpd(t = 6))

        // ---- Mic orb ----
        orb = OrbView(ctx)
        orb.isClickable = true
        orb.setOnClickListener { act.manualMic() }
        val orbLp = ctx.lpd(w = ctx.dp(224), h = ctx.dp(224), t = 22, b = 22)
        orbLp.gravity = Gravity.CENTER_HORIZONTAL
        col.addView(orb, orbLp)

        // ---- Conversation card ----
        val convo = ctx.card(18)
        convo.addView(ctx.label("LAST HEARD", 11f, pal.text2, 1).also { it.letterSpacing = 0.1f })
        heardTv = ctx.label("-", 18f, pal.text, 1)
        convo.addView(heardTv, ctx.lpd(t = 4))
        convo.addView(ctx.divider(), ctx.lpd(h = ctx.dp(1), t = 14, b = 14))
        convo.addView(ctx.label("REPLY", 11f, pal.text2, 1).also { it.letterSpacing = 0.1f })
        replyTv = ctx.label("Say \"${WakeWordService.WAKE_WORD}\", or tap the mic.", 15f, pal.text, 0)
        convo.addView(replyTv, ctx.lpd(t = 4))
        col.addView(convo, ctx.lpd())

        // ---- Quick commands ----
        col.addView(ctx.label("Quick commands", 14f, pal.text, 2), ctx.lpd(t = 22, b = 10))
        val quick = ctx.hbox()
        quick.addView(chip(G.TORCH, "Torch") { act.quickTorch() }, ctx.lpd(w = 0, h = ctx.dp(84), r = 4, weight = 1f))
        quick.addView(chip(G.CAMERA, "Camera") { act.runQuick(Cmd.OPEN_CAMERA, "Open camera") }, ctx.lpd(w = 0, h = ctx.dp(84), l = 4, r = 4, weight = 1f))
        quick.addView(chip(G.CHAT, "WhatsApp") { act.runQuick(Cmd.OPEN_WHATSAPP, "Open WhatsApp") }, ctx.lpd(w = 0, h = ctx.dp(84), l = 4, r = 4, weight = 1f))
        quick.addView(chip(G.CLOCK, "Time") { act.runQuick(Cmd.TELL_TIME, "Tell time") }, ctx.lpd(w = 0, h = ctx.dp(84), l = 4, weight = 1f))
        col.addView(quick, ctx.lpd())

        // ---- System health ----
        col.addView(ctx.label("System", 14f, pal.text, 2), ctx.lpd(t = 22, b = 10))
        hService = HealthItem(ctx, "Service")
        hModel = HealthItem(ctx, "Speech model")
        hVoice = HealthItem(ctx, "Voice engine")
        val health = ctx.hbox()
        health.addView(hService.root, ctx.lpd(w = 0, r = 4, weight = 1f))
        health.addView(hModel.root, ctx.lpd(w = 0, l = 4, r = 4, weight = 1f))
        health.addView(hVoice.root, ctx.lpd(w = 0, l = 4, weight = 1f))
        col.addView(health, ctx.lpd())

        val scroll = ScrollView(ctx)
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(col)
        return scroll
    }

    private fun chip(g: G, name: String, onClick: () -> Unit): View {
        val ctx: Context = act
        val pal = Theme.c
        val box = ctx.vbox()
        box.gravity = Gravity.CENTER
        box.background = ctx.pressable(pal.surface, 16f, pal.border, 1)
        box.isClickable = true
        box.setOnClickListener { onClick() }
        box.addView(GlyphView(ctx, g, pal.accent), LinearLayout.LayoutParams(ctx.dp(26), ctx.dp(26)))
        box.addView(ctx.label(name, 12f, pal.text, 1), ctx.lpd(w = WRAP, t = 8))
        return box
    }

    override fun refresh() {
        val ctx: Context = act
        val pal = Theme.c
        val s = AssistantBus.state
        val detail = AssistantBus.detail

        val texts: Pair<String, String> = when (s) {
            AState.STOPPED -> Pair(
                "Assistant is off",
                if (detail.startsWith("Error")) detail else "Tap the mic to start"
            )
            AState.LOADING -> Pair("Getting ready...", detail)
            AState.WAITING -> Pair("Waiting for wake word", "Say \"${WakeWordService.WAKE_WORD}\"")
            AState.LISTENING -> Pair("Listening...", "Say your command now")
            AState.PROCESSING -> Pair("Processing...", "")
            AState.EXECUTING -> Pair("Executing...", detail)
            AState.SUCCESS -> Pair("Done", "")
            AState.ERROR -> Pair("Didn't catch that", "Try again")
        }
        title.text = texts.first
        sub.text = texts.second
        sub.setTextColor(if (s == AState.STOPPED && detail.startsWith("Error")) pal.error else pal.text2)

        orb.applyMode(
            when (s) {
                AState.LISTENING -> 1
                AState.LOADING, AState.PROCESSING, AState.EXECUTING -> 2
                AState.ERROR -> 3
                else -> 0
            }
        )

        heardTv.text = if (AssistantBus.heard.isEmpty()) "-" else "\"${AssistantBus.heard}\""
        val reply = AssistantBus.reply
        if (reply.isNotEmpty()) replyTv.text = reply
        replyTv.setTextColor(
            when (s) {
                AState.SUCCESS -> pal.success
                AState.ERROR -> pal.error
                else -> pal.text
            }
        )

        // Header pill + health row
        val running = AssistantBus.serviceRunning
        (pillDot.background as android.graphics.drawable.GradientDrawable)
            .setColor(if (running) pal.accent else pal.text2)
        pillText.text = if (running) "Service active" else "Service off"

        hService.set(if (running) "Running" else "Stopped", if (running) pal.success else pal.text2)
        val modelReady = File(ctx.filesDir, "model.ok").exists()
        hModel.set(
            if (modelReady) "Loaded" else if (s == AState.LOADING) "Downloading" else "Not downloaded",
            if (modelReady) pal.success else pal.warning
        )
        hVoice.set(
            if (running) "Vosk, offline" else "Idle",
            if (running) pal.success else pal.text2
        )
    }
}
