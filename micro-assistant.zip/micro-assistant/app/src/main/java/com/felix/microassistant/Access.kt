package com.felix.microassistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService

/**
 * Accessibility service: lets the assistant press Back / Home / Recents, open the
 * notification shade, take a screenshot and lock the screen. It does nothing else
 * and does not read the screen.
 */
class FexAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile var instance: FexAccessibilityService? = null
    }
}

/** Notification access: only used to clear all notifications on command. */
class FexNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
    }

    override fun onListenerDisconnected() {
        instance = null
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile var instance: FexNotificationListener? = null
    }
}

/** Is a special access switched on in Android Settings? */
object Access {
    fun accessibilityOn(ctx: Context): Boolean {
        if (FexAccessibilityService.instance != null) return true
        val list = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        return list?.contains(ctx.packageName + "/") == true
    }

    fun notificationsOn(ctx: Context): Boolean {
        if (FexNotificationListener.instance != null) return true
        val list = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")
        return list?.contains(ctx.packageName + "/") == true
    }
}
