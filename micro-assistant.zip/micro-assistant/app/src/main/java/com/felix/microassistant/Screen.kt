package com.felix.microassistant

import android.view.View

/**
 * Base for every tab. A screen only listens to AssistantBus while it is visible,
 * so hidden tabs cost nothing.
 */
abstract class Screen(protected val act: MainActivity) {

    abstract val view: View
    abstract fun refresh()

    private val listener: () -> Unit = { refresh() }
    private var registered = false

    open fun onShow() {
        if (!registered) {
            AssistantBus.addListener(listener)
            registered = true
        }
        refresh()
    }

    open fun onHide() {
        if (registered) {
            AssistantBus.removeListener(listener)
            registered = false
        }
    }
}
