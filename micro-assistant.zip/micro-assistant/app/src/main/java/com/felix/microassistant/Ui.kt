package com.felix.microassistant

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

fun withAlpha(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha shl 24)

/** A rounded rectangle, optionally with a border. Radius is in dp. */
fun Context.shape(fill: Int, radiusDp: Float, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.shape = GradientDrawable.RECTANGLE
    g.setColor(fill)
    g.cornerRadius = dpf(radiusDp)
    if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor)
    return g
}

/** Same as shape() but with a touch ripple, for anything tappable. */
fun Context.pressable(fill: Int, radiusDp: Float, strokeColor: Int = 0, strokeDp: Int = 0): Drawable {
    val base = shape(fill, radiusDp, strokeColor, strokeDp)
    val rippleColor = if (Theme.c.dark) 0x33FFFFFF else 0x22000000
    return RippleDrawable(ColorStateList.valueOf(rippleColor), base, null)
}

/** weight: 0 = regular, 1 = medium, 2 = bold */
fun Context.label(text: CharSequence, sp: Float, color: Int, weight: Int = 0): TextView {
    val t = TextView(this)
    t.text = text
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    t.setTextColor(color)
    t.typeface = when (weight) {
        2 -> Typeface.create("sans-serif", Typeface.BOLD)
        1 -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
        else -> Typeface.create("sans-serif", Typeface.NORMAL)
    }
    return t
}

/** LinearLayout params. Margins are in dp; w and h are pixels or MATCH/WRAP. */
fun Context.lpd(
    w: Int = MATCH, h: Int = WRAP,
    l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0,
    weight: Float = 0f
): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.setMargins(dp(l), dp(t), dp(r), dp(b))
    return p
}

fun Context.vbox(): LinearLayout {
    val v = LinearLayout(this)
    v.orientation = LinearLayout.VERTICAL
    return v
}

fun Context.hbox(): LinearLayout {
    val v = LinearLayout(this)
    v.orientation = LinearLayout.HORIZONTAL
    v.gravity = Gravity.CENTER_VERTICAL
    return v
}

fun Context.dot(color: Int): View {
    val v = View(this)
    val g = GradientDrawable()
    g.shape = GradientDrawable.OVAL
    g.setColor(color)
    v.background = g
    return v
}

fun Context.divider(): View {
    val v = View(this)
    v.setBackgroundColor(Theme.c.border)
    return v
}

/** A standard surface card container. */
fun Context.card(padDp: Int = 16): LinearLayout {
    val v = vbox()
    v.background = shape(Theme.c.surface, 18f, Theme.c.border, 1)
    v.setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp))
    return v
}

/** Small rounded tag, e.g. "No permission". */
fun Context.tag(text: String, fg: Int, bg: Int): TextView {
    val t = label(text, 11f, fg, 1)
    t.setPadding(dp(8), dp(3), dp(8), dp(3))
    t.background = shape(bg, 8f)
    return t
}

/** Filled (accent) or outlined button. */
fun Context.button(text: String, filled: Boolean, onClick: () -> Unit): TextView {
    val pal = Theme.c
    val t = label(text, 14f, if (filled) pal.onAccent else pal.accent, 2)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(18), dp(12), dp(18), dp(12))
    t.background = if (filled) pressable(pal.accent, 14f) else pressable(0x00000000, 14f, pal.accent, 1)
    t.isClickable = true
    t.setOnClickListener { onClick() }
    return t
}

/** Small status block used on the Home screen: name on top, dot + value below. */
class HealthItem(ctx: Context, name: String) {
    val dot: View = ctx.dot(Theme.c.text2)
    val value: TextView = ctx.label("-", 13f, Theme.c.text, 1)
    val root: LinearLayout = ctx.vbox()

    init {
        root.background = ctx.shape(Theme.c.surface, 14f, Theme.c.border, 1)
        root.setPadding(ctx.dp(12), ctx.dp(10), ctx.dp(12), ctx.dp(10))
        root.addView(ctx.label(name, 11f, Theme.c.text2, 0))
        val row = ctx.hbox()
        val dotLp = LinearLayout.LayoutParams(ctx.dp(8), ctx.dp(8))
        dotLp.rightMargin = ctx.dp(6)
        row.addView(dot, dotLp)
        row.addView(value)
        root.addView(row, ctx.lpd(t = 5))
    }

    fun set(text: String, color: Int) {
        value.text = text
        (dot.background as GradientDrawable).setColor(color)
    }
}
