package com.felix.microassistant

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Downloads the small Vosk English model once (about 40MB), then it works offline forever. */
object ModelDownloader {
    private const val MODEL_URL =
        "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    private const val FOLDER = "vosk-model-small-en-us-0.15"
    private const val DONE_MARK = "model.ok"

    @Synchronized
    fun ensureModel(ctx: Context, onStatus: (String) -> Unit): File {
        val target = File(ctx.filesDir, FOLDER)
        val mark = File(ctx.filesDir, DONE_MARK)
        if (mark.exists() && target.isDirectory) return target

        mark.delete()
        target.deleteRecursively()

        // filesDir, not cacheDir: the phone's cleaner can wipe the cache mid-download
        val zip = File(ctx.filesDir, "model-download.zip")
        zip.delete()
        onStatus("Downloading speech model (needs internet, one time only)...")
        val conn = URL(MODEL_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        conn.connect()
        if (conn.responseCode != 200) {
            throw IllegalStateException("Download failed (HTTP ${conn.responseCode})")
        }
        val total = conn.contentLength.toLong()
        var got = 0L
        var lastShown = 0L
        conn.inputStream.use { input ->
            FileOutputStream(zip).use { out ->
                val buf = ByteArray(32 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    got += n
                    if (got - lastShown > 1_000_000) {
                        lastShown = got
                        val mb = got / 1_000_000
                        val of = if (total > 0) " of ${total / 1_000_000}" else ""
                        onStatus("Downloading speech model: $mb$of MB")
                    }
                }
            }
        }

        onStatus("Unpacking speech model...")
        val base = ctx.filesDir.canonicalFile
        ZipInputStream(zip.inputStream().buffered()).use { zin ->
            while (true) {
                val entry = zin.nextEntry ?: break
                val outFile = File(base, entry.name).canonicalFile
                if (!outFile.path.startsWith(base.path + File.separator)) continue
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { zin.copyTo(it) }
                }
            }
        }
        zip.delete()

        if (!target.isDirectory) throw IllegalStateException("Model folder missing after unpacking")
        mark.writeText("ok")
        return target
    }
}
