package com.felix.microassistant

import android.app.AlertDialog
import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryScreen(act: MainActivity) : Screen(act) {

    private lateinit var listBox: LinearLayout
    private lateinit var clearBtn: GlyphView
    private val chips = ArrayList<TextView>()
    private val filterNames = listOf("All", "Voice", "Manual", "Failed")
    private var filter = 0

    override val view: View by lazy { build() }

    /** Consecutive identical entries are shown once, with a count. */
    private class Group(val e: HistoryStore.Entry, var count: Int)

    private fun build(): View {
        val ctx: Context = act
        val pal = Theme.c

        val col = ctx.vbox()
        col.setPadding(ctx.dp(20), ctx.dp(20), ctx.dp(20), ctx.dp(24))

        val head = ctx.hbox()
        head.addView(ctx.label("History", 26f, pal.text, 2), ctx.lpd(w = 0, weight = 1f))
        clearBtn = GlyphView(ctx, G.TRASH, pal.text2)
        clearBtn.isClickable = true
        clearBtn.contentDescription = "Clear history"
        clearBtn.setOnClickListener { confirmClear() }
        head.addView(clearBtn, LinearLayout.LayoutParams(ctx.dp(44), ctx.dp(44)))
        col.addView(head, ctx.lpd())

        val chipRow = ctx.hbox()
        for (i in filterNames.indices) {
            val chip = ctx.chipView(filterNames[i])
            ctx.styleChip(chip, i == filter)
            chip.setOnClickListener {
                filter = i
                for (k in chips.indices) ctx.styleChip(chips[k], k == filter)
                refresh()
            }
            chips.add(chip)
            chipRow.addView(chip, ctx.lpd(w = WRAP, r = 8))
        }
        col.addView(chipRow, ctx.lpd(t = 8, b = 4))

        listBox = ctx.vbox()
        col.addView(listBox, ctx.lpd())

        val scroll = ScrollView(ctx)
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(col)
        return scroll
    }

    private fun confirmClear() {
        AlertDialog.Builder(act)
            .setTitle("Clear history?")
            .setMessage("This removes all recorded commands from this phone.")
            .setPositiveButton("Clear") { _, _ -> HistoryStore.clear(act) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun dayKey(ts: Long): String =
        SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(ts))

    override fun refresh() {
        val ctx: Context = act
        val pal = Theme.c
        listBox.removeAllViews()
        val everything = HistoryStore.all(ctx)
        clearBtn.visibility = if (everything.isEmpty()) View.INVISIBLE else View.VISIBLE

        if (everything.isEmpty()) {
            emptyState("Nothing here yet", "Commands you run will show up here, with the time and whether they worked.")
            return
        }

        val items = everything.filter {
            when (filter) {
                1 -> it.source == "voice"
                2 -> it.source == "manual"
                3 -> !it.ok
                else -> true
            }
        }
        if (items.isEmpty()) {
            emptyState("No matches", "Nothing in this filter yet.")
            return
        }

        // Group consecutive duplicates
        val groups = ArrayList<Group>()
        for (e in items) {
            val last = groups.lastOrNull()
            if (last != null &&
                last.e.phrase == e.phrase && last.e.result == e.result &&
                last.e.ok == e.ok && last.e.source == e.source &&
                dayKey(last.e.ts) == dayKey(e.ts)
            ) {
                last.count++
            } else {
                groups.add(Group(e, 1))
            }
        }

        val todayKey = dayKey(System.currentTimeMillis())
        val yesterdayKey = dayKey(System.currentTimeMillis() - 86_400_000L)
        val dayFmt = SimpleDateFormat("EEE, d MMM", Locale.getDefault())
        val timeFmt = SimpleDateFormat("h:mm a", Locale.getDefault())
        var lastDay = ""

        for (g in groups) {
            val key = dayKey(g.e.ts)
            if (key != lastDay) {
                lastDay = key
                val name = when (key) {
                    todayKey -> "Today"
                    yesterdayKey -> "Yesterday"
                    else -> dayFmt.format(Date(g.e.ts))
                }
                listBox.addView(ctx.label(name, 13f, pal.text2, 1), ctx.lpd(t = 14, b = 8))
            }
            listBox.addView(row(g, timeFmt.format(Date(g.e.ts))), ctx.lpd(b = 6))
        }
    }

    private fun emptyState(title: String, body: String) {
        val ctx: Context = act
        val pal = Theme.c
        val empty = ctx.vbox()
        empty.gravity = Gravity.CENTER_HORIZONTAL
        empty.setPadding(ctx.dp(20), ctx.dp(70), ctx.dp(20), 0)
        empty.addView(GlyphView(ctx, G.CLOCK, pal.text2), LinearLayout.LayoutParams(ctx.dp(44), ctx.dp(44)))
        val t = ctx.label(title, 17f, pal.text, 1)
        t.gravity = Gravity.CENTER
        empty.addView(t, ctx.lpd(t = 14))
        val d = ctx.label(body, 14f, pal.text2, 0)
        d.gravity = Gravity.CENTER
        empty.addView(d, ctx.lpd(t = 6))
        listBox.addView(empty, ctx.lpd())
    }

    private fun row(g: Group, time: String): View {
        val ctx: Context = act
        val pal = Theme.c
        val e = g.e
        val statusColor = if (e.ok) pal.success else pal.error

        val card = ctx.hbox()
        card.background = ctx.shape(pal.surface, 14f, pal.border, 1)
        card.setPadding(ctx.dp(12), ctx.dp(10), ctx.dp(12), ctx.dp(10))

        val badge = LinearLayout(ctx)
        badge.gravity = Gravity.CENTER
        badge.background = ctx.shape(withAlpha(statusColor, 36), 16f)
        badge.addView(
            GlyphView(ctx, if (e.ok) G.CHECK else G.CROSS, statusColor),
            LinearLayout.LayoutParams(ctx.dp(16), ctx.dp(16))
        )
        card.addView(badge, LinearLayout.LayoutParams(ctx.dp(32), ctx.dp(32)))

        val text = ctx.vbox()
        text.addView(ctx.label(e.phrase, 15f, pal.text, 1))
        val resultText = if (g.count > 1) e.result + "  x" + g.count else e.result
        text.addView(ctx.label(resultText, 13f, if (e.ok) pal.text2 else pal.error, 0), ctx.lpd(t = 1))
        card.addView(text, ctx.lpd(w = 0, l = 12, r = 8, weight = 1f))

        val right = ctx.vbox()
        right.gravity = Gravity.END
        right.addView(ctx.label(time, 12f, pal.text2, 0), ctx.lpd(w = WRAP))
        val isVoice = e.source == "voice"
        right.addView(
            ctx.tag(
                if (isVoice) "Voice" else "Manual",
                if (isVoice) pal.accent else pal.text2,
                if (isVoice) withAlpha(pal.accent, 30) else pal.elevated
            ),
            ctx.lpd(w = WRAP, t = 4)
        )
        card.addView(right, ctx.lpd(w = WRAP))
        return card
    }
}
