package com.felix.microassistant

import android.app.AlertDialog
import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryScreen(act: MainActivity) : Screen(act) {

    private lateinit var listBox: LinearLayout
    private lateinit var clearBtn: GlyphView

    override val view: View by lazy { build() }

    private fun build(): View {
        val ctx: Context = act
        val pal = Theme.c

        val col = ctx.vbox()
        col.setPadding(ctx.dp(20), ctx.dp(20), ctx.dp(20), ctx.dp(24))

        val head = ctx.hbox()
        head.addView(ctx.label("History", 26f, pal.text, 2), ctx.lpd(w = 0, weight = 1f))
        clearBtn = GlyphView(ctx, G.TRASH, pal.text2)
        clearBtn.isClickable = true
        clearBtn.contentDescription = "Clear history"
        clearBtn.setOnClickListener { confirmClear() }
        head.addView(clearBtn, LinearLayout.LayoutParams(ctx.dp(44), ctx.dp(44)))
        col.addView(head, ctx.lpd())

        listBox = ctx.vbox()
        col.addView(listBox, ctx.lpd(t = 8))

        val scroll = ScrollView(ctx)
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(col)
        return scroll
    }

    private fun confirmClear() {
        AlertDialog.Builder(act)
            .setTitle("Clear history?")
            .setMessage("This removes all recorded commands from this phone.")
            .setPositiveButton("Clear") { _, _ -> HistoryStore.clear(act) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun dayKey(ts: Long): String =
        SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(ts))

    override fun refresh() {
        val ctx: Context = act
        val pal = Theme.c
        listBox.removeAllViews()
        val items = HistoryStore.all(ctx)
        clearBtn.visibility = if (items.isEmpty()) View.INVISIBLE else View.VISIBLE

        if (items.isEmpty()) {
            val empty = ctx.vbox()
            empty.gravity = Gravity.CENTER_HORIZONTAL
            empty.setPadding(ctx.dp(20), ctx.dp(80), ctx.dp(20), 0)
            empty.addView(GlyphView(ctx, G.CLOCK, pal.text2), LinearLayout.LayoutParams(ctx.dp(44), ctx.dp(44)))
            val t = ctx.label("Nothing here yet", 17f, pal.text, 1)
            t.gravity = Gravity.CENTER
            empty.addView(t, ctx.lpd(t = 14))
            val d = ctx.label("Commands you run will show up here, with the time and whether they worked.", 14f, pal.text2, 0)
            d.gravity = Gravity.CENTER
            empty.addView(d, ctx.lpd(t = 6))
            listBox.addView(empty, ctx.lpd())
            return
        }

        val todayKey = dayKey(System.currentTimeMillis())
        val yesterdayKey = dayKey(System.currentTimeMillis() - 86_400_000L)
        val dayFmt = SimpleDateFormat("EEE, d MMM", Locale.getDefault())
        val timeFmt = SimpleDateFormat("h:mm a", Locale.getDefault())
        var lastDay = ""

        for (e in items) {
            val key = dayKey(e.ts)
            if (key != lastDay) {
                lastDay = key
                val name = when (key) {
                    todayKey -> "Today"
                    yesterdayKey -> "Yesterday"
                    else -> dayFmt.format(Date(e.ts))
                }
                listBox.addView(ctx.label(name, 13f, pal.text2, 1), ctx.lpd(t = 16, b = 8))
            }
            listBox.addView(row(e, timeFmt.format(Date(e.ts))), ctx.lpd(b = 8))
        }
    }

    private fun row(e: HistoryStore.Entry, time: String): View {
        val ctx: Context = act
        val pal = Theme.c
        val statusColor = if (e.ok) pal.success else pal.error

        val card = ctx.hbox()
        card.background = ctx.shape(pal.surface, 16f, pal.border, 1)
        card.setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))

        val badge = LinearLayout(ctx)
        badge.gravity = Gravity.CENTER
        badge.background = ctx.shape(withAlpha(statusColor, 36), 18f)
        badge.addView(
            GlyphView(ctx, if (e.ok) G.CHECK else G.CROSS, statusColor),
            LinearLayout.LayoutParams(ctx.dp(18), ctx.dp(18))
        )
        card.addView(badge, LinearLayout.LayoutParams(ctx.dp(36), ctx.dp(36)))

        val text = ctx.vbox()
        text.addView(ctx.label(e.phrase, 15f, pal.text, 1))
        text.addView(ctx.label(e.result, 13f, if (e.ok) pal.text2 else pal.error, 0), ctx.lpd(t = 2))
        card.addView(text, ctx.lpd(w = 0, l = 12, r = 8, weight = 1f))

        card.addView(ctx.label(time, 12f, pal.text2, 0), ctx.lpd(w = WRAP))
        return card
    }
}
