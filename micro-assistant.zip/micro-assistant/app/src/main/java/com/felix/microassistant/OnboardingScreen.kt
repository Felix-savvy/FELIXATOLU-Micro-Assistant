package com.felix.microassistant

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout

/**
 * First-launch tour. Three short steps. It never starts the service by itself:
 * the last button asks for permissions and then starts it.
 */
class OnboardingScreen(private val act: MainActivity, private val onFinish: (Boolean) -> Unit) {

    private val root = FrameLayout(act)
    private var step = 0

    val view: View get() = root

    private val titles = listOf("Meet FexAi", "Works offline", "Two quick permissions")
    private val bodies = listOf(
        "Your voice. Your control.\nAn assistant that lives on your phone.",
        "Say \"${WakeWordService.WAKE_WORD}\", wait for the beep, then say a command like \"torch on\" or \"open camera\".\n\n" +
            "Speech is recognised on your phone. The first start downloads a 41 MB speech model once.",
        "Microphone, so FexAi can hear the wake word.\n\n" +
            "Notifications, so Android keeps the listening service running. " +
            "You can stop it any time from Settings."
    )

    init {
        root.setBackgroundColor(Theme.c.bg)
        root.isClickable = true
        render()
    }

    private fun render() {
        val ctx: Context = act
        val pal = Theme.c
        root.removeAllViews()

        val col = ctx.vbox()
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(ctx.dp(28), ctx.dp(20), ctx.dp(28), ctx.dp(28))

        // Skip
        val skipRow = ctx.hbox()
        skipRow.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
        if (step < 2) {
            val skip = ctx.label("Skip", 14f, pal.text2, 1)
            skip.setPadding(ctx.dp(12), ctx.dp(10), ctx.dp(12), ctx.dp(10))
            skip.isClickable = true
            skip.setOnClickListener { onFinish(false) }
            skipRow.addView(skip)
        }
        col.addView(skipRow, ctx.lpd(h = ctx.dp(44)))

        col.addView(View(ctx), LinearLayout.LayoutParams(1, 0, 1f))

        // Hero
        if (step == 0) {
            col.addView(LogoView(ctx, true), LinearLayout.LayoutParams(ctx.dp(112), ctx.dp(112)))
        } else {
            val circle = LinearLayout(ctx)
            circle.gravity = Gravity.CENTER
            circle.background = ctx.shape(pal.elevated, 56f, pal.border, 1)
            val g = if (step == 1) G.CHECK else G.MIC
            circle.addView(GlyphView(ctx, g, pal.accent), LinearLayout.LayoutParams(ctx.dp(48), ctx.dp(48)))
            col.addView(circle, LinearLayout.LayoutParams(ctx.dp(112), ctx.dp(112)))
        }

        val title = ctx.label(titles[step], 28f, pal.text, 2)
        title.gravity = Gravity.CENTER
        col.addView(title, ctx.lpd(t = 32))
        val body = ctx.label(bodies[step], 15f, pal.text2, 0)
        body.gravity = Gravity.CENTER
        body.setLineSpacing(0f, 1.15f)
        col.addView(body, ctx.lpd(t = 14))

        col.addView(View(ctx), LinearLayout.LayoutParams(1, 0, 1f))

        // Dots
        val dots = ctx.hbox()
        dots.gravity = Gravity.CENTER
        for (i in 0 until 3) {
            val d = ctx.dot(if (i == step) pal.accent else pal.border)
            val w = if (i == step) ctx.dp(22) else ctx.dp(8)
            val lp = LinearLayout.LayoutParams(w, ctx.dp(8))
            lp.setMargins(ctx.dp(4), 0, ctx.dp(4), 0)
            d.background = ctx.shape(if (i == step) pal.accent else pal.border, 4f)
            dots.addView(d, lp)
        }
        col.addView(dots, ctx.lpd(b = 22))

        val label = if (step < 2) "Next" else "Allow and start"
        val btn = ctx.button(label, true) {
            if (step < 2) {
                step++
                render()
            } else {
                onFinish(true)
            }
        }
        col.addView(btn, ctx.lpd(h = ctx.dp(54)))

        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
    }
}
