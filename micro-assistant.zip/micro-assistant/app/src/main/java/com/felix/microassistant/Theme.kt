package com.felix.microassistant

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color

/** One complete set of colours. Dark and light share the same structure. */
class Palette(
    val dark: Boolean,
    val bg: Int,
    val surface: Int,
    val elevated: Int,
    val border: Int,
    val accent: Int,
    val accentPressed: Int,
    val onAccent: Int,
    val text: Int,
    val text2: Int,
    val success: Int,
    val warning: Int,
    val error: Int
)

/** FexAi design system: "Signal / Electric". Dark first, light available. */
object Theme {
    const val DARK = 0
    const val LIGHT = 1
    const val SYSTEM = 2
    private const val KEY = "theme_mode"

    private fun p(hex: String): Int = Color.parseColor(hex)

    private val darkPalette = Palette(
        dark = true,
        bg = p("#080D12"),
        surface = p("#121B23"),
        elevated = p("#1A2731"),
        border = p("#24323D"),
        accent = p("#B8F34A"),
        accentPressed = p("#8FCB30"),
        onAccent = p("#10170B"),
        text = p("#F4F7F8"),
        text2 = p("#9BAAB2"),
        success = p("#55D69E"),
        warning = p("#F2B85B"),
        error = p("#FF6868")
    )

    private val lightPalette = Palette(
        dark = false,
        bg = p("#F5F8F2"),
        surface = p("#FFFFFF"),
        elevated = p("#EBF1E5"),
        border = p("#DCE4D5"),
        accent = p("#83B92D"),
        accentPressed = p("#6C9C22"),
        onAccent = p("#10170B"),
        text = p("#182019"),
        text2 = p("#5C685F"),
        success = p("#2E9E6E"),
        warning = p("#B57B12"),
        error = p("#D64545")
    )

    /** The palette currently in use. Read this when building any view. */
    var c: Palette = darkPalette
        private set

    fun mode(ctx: Context): Int =
        ctx.getSharedPreferences(WakeWordService.PREFS, Context.MODE_PRIVATE).getInt(KEY, DARK)

    fun setMode(ctx: Context, mode: Int) {
        ctx.getSharedPreferences(WakeWordService.PREFS, Context.MODE_PRIVATE)
            .edit().putInt(KEY, mode).apply()
    }

    fun apply(ctx: Context) {
        c = when (mode(ctx)) {
            LIGHT -> lightPalette
            SYSTEM -> {
                val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                    Configuration.UI_MODE_NIGHT_YES
                if (night) darkPalette else lightPalette
            }
            else -> darkPalette
        }
    }
}
