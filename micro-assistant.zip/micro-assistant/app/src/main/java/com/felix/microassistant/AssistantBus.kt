package com.felix.microassistant

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList

enum class AState { STOPPED, LOADING, WAITING, LISTENING, PROCESSING, EXECUTING, SUCCESS, ERROR }

/**
 * One shared place where the background service reports what it is doing.
 * The screens (and later the floating card) only read from here, so the UI
 * never touches the microphone or the voice engine.
 */
object AssistantBus {
    @Volatile var state: AState = AState.STOPPED
    @Volatile var detail: String = ""
    @Volatile var heard: String = ""
    @Volatile var reply: String = ""
    @Volatile var serviceRunning: Boolean = false
    /** While true the floating card stays hidden (used so screenshots do not include it). */
    @Volatile var suppressCard: Boolean = false

    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())

    fun addListener(l: () -> Unit) {
        listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }

    fun notifyChanged() {
        main.post {
            for (l in listeners) l()
        }
    }

    fun update(
        state: AState? = null,
        detail: String? = null,
        heard: String? = null,
        reply: String? = null
    ) {
        if (state != null) this.state = state
        if (detail != null) this.detail = detail
        if (heard != null) this.heard = heard
        if (reply != null) this.reply = reply
        notifyChanged()
    }

    /** After a result is shown for a moment, go back to the resting state. */
    fun settleLater(ms: Long = 2500L) {
        main.postDelayed({
            if (state == AState.SUCCESS || state == AState.ERROR) {
                state = if (serviceRunning) AState.WAITING else AState.STOPPED
                notifyChanged()
            }
        }, ms)
    }
}
