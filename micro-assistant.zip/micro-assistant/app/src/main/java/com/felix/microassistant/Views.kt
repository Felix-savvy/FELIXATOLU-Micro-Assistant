package com.felix.microassistant

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.animation.LinearInterpolator

/**
 * The FexAi mark: an "F" built from signal bars, with a voice dot on the middle bar.
 * Drawn on a 108 x 108 grid (same geometry as the launcher icon).
 */
class LogoView(ctx: Context, private val tile: Boolean) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    /** 0 = Signal F, 1 = Aperture, 2 = Voice F. Defaults to the user's choice. */
    var style: Int = AppPrefs.logo(ctx)
        set(v) {
            field = v
            invalidate()
        }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height) / 108f
        if (s <= 0f) return
        c.save()
        c.scale(s, s)
        if (tile) {
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor("#0B1218")
            rect.set(0f, 0f, 108f, 108f)
            c.drawRoundRect(rect, 26f, 26f, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f
            paint.color = Color.parseColor("#24323D")
            rect.set(1f, 1f, 107f, 107f)
            c.drawRoundRect(rect, 25f, 25f, paint)
        }
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#B8F34A")
        when (style) {
            1 -> {
                // Aperture: a ring with a solid centre
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 9f
                c.drawCircle(54f, 54f, 26f, paint)
                paint.style = Paint.Style.FILL
                c.drawCircle(54f, 54f, 9f, paint)
            }
            2 -> {
                // Voice F: a stem with three sound bars of falling height
                rect.set(34f, 30f, 44f, 78f)
                c.drawRoundRect(rect, 5f, 5f, paint)
                rect.set(52f, 30f, 62f, 66f)
                c.drawRoundRect(rect, 5f, 5f, paint)
                rect.set(70f, 30f, 80f, 54f)
                c.drawRoundRect(rect, 5f, 5f, paint)
                rect.set(52f, 72f, 62f, 78f)
                c.drawRoundRect(rect, 3f, 3f, paint)
            }
            else -> {
                rect.set(38f, 30f, 48f, 78f)
                c.drawRoundRect(rect, 5f, 5f, paint)
                rect.set(38f, 30f, 74f, 40f)
                c.drawRoundRect(rect, 5f, 5f, paint)
                rect.set(38f, 49f, 64f, 59f)
                c.drawRoundRect(rect, 5f, 5f, paint)
                c.drawCircle(72f, 54f, 5f, paint)
            }
        }
        c.restore()
    }
}

/**
 * The big microphone orb on Home.
 * mode: 0 idle, 1 listening, 2 working, 3 error.
 *
 * Animation rules (battery friendly):
 *  - listening / working: fast, expressive wave
 *  - idle: very soft slow pulse, ONLY while the Home screen is visible (breathe(true))
 *  - everything stops when the screen is hidden or the mode is error
 */
class OrbView(ctx: Context) : View(ctx) {

    var mode = 0
        private set

    private var breathing = false
    private var phase = 0f
    private var anim: ValueAnimator? = null

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG)
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val base = floatArrayOf(0.20f, 0.34f, 0.50f, 0.34f, 0.20f)

    init {
        val d = ctx.resources.displayMetrics.density
        ring.style = Paint.Style.STROKE
        ring.strokeWidth = 2f * d
        body.style = Paint.Style.FILL
        edge.style = Paint.Style.STROKE
        edge.strokeWidth = 2f * d
        bar.style = Paint.Style.FILL
        contentDescription = "Microphone"
    }

    fun applyMode(m: Int) {
        if (m == mode) return
        mode = m
        updateAnim()
        invalidate()
    }

    /** Call with true when Home is on screen, false when it is hidden. */
    fun breathe(on: Boolean) {
        if (on == breathing) return
        breathing = on
        updateAnim()
        invalidate()
    }

    private fun updateAnim() {
        val want = mode == 1 || mode == 2 || (breathing && mode == 0)
        if (!want) {
            stopAnim()
            return
        }
        val dur = if (mode == 0) 3200L else 1400L
        val cur = anim
        if (cur != null && cur.duration == dur) return
        stopAnim()
        startAnim(dur)
    }

    private fun startAnim(dur: Long) {
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = dur
        a.repeatCount = ValueAnimator.INFINITE
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
        anim = a
        a.start()
    }

    private fun stopAnim() {
        anim?.cancel()
        anim = null
        phase = 0f
    }

    override fun onDetachedFromWindow() {
        stopAnim()
        super.onDetachedFromWindow()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        updateAnim()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f
        val pal = Theme.c
        val active = mode == 1 || mode == 2
        val idle = mode == 0 && breathing
        val col = if (mode == 3) pal.error else pal.accent

        if (active || idle) {
            ring.color = col
            ring.alpha = ((if (active) 90f else 38f) * (1f - phase)).toInt()
            c.drawCircle(cx, cy, r * (0.74f + 0.26f * phase), ring)
        }

        body.color = pal.elevated
        c.drawCircle(cx, cy, r * 0.70f, body)
        edge.color = col
        edge.alpha = if (active) 255 else 150
        c.drawCircle(cx, cy, r * 0.70f, edge)

        val bw = r * 0.085f
        val gap = r * 0.075f
        val total = 5 * bw + 4 * gap
        var x = cx - total / 2f
        bar.color = col
        bar.alpha = if (active) 255 else 210
        for (i in 0 until 5) {
            var h = base[i] * r
            if (active) {
                val speed = if (mode == 1) 2.0 else 1.0
                val wave = Math.sin(2.0 * Math.PI * (phase * speed + i * 0.18)).toFloat()
                h *= (0.65f + 0.35f * wave)
            } else if (idle) {
                val wave = Math.sin(2.0 * Math.PI * (phase + i * 0.18)).toFloat()
                h *= (0.92f + 0.08f * wave)
            }
            rect.set(x, cy - h / 2f, x + bw, cy + h / 2f)
            c.drawRoundRect(rect, bw / 2f, bw / 2f, bar)
            x += bw + gap
        }
    }
}
