package com.felix.microassistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Remembers the last commands (newest first) so the History screen has something to show. */
object HistoryStore {

    /** source is "voice" (spoken) or "manual" (tapped in the app). */
    class Entry(
        val ts: Long,
        val phrase: String,
        val result: String,
        val ok: Boolean,
        val source: String
    )

    private const val KEY = "history"
    private const val MAX = 150

    @Synchronized
    fun add(ctx: Context, phrase: String, result: String, ok: Boolean, source: String = "voice") {
        val prefs = ctx.getSharedPreferences(WakeWordService.PREFS, Context.MODE_PRIVATE)
        val old = try {
            JSONArray(prefs.getString(KEY, "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
        val entry = JSONObject()
        entry.put("t", System.currentTimeMillis())
        entry.put("p", phrase)
        entry.put("r", result)
        entry.put("ok", ok)
        entry.put("s", source)

        val out = JSONArray()
        out.put(entry)
        val keep = minOf(old.length(), MAX - 1)
        for (i in 0 until keep) out.put(old.get(i))
        prefs.edit().putString(KEY, out.toString()).apply()
        AssistantBus.notifyChanged()
    }

    @Synchronized
    fun all(ctx: Context): List<Entry> {
        val prefs = ctx.getSharedPreferences(WakeWordService.PREFS, Context.MODE_PRIVATE)
        val arr = try {
            JSONArray(prefs.getString(KEY, "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
        val list = ArrayList<Entry>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            var phrase = o.optString("p")
            var source = o.optString("s", "")
            // Entries saved by the previous version had no source; "Tapped: x" meant manual.
            if (source.isEmpty()) {
                if (phrase.startsWith("Tapped: ")) {
                    source = "manual"
                    phrase = phrase.removePrefix("Tapped: ")
                } else {
                    source = "voice"
                }
            }
            list.add(Entry(o.optLong("t"), phrase, o.optString("r"), o.optBoolean("ok"), source))
        }
        return list
    }

    @Synchronized
    fun clear(ctx: Context) {
        ctx.getSharedPreferences(WakeWordService.PREFS, Context.MODE_PRIVATE)
            .edit().remove(KEY).apply()
        AssistantBus.notifyChanged()
    }
}
