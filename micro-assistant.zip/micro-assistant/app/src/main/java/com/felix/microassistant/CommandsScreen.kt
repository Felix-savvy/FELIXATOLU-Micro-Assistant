package com.felix.microassistant

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class CommandsScreen(act: MainActivity) : Screen(act) {

    private enum class Cat(val title: String) {
        PHONE("Phone controls"), APPS("Apps"), INFO("Information")
    }

    private class Item(val cmd: Cmd, val cat: Cat, val desc: String, val perm: String?)

    private val items = listOf(
        Item(Cmd.TORCH_ON, Cat.PHONE, "Turns the flashlight on", null),
        Item(Cmd.TORCH_OFF, Cat.PHONE, "Turns the flashlight off", null),
        Item(Cmd.VOLUME_UP, Cat.PHONE, "Raises the media volume", null),
        Item(Cmd.VOLUME_DOWN, Cat.PHONE, "Lowers the media volume", null),
        Item(Cmd.MUTE, Cat.PHONE, "Mutes media audio", null),
        Item(Cmd.OPEN_CAMERA, Cat.APPS, "Opens the camera", "Works best with full-screen prompts on"),
        Item(Cmd.OPEN_WHATSAPP, Cat.APPS, "Opens WhatsApp", "Works best with full-screen prompts on"),
        Item(Cmd.TELL_TIME, Cat.INFO, "Says the current time", null)
    )

    private val chipNames = listOf("All", "Phone", "Apps", "Info")
    private val chips = ArrayList<TextView>()
    private var filter = 0
    private lateinit var listBox: LinearLayout

    override val view: View by lazy { build() }

    override fun refresh() {
        // Static content. Nothing to update.
    }

    private fun build(): View {
        val ctx: Context = act
        val pal = Theme.c

        val col = ctx.vbox()
        col.setPadding(ctx.dp(20), ctx.dp(20), ctx.dp(20), ctx.dp(24))

        col.addView(ctx.label("Commands", 26f, pal.text, 2), ctx.lpd())
        col.addView(
            ctx.label(
                "Say \"${AppPrefs.wakeWord(ctx)}\", wait for the reply, then say one of these.",
                14f, pal.text2, 0
            ),
            ctx.lpd(t = 4, b = 12)
        )

        val chipRow = ctx.hbox()
        for (i in chipNames.indices) {
            val chip = ctx.chipView(chipNames[i])
            ctx.styleChip(chip, i == filter)
            chip.setOnClickListener {
                filter = i
                for (k in chips.indices) ctx.styleChip(chips[k], k == filter)
                renderList()
            }
            chips.add(chip)
            chipRow.addView(chip, ctx.lpd(w = WRAP, r = 8))
        }
        col.addView(chipRow, ctx.lpd(b = 6))

        listBox = ctx.vbox()
        col.addView(listBox, ctx.lpd())
        renderList()

        // One compact card instead of a stack of disabled rows
        val soon = ctx.card(16)
        soon.addView(ctx.label("Coming soon", 13f, pal.text2, 1))
        soon.addView(
            ctx.label(
                "My commands  ·  Intent recipes  ·  Back, home, screenshot  ·  Media controls",
                13f, pal.text2, 0
            ),
            ctx.lpd(t = 4)
        )
        col.addView(soon, ctx.lpd(t = 20))

        val scroll = ScrollView(ctx)
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(col)
        return scroll
    }

    private fun renderList() {
        val ctx: Context = act
        val pal = Theme.c
        listBox.removeAllViews()
        var lastCat: Cat? = null
        for (item in items) {
            val show = when (filter) {
                1 -> item.cat == Cat.PHONE
                2 -> item.cat == Cat.APPS
                3 -> item.cat == Cat.INFO
                else -> true
            }
            if (!show) continue
            if (filter == 0 && item.cat != lastCat) {
                lastCat = item.cat
                listBox.addView(ctx.label(item.cat.title, 13f, pal.text2, 1), ctx.lpd(t = 14, b = 8))
            }
            listBox.addView(row(item), ctx.lpd(b = 6, t = if (filter == 0) 0 else 6))
        }
    }

    private fun row(item: Item): View {
        val ctx: Context = act
        val pal = Theme.c
        val phrases = CommandRunner.PHRASES.filterValues { it == item.cmd }.keys.toList()
        val main = phrases.firstOrNull() ?: "?"

        val card = ctx.hbox()
        card.background = ctx.shape(pal.surface, 14f, pal.border, 1)
        card.setPadding(ctx.dp(14), ctx.dp(10), ctx.dp(10), ctx.dp(10))

        val text = ctx.vbox()
        text.addView(ctx.label("\"$main\"", 15f, pal.text, 2))
        text.addView(ctx.label(item.desc, 12f, pal.text2, 0), ctx.lpd(t = 1))
        if (phrases.size > 1) {
            text.addView(
                ctx.label("Also: " + phrases.drop(1).joinToString(", ") { "\"$it\"" }, 11f, pal.text2, 0),
                ctx.lpd(t = 2)
            )
        }
        if (item.perm != null) {
            text.addView(ctx.label(item.perm, 11f, pal.warning, 0), ctx.lpd(t = 2))
        }
        card.addView(text, ctx.lpd(w = 0, weight = 1f))

        val play = LinearLayout(ctx)
        play.gravity = Gravity.CENTER
        play.background = ctx.pressable(0x00000000, 20f, pal.accent, 1)
        play.isClickable = true
        play.contentDescription = "Try " + main
        play.setOnClickListener { act.runQuick(item.cmd, main) }
        play.addView(GlyphView(ctx, G.PLAY, pal.accent), LinearLayout.LayoutParams(ctx.dp(18), ctx.dp(18)))
        card.addView(play, ctx.lpd(w = ctx.dp(40), h = ctx.dp(40), l = 8))
        return card
    }
}
