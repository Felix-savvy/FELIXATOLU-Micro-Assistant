package com.felix.microassistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class CommandsScreen(act: MainActivity) : Screen(act) {

    private enum class Cat(val title: String) {
        PHONE("Phone controls"), MEDIA("Media"), APPS("Apps"), INFO("Information"), MINE("My commands")
    }

    private enum class Need { NONE, A11Y, NOTIF, CALLS }

    private class Item(val cmd: Cmd, val cat: Cat, val desc: String, val perm: String?, val need: Need = Need.NONE)

    private val items = listOf(
        Item(Cmd.TORCH_ON, Cat.PHONE, "Turns the flashlight on", null),
        Item(Cmd.TORCH_OFF, Cat.PHONE, "Turns the flashlight off", null),
        Item(Cmd.VOLUME_UP, Cat.PHONE, "Raises the media volume", null),
        Item(Cmd.VOLUME_DOWN, Cat.PHONE, "Lowers the media volume", null),
        Item(Cmd.MUTE, Cat.PHONE, "Mutes media audio", null),
        Item(Cmd.GO_BACK, Cat.PHONE, "Presses Back", null, Need.A11Y),
        Item(Cmd.GO_HOME, Cat.PHONE, "Goes to the home screen", null, Need.A11Y),
        Item(Cmd.RECENTS, Cat.PHONE, "Shows recent apps", null, Need.A11Y),
        Item(Cmd.SCREENSHOT, Cat.PHONE, "Takes a screenshot", null, Need.A11Y),
        Item(Cmd.SHOW_NOTIFICATIONS, Cat.PHONE, "Pulls down notifications", null, Need.A11Y),
        Item(Cmd.QUICK_SETTINGS, Cat.PHONE, "Opens quick settings", null, Need.A11Y),
        Item(Cmd.LOCK_SCREEN, Cat.PHONE, "Locks the screen", null, Need.A11Y),
        Item(Cmd.CLEAR_NOTIFICATIONS, Cat.PHONE, "Clears all notifications", null, Need.NOTIF),
        Item(Cmd.ANSWER_CALL, Cat.PHONE, "Answers an incoming call", null, Need.CALLS),
        Item(Cmd.END_CALL, Cat.PHONE, "Ends or declines a call", null, Need.CALLS),
        Item(Cmd.MEDIA_PLAY, Cat.MEDIA, "Plays the current music or video", null),
        Item(Cmd.MEDIA_PAUSE, Cat.MEDIA, "Pauses it", null),
        Item(Cmd.MEDIA_NEXT, Cat.MEDIA, "Skips to the next track", null),
        Item(Cmd.MEDIA_PREV, Cat.MEDIA, "Goes to the previous track", null),
        Item(Cmd.OPEN_CAMERA, Cat.APPS, "Opens the camera", "Works best with full-screen prompts on"),
        Item(Cmd.OPEN_WHATSAPP, Cat.APPS, "Opens WhatsApp", "Works best with full-screen prompts on"),
        Item(Cmd.TELL_TIME, Cat.INFO, "Says the current time", null)
    )

    private val chipNames = listOf("All", "Phone", "Media", "Apps", "Info", "Mine")
    private val chipCats = listOf(null, Cat.PHONE, Cat.MEDIA, Cat.APPS, Cat.INFO, Cat.MINE)
    private val chips = ArrayList<TextView>()
    private var filter = 0
    private lateinit var listBox: LinearLayout

    override val view: View by lazy { build() }

    override fun onShow() {
        super.onShow()
        if (this::listBox.isInitialized) renderList() // permission notes may have changed
    }

    override fun refresh() {
        // Static content. Nothing to update.
    }

    private fun build(): View {
        val ctx: Context = act
        val pal = Theme.c

        val col = ctx.vbox()
        col.setPadding(ctx.dp(20), ctx.dp(20), ctx.dp(20), ctx.dp(24))

        col.addView(ctx.label("Commands", 26f, pal.text, 2), ctx.lpd())
        col.addView(
            ctx.label(
                "Say \"${AppPrefs.wakeWord(ctx)}\", wait for the reply, then say one of these.",
                14f, pal.text2, 0
            ),
            ctx.lpd(t = 4, b = 12)
        )

        val chipRow = ctx.hbox()
        for (i in chipNames.indices) {
            val chip = ctx.chipView(chipNames[i])
            ctx.styleChip(chip, i == filter)
            chip.setOnClickListener {
                filter = i
                for (k in chips.indices) ctx.styleChip(chips[k], k == filter)
                renderList()
            }
            chips.add(chip)
            chipRow.addView(chip, ctx.lpd(w = WRAP, r = 8))
        }
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(chipRow)
        col.addView(hs, ctx.lpd(b = 6))

        listBox = ctx.vbox()
        col.addView(listBox, ctx.lpd())
        renderList()

        val mineCard = ctx.card(16)
        mineCard.addView(ctx.label("Make your own", 13f, pal.text2, 1))
        mineCard.addView(
            ctx.label("Add phrases that open apps or websites, call people, or say something back.", 13f, pal.text2, 0),
            ctx.lpd(t = 4)
        )
        mineCard.addView(ctx.button("Manage my commands", false) { act.goSettings(6) }, ctx.lpd(t = 12))
        col.addView(mineCard, ctx.lpd(t = 20))

        val scroll = ScrollView(ctx)
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(col)
        return scroll
    }

    private fun renderList() {
        val ctx: Context = act
        val pal = Theme.c
        listBox.removeAllViews()
        var lastCat: Cat? = null
        for (item in items) {
            val want = chipCats[filter]
            val show = want == null || item.cat == want
            if (!show) continue
            if (filter == 0 && item.cat != lastCat) {
                lastCat = item.cat
                listBox.addView(ctx.label(item.cat.title, 13f, pal.text2, 1), ctx.lpd(t = 14, b = 8))
            }
            listBox.addView(row(item), ctx.lpd(b = 6, t = if (filter == 0) 0 else 6))
        }

        val wantMine = chipCats[filter] == null || chipCats[filter] == Cat.MINE
        if (wantMine) {
            val mine = CustomStore.all(ctx)
            if (mine.isNotEmpty()) {
                if (filter == 0) listBox.addView(ctx.label("My commands", 13f, pal.text2, 1), ctx.lpd(t = 14, b = 8))
                for (c in mine) listBox.addView(customRow(c), ctx.lpd(b = 6, t = if (filter == 0) 0 else 6))
            } else if (filter != 0) {
                listBox.addView(
                    ctx.label("You haven't made any yet. Tap \"Manage my commands\" below.", 13f, pal.text2, 0),
                    ctx.lpd(t = 14)
                )
            }
        }
    }

    private fun customRow(c: CustomCmd): View {
        val ctx: Context = act
        val pal = Theme.c
        val card = ctx.hbox()
        card.background = ctx.shape(pal.surface, 14f, pal.border, 1)
        card.setPadding(ctx.dp(14), ctx.dp(10), ctx.dp(10), ctx.dp(10))
        val text = ctx.vbox()
        text.addView(ctx.label("\"" + c.phrase + "\"", 15f, pal.text, 2))
        text.addView(ctx.label(c.summary(), 12f, pal.text2, 0), ctx.lpd(t = 1))
        card.addView(text, ctx.lpd(w = 0, weight = 1f))
        val play = LinearLayout(ctx)
        play.gravity = Gravity.CENTER
        play.background = ctx.pressable(0x00000000, 20f, pal.accent, 1)
        play.isClickable = true
        play.contentDescription = "Try " + c.phrase
        play.setOnClickListener { act.runCustomQuick(c.action(), c.phrase) }
        play.addView(GlyphView(ctx, G.PLAY, pal.accent), LinearLayout.LayoutParams(ctx.dp(18), ctx.dp(18)))
        card.addView(play, ctx.lpd(w = ctx.dp(40), h = ctx.dp(40), l = 8))
        return card
    }

    private fun row(item: Item): View {
        val ctx: Context = act
        val pal = Theme.c
        val phrases = CommandRunner.PHRASES.filterValues { it == item.cmd }.keys.toList()
        val main = phrases.firstOrNull() ?: "?"

        val card = ctx.hbox()
        card.background = ctx.shape(pal.surface, 14f, pal.border, 1)
        card.setPadding(ctx.dp(14), ctx.dp(10), ctx.dp(10), ctx.dp(10))

        val text = ctx.vbox()
        text.addView(ctx.label("\"$main\"", 15f, pal.text, 2))
        text.addView(ctx.label(item.desc, 12f, pal.text2, 0), ctx.lpd(t = 1))
        if (phrases.size > 1) {
            text.addView(
                ctx.label("Also: " + phrases.drop(1).joinToString(", ") { "\"$it\"" }, 11f, pal.text2, 0),
                ctx.lpd(t = 2)
            )
        }
        val missing = when (item.need) {
            Need.A11Y -> if (Access.accessibilityOn(ctx)) null else "Needs accessibility access (Settings)"
            Need.NOTIF -> if (Access.notificationsOn(ctx)) null else "Needs notification access (Settings)"
            Need.CALLS -> if (ctx.checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED) null
            else "Needs phone permission (Settings > Calls & contacts)"
            Need.NONE -> null
        }
        if (missing != null) {
            text.addView(ctx.label(missing, 11f, pal.warning, 0), ctx.lpd(t = 2))
        }
        if (item.perm != null) {
            text.addView(ctx.label(item.perm, 11f, pal.warning, 0), ctx.lpd(t = 2))
        }
        card.addView(text, ctx.lpd(w = 0, weight = 1f))

        val play = LinearLayout(ctx)
        play.gravity = Gravity.CENTER
        play.background = ctx.pressable(0x00000000, 20f, pal.accent, 1)
        play.isClickable = true
        play.contentDescription = "Try " + main
        play.setOnClickListener { act.runQuick(item.cmd, main) }
        play.addView(GlyphView(ctx, G.PLAY, pal.accent), LinearLayout.LayoutParams(ctx.dp(18), ctx.dp(18)))
        card.addView(play, ctx.lpd(w = ctx.dp(40), h = ctx.dp(40), l = 8))
        return card
    }
}
