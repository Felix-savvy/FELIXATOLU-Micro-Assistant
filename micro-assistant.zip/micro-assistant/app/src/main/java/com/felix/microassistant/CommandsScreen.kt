package com.felix.microassistant

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView

class CommandsScreen(act: MainActivity) : Screen(act) {

    override val view: View by lazy { build() }

    override fun refresh() {
        // Static content. Nothing to update.
    }

    private class Item(val cmd: Cmd, val desc: String, val perm: String?)

    private fun build(): View {
        val ctx: Context = act
        val pal = Theme.c

        val col = ctx.vbox()
        col.setPadding(ctx.dp(20), ctx.dp(20), ctx.dp(20), ctx.dp(24))

        col.addView(ctx.label("Commands", 26f, pal.text, 2), ctx.lpd())
        col.addView(
            ctx.label(
                "Say \"${WakeWordService.WAKE_WORD}\", wait for the beep, then say one of these.",
                14f, pal.text2, 0
            ),
            ctx.lpd(t = 6, b = 6)
        )

        section(col, "Phone controls", listOf(
            Item(Cmd.TORCH_ON, "Turns the flashlight on.", null),
            Item(Cmd.TORCH_OFF, "Turns the flashlight off.", null),
            Item(Cmd.VOLUME_UP, "Raises the media volume.", null),
            Item(Cmd.VOLUME_DOWN, "Lowers the media volume.", null),
            Item(Cmd.MUTE, "Mutes media audio.", null)
        ))
        section(col, "Apps", listOf(
            Item(Cmd.OPEN_CAMERA, "Opens the camera.", "Full-screen notifications (optional)"),
            Item(Cmd.OPEN_WHATSAPP, "Opens WhatsApp.", "Full-screen notifications (optional)")
        ))
        section(col, "Information", listOf(
            Item(Cmd.TELL_TIME, "Says the current time out loud.", null)
        ))

        col.addView(ctx.label("Coming soon", 14f, pal.text2, 2), ctx.lpd(t = 24, b = 10))
        soon(col, "My commands", "Add your own phrases and pick what they do.")
        soon(col, "Intent recipes", "Advanced custom actions for any app.")
        soon(col, "System navigation", "Back, home, recents, screenshot, notifications.")

        val scroll = ScrollView(ctx)
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(col)
        return scroll
    }

    private fun section(col: LinearLayout, name: String, items: List<Item>) {
        val ctx: Context = act
        col.addView(ctx.label(name, 14f, Theme.c.text, 2), ctx.lpd(t = 22, b = 10))
        for (item in items) col.addView(row(item), ctx.lpd(b = 8))
    }

    private fun row(item: Item): View {
        val ctx: Context = act
        val pal = Theme.c
        val phrases = CommandRunner.PHRASES.filterValues { it == item.cmd }.keys.toList()
        val main = phrases.firstOrNull() ?: "?"

        val card = ctx.hbox()
        card.background = ctx.shape(pal.surface, 16f, pal.border, 1)
        card.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(12), ctx.dp(14))

        val text = ctx.vbox()
        text.addView(ctx.label("\"$main\"", 16f, pal.text, 2))
        if (phrases.size > 1) {
            text.addView(
                ctx.label("Also: " + phrases.drop(1).joinToString(", ") { "\"$it\"" }, 12f, pal.text2, 0),
                ctx.lpd(t = 2)
            )
        }
        text.addView(ctx.label(item.desc, 13f, pal.text2, 0), ctx.lpd(t = 4))
        val permText = item.perm ?: "No extra permission"
        val permColor = if (item.perm == null) pal.success else pal.warning
        text.addView(ctx.tag(permText, permColor, withAlpha(permColor, 36)), ctx.lpd(w = WRAP, t = 8))
        card.addView(text, ctx.lpd(w = 0, weight = 1f))

        val tryBtn = ctx.button("Try", false) { act.runQuick(item.cmd, main) }
        tryBtn.setPadding(ctx.dp(16), ctx.dp(9), ctx.dp(16), ctx.dp(9))
        card.addView(tryBtn, ctx.lpd(w = WRAP, l = 8))
        return card
    }

    private fun soon(col: LinearLayout, name: String, desc: String) {
        val ctx: Context = act
        val pal = Theme.c
        val card = ctx.hbox()
        card.background = ctx.shape(pal.surface, 16f, pal.border, 1)
        card.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(16), ctx.dp(14))
        card.alpha = 0.75f
        val text = ctx.vbox()
        text.addView(ctx.label(name, 15f, pal.text, 1))
        text.addView(ctx.label(desc, 12f, pal.text2, 0), ctx.lpd(t = 2))
        card.addView(text, ctx.lpd(w = 0, weight = 1f))
        val t = ctx.tag("Soon", pal.text2, pal.elevated)
        t.gravity = Gravity.CENTER
        card.addView(t, ctx.lpd(w = WRAP))
        col.addView(card, ctx.lpd(b = 8))
    }
}
