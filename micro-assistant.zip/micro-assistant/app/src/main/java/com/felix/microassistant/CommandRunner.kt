package com.felix.microassistant

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.telecom.TelecomManager
import android.provider.MediaStore
import android.view.KeyEvent
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Cmd {
    TORCH_ON, TORCH_OFF, VOLUME_UP, VOLUME_DOWN, MUTE,
    OPEN_CAMERA, OPEN_WHATSAPP, TELL_TIME,
    GO_BACK, GO_HOME, RECENTS, SCREENSHOT, SHOW_NOTIFICATIONS, QUICK_SETTINGS, LOCK_SCREEN,
    CLEAR_NOTIFICATIONS, ANSWER_CALL, END_CALL, MEDIA_PLAY, MEDIA_PAUSE, MEDIA_NEXT, MEDIA_PREV
}

/**
 * Turns a recognised command into a real phone action.
 * To add a command later: add it to Cmd, add phrase(s) to PHRASES, add a branch in run().
 */
class CommandRunner(
    private val ctx: Context,
    private val speak: (String) -> Unit
) {

    fun run(cmd: Cmd): String = try {
        when (cmd) {
            Cmd.TORCH_ON -> setTorch(true)
            Cmd.TORCH_OFF -> setTorch(false)
            Cmd.VOLUME_UP -> changeVolume(AudioManager.ADJUST_RAISE, "Volume up")
            Cmd.VOLUME_DOWN -> changeVolume(AudioManager.ADJUST_LOWER, "Volume down")
            Cmd.MUTE -> changeVolume(AudioManager.ADJUST_MUTE, "Muted")
            Cmd.OPEN_CAMERA -> launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), "Camera")
            Cmd.OPEN_WHATSAPP -> openWhatsApp()
            Cmd.TELL_TIME -> tellTime()
            Cmd.GO_BACK -> global(AccessibilityService.GLOBAL_ACTION_BACK, "Going back")
            Cmd.GO_HOME -> global(AccessibilityService.GLOBAL_ACTION_HOME, "Going home")
            Cmd.RECENTS -> global(AccessibilityService.GLOBAL_ACTION_RECENTS, "Recent apps")
            Cmd.SCREENSHOT -> global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "Taking screenshot")
            Cmd.SHOW_NOTIFICATIONS -> global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "Notifications")
            Cmd.QUICK_SETTINGS -> global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS, "Quick settings")
            Cmd.LOCK_SCREEN -> global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "Screen locked")
            Cmd.CLEAR_NOTIFICATIONS -> clearNotifications()
            Cmd.ANSWER_CALL -> answerCall()
            Cmd.END_CALL -> endCall()
            Cmd.MEDIA_PLAY -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY, "Playing")
            Cmd.MEDIA_PAUSE -> mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE, "Paused")
            Cmd.MEDIA_NEXT -> mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT, "Next song")
            Cmd.MEDIA_PREV -> mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS, "Previous song")
        }
    } catch (e: Exception) {
        "Failed: ${e.message ?: e.javaClass.simpleName}"
    }

    private fun setTorch(on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { camId ->
            val c = cm.getCameraCharacteristics(camId)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        } ?: return "No flashlight found on this phone"
        cm.setTorchMode(id, on)
        return if (on) "Torch on" else "Torch off"
    }

    private fun changeVolume(direction: Int, label: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val steps = if (direction == AudioManager.ADJUST_MUTE) 1 else 2
        repeat(steps) { i ->
            val flags = if (i == steps - 1) AudioManager.FLAG_SHOW_UI else 0
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, flags)
        }
        return label
    }

    private fun openWhatsApp(): String {
        val pm = ctx.packageManager
        val intent = pm.getLaunchIntentForPackage("com.whatsapp")
            ?: pm.getLaunchIntentForPackage("com.whatsapp.w4b")
            ?: return "WhatsApp is not installed"
        return launch(intent, "WhatsApp")
    }

    /** Runs a command the user made, or an automatic "open <app>" / "call <name>" one. */
    fun runCustom(a: CustomAction): String = try {
        when (a.type) {
            "app" -> openPackage(a.arg, a.label)
            "url" -> openUrl(a.arg, a.label)
            "call" -> call(a.arg, a.label)
            "say" -> {
                speak(a.arg)
                a.arg
            }
            else -> customIntent(a.arg)
        }
    } catch (e: Exception) {
        "Failed: ${e.message ?: e.javaClass.simpleName}"
    }

    private fun openPackage(pkg: String, label: String): String {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg)
            ?: return "$label is not installed"
        return launch(intent, label)
    }

    private fun openUrl(url: String, label: String): String {
        val fixed = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        return launch(Intent(Intent.ACTION_VIEW, Uri.parse(fixed)), label.ifEmpty { "website" })
    }

    private fun call(number: String, label: String): String {
        val who = label.ifEmpty { number }
        val granted = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val intent = Intent(
            if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL,
            Uri.parse("tel:" + Uri.encode(number))
        )
        val r = launch(intent, "call to $who")
        if (r.startsWith("Could not")) return r
        return if (granted) "Calling $who" else "Opening dialer for $who"
    }

    /** arg is "action", "data" and "package" on separate lines. */
    private fun customIntent(arg: String): String {
        val parts = arg.split("\n")
        val action = parts.getOrElse(0) { "" }.trim()
        if (action.isEmpty()) return "Failed: no action set"
        val intent = Intent(action)
        val data = parts.getOrElse(1) { "" }.trim()
        val pkg = parts.getOrElse(2) { "" }.trim()
        if (data.isNotEmpty()) intent.data = Uri.parse(data)
        if (pkg.isNotEmpty()) intent.setPackage(pkg)
        return launch(intent, "action")
    }

    private fun answerCall(): String {
        if (ctx.checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            return "Needs phone permission (Settings > Calls & contacts)"
        }
        val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        tm.acceptRingingCall()
        return "Answering"
    }

    private fun endCall(): String {
        if (ctx.checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            return "Needs phone permission (Settings > Calls & contacts)"
        }
        if (Build.VERSION.SDK_INT < 28) return "Failed: ending calls needs Android 9 or newer"
        val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        return if (tm.endCall()) "Call ended" else "Failed: no call to end"
    }

    private fun global(action: Int, label: String): String {
        val svc = FexAccessibilityService.instance
            ?: return "Needs accessibility access (Settings > Assistant & permissions)"
        return if (svc.performGlobalAction(action)) label else "Failed: Android refused \"$label\""
    }

    private fun clearNotifications(): String {
        val l = FexNotificationListener.instance
            ?: return "Needs notification access (Settings > Assistant & permissions)"
        l.cancelAllNotifications()
        return "Notifications cleared"
    }

    private fun mediaKey(code: Int, label: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return label
    }

    private fun tellTime(): String {
        val t = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        speak("It is $t")
        return "Time is $t"
    }

    /**
     * Android blocks apps from opening screens out of nowhere. We try directly, and also
     * post a "tap to open" notification (with a full-screen intent) as a backup.
     */
    private fun launch(intent: Intent, label: String): String {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(intent)
        } catch (e: Exception) {
            return "Could not open $label: ${e.message}"
        }
        postTapNotification(intent, label)
        return "Opening $label"
    }

    private fun postTapNotification(intent: Intent, label: String) {
        try {
            val pi = PendingIntent.getActivity(
                ctx, label.hashCode(), intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(ctx, LAUNCH_CHANNEL)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Tap to open $label")
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .setAutoCancel(true)
                .setTimeoutAfter(8000)
                .build()
            ctx.getSystemService(NotificationManager::class.java).notify(2, n)
        } catch (e: Exception) {
            // backup only, ignore
        }
    }

    companion object {
        const val LAUNCH_CHANNEL = "launch"

        /** True when a run() result text describes a failure (used for history and UI colours). */
        fun looksFailed(r: String): Boolean =
            r.startsWith("Failed") || r.startsWith("Needs") || r.startsWith("Could not") ||
                r.startsWith("No flashlight") || r.contains("not installed")

        /** Exactly what the command recogniser is allowed to hear. Keep phrases distinct. */
        val PHRASES: Map<String, Cmd> = mapOf(
            "torch on" to Cmd.TORCH_ON,
            "torch off" to Cmd.TORCH_OFF,
            "volume up" to Cmd.VOLUME_UP,
            "volume down" to Cmd.VOLUME_DOWN,
            "mute audio" to Cmd.MUTE,
            "open camera" to Cmd.OPEN_CAMERA,
            "open whatsapp" to Cmd.OPEN_WHATSAPP,
            "open chat" to Cmd.OPEN_WHATSAPP, // backup phrase in case "whatsapp" isn't in the model
            // The small model hears "whatsapp" as "what's up", so accept that too
            "what's up" to Cmd.OPEN_WHATSAPP,
            "open what's up" to Cmd.OPEN_WHATSAPP,
            "tell time" to Cmd.TELL_TIME,
            "what time is it" to Cmd.TELL_TIME,
            "what's time is it" to Cmd.TELL_TIME,
            "what's the time" to Cmd.TELL_TIME,
            "tell me the time" to Cmd.TELL_TIME,
            "go back" to Cmd.GO_BACK,
            "go home" to Cmd.GO_HOME,
            "recent apps" to Cmd.RECENTS,
            "take screen shot" to Cmd.SCREENSHOT,
            "show notifications" to Cmd.SHOW_NOTIFICATIONS,
            "quick settings" to Cmd.QUICK_SETTINGS,
            "lock screen" to Cmd.LOCK_SCREEN,
            "clear notifications" to Cmd.CLEAR_NOTIFICATIONS,
            "play music" to Cmd.MEDIA_PLAY,
            "pause music" to Cmd.MEDIA_PAUSE,
            "next song" to Cmd.MEDIA_NEXT,
            "previous song" to Cmd.MEDIA_PREV,
            "answer call" to Cmd.ANSWER_CALL,
            "pick up" to Cmd.ANSWER_CALL,
            "end call" to Cmd.END_CALL,
            "hang up" to Cmd.END_CALL,
            "reject call" to Cmd.END_CALL
        )

        fun grammarJson(extra: Collection<String> = emptyList()): String {
            val arr = JSONArray()
            PHRASES.keys.forEach { arr.put(it) }
            extra.forEach { if (!PHRASES.containsKey(it)) arr.put(it) }
            arr.put("[unk]") // lets random noise land here instead of being forced into a command
            return arr.toString()
        }
    }
}
