package com.felix.microassistant

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.provider.MediaStore
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Cmd {
    TORCH_ON, TORCH_OFF, VOLUME_UP, VOLUME_DOWN, MUTE,
    OPEN_CAMERA, OPEN_WHATSAPP, TELL_TIME
}

/**
 * Turns a recognised command into a real phone action.
 * To add a command later: add it to Cmd, add phrase(s) to PHRASES, add a branch in run().
 */
class CommandRunner(
    private val ctx: Context,
    private val speak: (String) -> Unit
) {

    fun run(cmd: Cmd): String = try {
        when (cmd) {
            Cmd.TORCH_ON -> setTorch(true)
            Cmd.TORCH_OFF -> setTorch(false)
            Cmd.VOLUME_UP -> changeVolume(AudioManager.ADJUST_RAISE, "Volume up")
            Cmd.VOLUME_DOWN -> changeVolume(AudioManager.ADJUST_LOWER, "Volume down")
            Cmd.MUTE -> changeVolume(AudioManager.ADJUST_MUTE, "Muted")
            Cmd.OPEN_CAMERA -> launch(Intent(MediaStore.ACTION_STILL_IMAGE_CAMERA), "Camera")
            Cmd.OPEN_WHATSAPP -> openWhatsApp()
            Cmd.TELL_TIME -> tellTime()
        }
    } catch (e: Exception) {
        "Failed: ${e.message ?: e.javaClass.simpleName}"
    }

    private fun setTorch(on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { camId ->
            val c = cm.getCameraCharacteristics(camId)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        } ?: return "No flashlight found on this phone"
        cm.setTorchMode(id, on)
        return if (on) "Torch on" else "Torch off"
    }

    private fun changeVolume(direction: Int, label: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val steps = if (direction == AudioManager.ADJUST_MUTE) 1 else 2
        repeat(steps) { i ->
            val flags = if (i == steps - 1) AudioManager.FLAG_SHOW_UI else 0
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, flags)
        }
        return label
    }

    private fun openWhatsApp(): String {
        val pm = ctx.packageManager
        val intent = pm.getLaunchIntentForPackage("com.whatsapp")
            ?: pm.getLaunchIntentForPackage("com.whatsapp.w4b")
            ?: return "WhatsApp is not installed"
        return launch(intent, "WhatsApp")
    }

    private fun tellTime(): String {
        val t = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        speak("It is $t")
        return "Time is $t"
    }

    /**
     * Android blocks apps from opening screens out of nowhere. We try directly, and also
     * post a "tap to open" notification (with a full-screen intent) as a backup.
     */
    private fun launch(intent: Intent, label: String): String {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(intent)
        } catch (e: Exception) {
            return "Could not open $label: ${e.message}"
        }
        postTapNotification(intent, label)
        return "Opening $label"
    }

    private fun postTapNotification(intent: Intent, label: String) {
        try {
            val pi = PendingIntent.getActivity(
                ctx, label.hashCode(), intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(ctx, LAUNCH_CHANNEL)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Tap to open $label")
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .setAutoCancel(true)
                .setTimeoutAfter(8000)
                .build()
            ctx.getSystemService(NotificationManager::class.java).notify(2, n)
        } catch (e: Exception) {
            // backup only, ignore
        }
    }

    companion object {
        const val LAUNCH_CHANNEL = "launch"

        /** Exactly what the command recogniser is allowed to hear. Keep phrases distinct. */
        val PHRASES: Map<String, Cmd> = mapOf(
            "torch on" to Cmd.TORCH_ON,
            "torch off" to Cmd.TORCH_OFF,
            "volume up" to Cmd.VOLUME_UP,
            "volume down" to Cmd.VOLUME_DOWN,
            "mute audio" to Cmd.MUTE,
            "open camera" to Cmd.OPEN_CAMERA,
            "open whatsapp" to Cmd.OPEN_WHATSAPP,
            "open chat" to Cmd.OPEN_WHATSAPP, // backup phrase in case "whatsapp" isn't in the model
            "tell time" to Cmd.TELL_TIME,
            "what time is it" to Cmd.TELL_TIME
        )

        fun grammarJson(): String {
            val arr = JSONArray()
            PHRASES.keys.forEach { arr.put(it) }
            arr.put("[unk]") // lets random noise land here instead of being forced into a command
            return arr.toString()
        }
    }
}
