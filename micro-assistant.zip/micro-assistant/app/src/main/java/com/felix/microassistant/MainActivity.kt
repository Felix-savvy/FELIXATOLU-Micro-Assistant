package com.felix.microassistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private lateinit var prefs: SharedPreferences

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == WakeWordService.KEY_STATUS) runOnUiThread { showStatus() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(WakeWordService.PREFS, Context.MODE_PRIVATE)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "Micro Assistant"
            textSize = 26f
        })
        root.addView(TextView(this).apply {
            text = "Tap Start. Say \"${WakeWordService.WAKE_WORD}\", wait for the beep, " +
                "then say ONE command within 4 seconds."
            setPadding(0, pad / 2, 0, pad / 2)
        })

        root.addView(Button(this).apply {
            text = "Start listening"
            setOnClickListener { startListening() }
        })
        root.addView(Button(this).apply {
            text = "Stop"
            setOnClickListener {
                startService(
                    Intent(this@MainActivity, WakeWordService::class.java)
                        .setAction(WakeWordService.ACTION_STOP)
                )
            }
        })
        root.addView(Button(this).apply {
            text = "Battery settings (allow background)"
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (e: Exception) {
                    toast("Open Settings > Battery manually")
                }
            }
        })
        root.addView(Button(this).apply {
            text = "Allow full-screen notifications (for open camera / WhatsApp)"
            setOnClickListener {
                try {
                    if (Build.VERSION.SDK_INT >= 34) {
                        startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                                Uri.parse("package:$packageName")
                            )
                        )
                    } else {
                        toast("Not needed on this Android version")
                    }
                } catch (e: Exception) {
                    toast("Open Settings > Apps > Micro Assistant manually")
                }
            }
        })

        statusView = TextView(this).apply {
            textSize = 18f
            setPadding(0, pad, 0, pad)
        }
        root.addView(statusView)

        root.addView(TextView(this).apply {
            text = "Commands:\n" + CommandRunner.PHRASES.keys.joinToString("\n") { "• $it" }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        showStatus()
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
    }

    override fun onPause() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        super.onPause()
    }

    private fun showStatus() {
        statusView.text = "Status: " + prefs.getString(WakeWordService.KEY_STATUS, "Not started")
    }

    private fun startListening() {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (needed.isNotEmpty()) {
            requestPermissions(needed.toTypedArray(), REQ_PERMS)
            return
        }

        startForegroundService(Intent(this, WakeWordService::class.java))
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERMS) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            toast("Microphone permission is required")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        private const val REQ_PERMS = 1
    }
}
