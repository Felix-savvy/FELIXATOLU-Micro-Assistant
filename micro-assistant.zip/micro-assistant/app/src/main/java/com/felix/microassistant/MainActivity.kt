package com.felix.microassistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var keyInput: EditText
    private lateinit var statusView: TextView
    private lateinit var prefs: SharedPreferences

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == WakeWordService.KEY_STATUS) showStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(WakeWordService.PREFS, Context.MODE_PRIVATE)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "Micro Assistant"
            textSize = 26f
        })
        root.addView(TextView(this).apply {
            text = "Milestone 1: wake word. Paste your Picovoice AccessKey, tap Start, " +
                "then say \"Jarvis\". The phone should vibrate."
            setPadding(0, pad / 2, 0, pad / 2)
        })

        keyInput = EditText(this).apply {
            hint = "Picovoice AccessKey"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            setText(prefs.getString(WakeWordService.KEY_ACCESS, ""))
        }
        root.addView(keyInput)

        root.addView(Button(this).apply {
            text = "Start listening"
            setOnClickListener { startListening() }
        })
        root.addView(Button(this).apply {
            text = "Stop"
            setOnClickListener {
                startService(
                    Intent(this@MainActivity, WakeWordService::class.java)
                        .setAction(WakeWordService.ACTION_STOP)
                )
            }
        })
        root.addView(Button(this).apply {
            text = "Battery settings (allow background)"
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (e: Exception) {
                    toast("Open Settings > Battery manually")
                }
            }
        })

        statusView = TextView(this).apply {
            textSize = 18f
            setPadding(0, pad, 0, 0)
        }
        root.addView(statusView)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        showStatus()
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
    }

    override fun onPause() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        super.onPause()
    }

    private fun showStatus() {
        statusView.text = "Status: " + prefs.getString(WakeWordService.KEY_STATUS, "Not started")
    }

    private fun startListening() {
        val key = keyInput.text.toString().trim()
        if (key.isEmpty()) {
            toast("Paste your AccessKey first")
            return
        }
        prefs.edit().putString(WakeWordService.KEY_ACCESS, key).apply()

        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (needed.isNotEmpty()) {
            requestPermissions(needed.toTypedArray(), REQ_PERMS)
            return
        }

        startForegroundService(Intent(this, WakeWordService::class.java))
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERMS) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            toast("Microphone permission is required")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        private const val REQ_PERMS = 1
    }
}
