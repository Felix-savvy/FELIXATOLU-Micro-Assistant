package com.felix.microassistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var contentFrame: FrameLayout
    private lateinit var rootFrame: FrameLayout
    private lateinit var screens: List<Screen>
    private lateinit var navHolders: List<LinearLayout>
    private lateinit var navIcons: List<GlyphView>
    private lateinit var navLabels: List<TextView>
    private lateinit var runner: CommandRunner
    private var current: Screen? = null
    private var tab = 0
    private var torchOn = false
    private var onboarding: OnboardingScreen? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Theme.apply(this)
        applyBars()
        runner = CommandRunner(applicationContext) { }

        screens = listOf(HomeScreen(this), CommandsScreen(this), HistoryScreen(this), SettingsScreen(this))
        tab = savedInstanceState?.getInt("tab") ?: lastTab

        rootFrame = FrameLayout(this)
        rootFrame.setBackgroundColor(Theme.c.bg)

        val column = vbox()
        contentFrame = FrameLayout(this)
        column.addView(contentFrame, LinearLayout.LayoutParams(MATCH, 0, 1f))
        column.addView(buildNav(), LinearLayout.LayoutParams(MATCH, WRAP))
        rootFrame.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(rootFrame)

        showTab(tab)

        val prefs = getSharedPreferences(WakeWordService.PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(KEY_ONBOARDED, false)) showOnboarding()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", tab)
    }

    override fun onResume() {
        super.onResume()
        current?.onShow()
    }

    override fun onPause() {
        current?.onHide()
        super.onPause()
    }

    // ---------------------------------------------------------------- look

    @Suppress("DEPRECATION")
    private fun applyBars() {
        val pal = Theme.c
        window.setBackgroundDrawable(ColorDrawable(pal.bg))
        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.surface
        var flags = window.decorView.systemUiVisibility
        flags = if (pal.dark) {
            flags and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
        } else {
            flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.decorView.systemUiVisibility = flags
    }

    private fun buildNav(): View {
        val pal = Theme.c
        val wrap = vbox()
        wrap.setBackgroundColor(pal.surface)
        wrap.addView(divider(), lpd(h = dp(1)))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL

        val glyphs = listOf(G.HOME, G.LIST, G.CLOCK, G.SLIDERS)
        val names = listOf("Home", "Commands", "History", "Settings")
        val holders = ArrayList<LinearLayout>()
        val icons = ArrayList<GlyphView>()
        val labels = ArrayList<TextView>()

        for (i in glyphs.indices) {
            val item = vbox()
            item.gravity = Gravity.CENTER_HORIZONTAL
            item.setPadding(0, dp(8), 0, dp(8))
            item.isClickable = true
            item.setOnClickListener { showTab(i) }

            val holder = LinearLayout(this)
            holder.gravity = Gravity.CENTER
            val icon = GlyphView(this, glyphs[i], pal.text2)
            holder.addView(icon, LinearLayout.LayoutParams(dp(24), dp(24)))
            item.addView(holder, LinearLayout.LayoutParams(dp(56), dp(30)))

            val caption = label(names[i], 11f, pal.text2, 1)
            item.addView(caption, lpd(w = WRAP, t = 3))

            holders.add(holder)
            icons.add(icon)
            labels.add(caption)
            row.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        navHolders = holders
        navIcons = icons
        navLabels = labels
        wrap.addView(row, lpd())
        return wrap
    }

    private fun selectNav(i: Int) {
        val pal = Theme.c
        for (k in navIcons.indices) {
            val on = k == i
            val c = if (on) pal.accent else pal.text2
            navIcons[k].set(navIcons[k].glyph, c)
            navLabels[k].setTextColor(c)
            navHolders[k].background = if (on) shape(withAlpha(pal.accent, 38), 15f) else null
        }
    }

    private fun showTab(i: Int) {
        current?.onHide()
        tab = i
        lastTab = i
        val s = screens[i]
        contentFrame.removeAllViews()
        contentFrame.addView(s.view, FrameLayout.LayoutParams(MATCH, MATCH))
        current = s
        selectNav(i)
        s.onShow()
    }

    // ---------------------------------------------------------- onboarding

    private fun showOnboarding() {
        val ob = OnboardingScreen(this) { start -> finishOnboarding(start) }
        onboarding = ob
        rootFrame.addView(ob.view, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun finishOnboarding(start: Boolean) {
        getSharedPreferences(WakeWordService.PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ONBOARDED, true).apply()
        onboarding?.let { rootFrame.removeView(it.view) }
        onboarding = null
        if (start) startListening()
    }

    fun restartOnboarding() {
        getSharedPreferences(WakeWordService.PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ONBOARDED, false).apply()
        if (onboarding == null) showOnboarding()
    }

    // ----------------------------------------------------- service control

    private fun hasBasics(): Boolean {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        return true
    }

    /** Asks for the microphone (and notification) permission if missing. */
    fun requestBasics() {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), REQ_PERMS)
    }

    fun startListening() {
        if (!hasBasics()) {
            requestBasics()
            return
        }
        startForegroundService(Intent(this, WakeWordService::class.java))
    }

    fun stopListening() {
        startService(Intent(this, WakeWordService::class.java).setAction(WakeWordService.ACTION_STOP))
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERMS) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            if (!AssistantBus.serviceRunning) startListening()
        } else {
            Toast.makeText(this, "Microphone permission is required", Toast.LENGTH_LONG).show()
        }
        current?.onShow()
    }

    /** The big mic on Home: start the assistant, or trigger one command now. */
    fun manualMic() {
        when {
            !AssistantBus.serviceRunning -> startListening()
            AssistantBus.state == AState.LOADING ->
                Toast.makeText(this, "Still getting ready...", Toast.LENGTH_SHORT).show()
            else -> startService(
                Intent(this, WakeWordService::class.java).setAction(WakeWordService.ACTION_MANUAL)
            )
        }
    }

    // --------------------------------------------------------- quick tests

    fun quickTorch() {
        torchOn = !torchOn
        runQuick(if (torchOn) Cmd.TORCH_ON else Cmd.TORCH_OFF, if (torchOn) "Torch on" else "Torch off")
    }

    /** Runs a command by tapping instead of speaking. Also useful for testing. */
    fun runQuick(cmd: Cmd, label: String) {
        val result = runner.run(cmd)
        val ok = !CommandRunner.looksFailed(result)
        if (!ok && (cmd == Cmd.TORCH_ON || cmd == Cmd.TORCH_OFF)) torchOn = false
        HistoryStore.add(this, "Tapped: $label", result, ok)
        AssistantBus.update(
            state = if (ok) AState.SUCCESS else AState.ERROR,
            heard = "Tapped: $label",
            reply = result
        )
        AssistantBus.settleLater()
    }

    companion object {
        private const val REQ_PERMS = 1
        private const val KEY_ONBOARDED = "onboarded"
        private var lastTab = 0
    }
}
