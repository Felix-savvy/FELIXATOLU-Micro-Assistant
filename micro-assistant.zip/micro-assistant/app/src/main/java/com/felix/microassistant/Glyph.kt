package com.felix.microassistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

enum class G {
    HOME, LIST, CLOCK, SLIDERS, MIC, TORCH, CAMERA, CHAT, VOLUME,
    CHECK, CROSS, TRASH, CHEVRON, WARN, PLAY
}

/**
 * Tiny icon set drawn in code on a 24x24 grid, so it recolours with the theme and
 * needs no image files. Stroke style, round caps.
 */
class GlyphView(ctx: Context, var glyph: G, var color: Int) : View(ctx) {

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    init {
        stroke.style = Paint.Style.STROKE
        stroke.strokeCap = Paint.Cap.ROUND
        stroke.strokeJoin = Paint.Join.ROUND
        stroke.strokeWidth = 2f
        fill.style = Paint.Style.FILL
    }

    fun set(g: G, c: Int) {
        glyph = g
        color = c
        invalidate()
    }

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        c.drawLine(x1, y1, x2, y2, stroke)
    }

    private fun poly(c: Canvas, close: Boolean, vararg pts: Float) {
        path.reset()
        path.moveTo(pts[0], pts[1])
        var i = 2
        while (i < pts.size) {
            path.lineTo(pts[i], pts[i + 1])
            i += 2
        }
        if (close) path.close()
        c.drawPath(path, stroke)
    }

    private fun rrect(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float) {
        rect.set(l, t, r, b)
        c.drawRoundRect(rect, rad, rad, stroke)
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height) / 24f
        if (s <= 0f) return
        stroke.color = color
        fill.color = color
        c.save()
        c.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        c.scale(s, s)
        when (glyph) {
            G.HOME -> {
                poly(c, false, 4f, 11f, 12f, 4f, 20f, 11f)
                poly(c, false, 6f, 10f, 6f, 20f, 18f, 20f, 18f, 10f)
            }
            G.LIST -> {
                line(c, 9f, 7f, 20f, 7f)
                line(c, 9f, 12f, 20f, 12f)
                line(c, 9f, 17f, 20f, 17f)
                c.drawCircle(5f, 7f, 1.3f, fill)
                c.drawCircle(5f, 12f, 1.3f, fill)
                c.drawCircle(5f, 17f, 1.3f, fill)
            }
            G.CLOCK -> {
                c.drawCircle(12f, 12f, 8.5f, stroke)
                poly(c, false, 12f, 7.5f, 12f, 12f, 15.5f, 14f)
            }
            G.SLIDERS -> {
                line(c, 4f, 7f, 20f, 7f)
                line(c, 4f, 12f, 20f, 12f)
                line(c, 4f, 17f, 20f, 17f)
                c.drawCircle(15f, 7f, 2.4f, fill)
                c.drawCircle(8f, 12f, 2.4f, fill)
                c.drawCircle(16f, 17f, 2.4f, fill)
            }
            G.MIC -> {
                rrect(c, 9f, 3f, 15f, 13.5f, 3f)
                rect.set(6f, 7f, 18f, 19f)
                c.drawArc(rect, 0f, 180f, false, stroke)
                line(c, 12f, 19f, 12f, 22f)
            }
            G.TORCH -> {
                rrect(c, 8.5f, 3f, 15.5f, 8.5f, 1.5f)
                rrect(c, 10f, 8.5f, 14f, 21f, 1.5f)
                line(c, 12f, 12f, 12f, 14f)
            }
            G.CAMERA -> {
                rrect(c, 3f, 7.5f, 21f, 19f, 3f)
                c.drawCircle(12f, 13.2f, 3.4f, stroke)
                poly(c, false, 8.5f, 7.5f, 9.8f, 5f, 14.2f, 5f, 15.5f, 7.5f)
            }
            G.CHAT -> {
                rrect(c, 4f, 4f, 20f, 16f, 4f)
                poly(c, false, 9f, 16f, 8f, 20f, 13f, 16f)
            }
            G.VOLUME -> {
                poly(c, true, 4f, 9.5f, 8f, 9.5f, 13f, 5.5f, 13f, 18.5f, 8f, 14.5f, 4f, 14.5f)
                rect.set(9f, 7f, 19f, 17f)
                c.drawArc(rect, -45f, 90f, false, stroke)
            }
            G.CHECK -> poly(c, false, 5f, 12.5f, 10f, 17.5f, 19f, 7f)
            G.CROSS -> {
                line(c, 6f, 6f, 18f, 18f)
                line(c, 18f, 6f, 6f, 18f)
            }
            G.TRASH -> {
                line(c, 5f, 7f, 19f, 7f)
                poly(c, false, 9f, 7f, 9f, 4.5f, 15f, 4.5f, 15f, 7f)
                poly(c, false, 7f, 7f, 8f, 20f, 16f, 20f, 17f, 7f)
            }
            G.CHEVRON -> poly(c, false, 9f, 6f, 15f, 12f, 9f, 18f)
            G.PLAY -> poly(c, true, 8f, 5.5f, 19f, 12f, 8f, 18.5f)
            G.WARN -> {
                poly(c, true, 12f, 4f, 21f, 19.5f, 3f, 19.5f)
                line(c, 12f, 10f, 12f, 14f)
                c.drawCircle(12f, 17f, 1.1f, fill)
            }
        }
        c.restore()
    }
}
