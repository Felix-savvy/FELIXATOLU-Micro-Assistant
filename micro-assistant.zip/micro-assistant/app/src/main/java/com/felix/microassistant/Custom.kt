package com.felix.microassistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.ContactsContract
import org.json.JSONArray
import org.json.JSONObject

/** What a custom / automatic command does. type: app, url, call, say, intent. */
class CustomAction(val type: String, val arg: String, val label: String)

/** A command the user made: "when I say [phrase], do [action]". */
class CustomCmd(val phrase: String, val type: String, val arg: String, val label: String) {
    fun action() = CustomAction(type, arg, label)

    fun summary(): String = when (type) {
        "app" -> "Opens $label"
        "url" -> "Opens $arg"
        "call" -> "Calls " + label.ifEmpty { arg }
        "say" -> "Says \"$arg\""
        else -> "Custom Android action"
    }
}

object CustomStore {
    private const val KEY = "custom_commands"

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(WakeWordService.PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun all(ctx: Context): List<CustomCmd> {
        val arr = try {
            JSONArray(prefs(ctx).getString(KEY, "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
        val out = ArrayList<CustomCmd>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(CustomCmd(o.optString("p"), o.optString("t"), o.optString("a"), o.optString("l")))
        }
        return out
    }

    private fun save(ctx: Context, list: List<CustomCmd>) {
        val arr = JSONArray()
        for (c in list) {
            val o = JSONObject()
            o.put("p", c.phrase)
            o.put("t", c.type)
            o.put("a", c.arg)
            o.put("l", c.label)
            arr.put(o)
        }
        prefs(ctx).edit().putString(KEY, arr.toString()).apply()
    }

    @Synchronized
    fun add(ctx: Context, c: CustomCmd) {
        val list = all(ctx).filter { it.phrase != c.phrase }.toMutableList()
        list.add(c)
        save(ctx, list)
    }

    @Synchronized
    fun remove(ctx: Context, phrase: String) {
        save(ctx, all(ctx).filter { it.phrase != phrase })
    }
}

class AppEntry(val label: String, val pkg: String)

/** Every app with a launcher icon, plus optional spoken-name overrides. */
object AppIndex {
    private const val ALIASES = "app_aliases"

    fun list(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        val out = ArrayList<AppEntry>()
        try {
            for (ri in pm.queryIntentActivities(intent, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == ctx.packageName || !seen.add(pkg)) continue
                out.add(AppEntry(ri.loadLabel(pm).toString(), pkg))
            }
        } catch (e: Exception) {
        }
        out.sortBy { it.label.lowercase() }
        return out
    }

    private fun aliases(ctx: Context): JSONObject = try {
        JSONObject(ctx.getSharedPreferences(WakeWordService.PREFS, Context.MODE_PRIVATE).getString(ALIASES, "{}"))
    } catch (e: Exception) {
        JSONObject()
    }

    fun setAlias(ctx: Context, pkg: String, name: String) {
        val o = aliases(ctx)
        if (name.isEmpty()) o.remove(pkg) else o.put(pkg, name)
        ctx.getSharedPreferences(WakeWordService.PREFS, Context.MODE_PRIVATE)
            .edit().putString(ALIASES, o.toString()).apply()
    }

    /** What you say after "open": the alias if one is set, otherwise the app's own name. */
    fun spokenName(ctx: Context, e: AppEntry): String {
        val a = aliases(ctx).optString(e.pkg, "")
        return if (a.isNotEmpty()) a else AppPrefs.clean(e.label)
    }
}

/** "call <name>" phrases built from the phone's contacts. */
object ContactIndex {
    fun build(ctx: Context): Map<String, CustomAction> {
        val out = LinkedHashMap<String, CustomAction>()
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return out
        val vocab = Vocab.get(ctx) ?: return out

        // name -> (contact id -> number)
        val byName = HashMap<String, MutableMap<Long, String>>()
        val shown = HashMap<String, String>()
        fun add(key: String, display: String, id: Long, number: String) {
            val m = byName.getOrPut(key) { HashMap() }
            if (!m.containsKey(id)) m[id] = number
            shown[key] = display
        }
        try {
            val cols = arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            )
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI, cols, null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val name = c.getString(1) ?: continue
                    val num = c.getString(2) ?: continue
                    val full = AppPrefs.clean(name)
                    if (full.isEmpty()) continue
                    add(full, name, id, num)
                    val first = full.substringBefore(' ')
                    if (first != full) add(first, name.substringBefore(' '), id, num)
                }
            }
        } catch (e: Exception) {
            return out
        }
        for ((key, people) in byName) {
            if (people.size != 1) continue // two contacts share this name: too ambiguous
            if (!key.split(' ').all { it in vocab }) continue
            out["call $key"] = CustomAction("call", people.values.first(), shown[key] ?: key)
        }
        return out
    }
}

/** Everything the assistant can be told beyond the built-in commands. */
object DynamicCommands {
    const val MAX = 450

    fun ready(name: String, vocab: Set<String>): Boolean {
        if (name.isEmpty()) return false
        val w = name.split(" ")
        return w.size <= 4 && w.all { it in vocab }
    }

    fun build(ctx: Context): Map<String, CustomAction> {
        val map = LinkedHashMap<String, CustomAction>()
        for (c in CustomStore.all(ctx)) map[c.phrase] = c.action()
        val vocab = Vocab.get(ctx) ?: return map // can't tell which names are hearable
        if (AppPrefs.appsByVoice(ctx)) {
            for (e in AppIndex.list(ctx)) {
                if (map.size >= MAX) break
                val name = AppIndex.spokenName(ctx, e)
                if (!ready(name, vocab)) continue
                val phrase = "open $name"
                if (!map.containsKey(phrase) && !CommandRunner.PHRASES.containsKey(phrase)) {
                    map[phrase] = CustomAction("app", e.pkg, e.label)
                }
            }
        }
        if (AppPrefs.contactsByVoice(ctx)) {
            for ((k, v) in ContactIndex.build(ctx)) {
                if (map.size >= MAX) break
                if (!map.containsKey(k) && !CommandRunner.PHRASES.containsKey(k)) map[k] = v
            }
        }
        return map
    }
}
