package com.felix.microassistant

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** A row of bars that dance while the assistant is listening or working. */
class WaveView(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var phase = 0f
    private var anim: ValueAnimator? = null
    private var speedMs = 1100L
    var color: Int = Color.parseColor("#B8F34A")
        set(v) {
            field = v
            invalidate()
        }
    /** 0 = flat, 1 = gentle, 2 = lively */
    var energy = 2
        set(v) {
            field = v
            invalidate()
        }

    fun run(fast: Boolean) {
        val ms = if (fast) 700L else 1100L
        if (anim != null && ms == speedMs) return
        stop()
        speedMs = ms
        val a = ValueAnimator.ofFloat(0f, (Math.PI * 2).toFloat())
        a.duration = ms
        a.repeatCount = ValueAnimator.INFINITE
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
        a.start()
        anim = a
    }

    fun stop() {
        anim?.cancel()
        anim = null
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val n = 9
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f) return
        val gap = w / (n * 2f)
        val bw = gap
        paint.color = color
        val amp = when (energy) {
            0 -> 0.08f
            1 -> 0.30f
            else -> 0.55f
        }
        for (i in 0 until n) {
            val centre = 1f - Math.abs(i - (n - 1) / 2f) / (n / 2f) // taller in the middle
            val wob = (Math.sin(phase + i * 0.7).toFloat() + 1f) / 2f
            val bh = h * (0.14f + amp * centre * (0.35f + 0.65f * wob))
            val x = gap / 2f + i * 2f * gap
            rect.set(x, (h - bh) / 2f, x + bw, (h + bh) / 2f)
            c.drawRoundRect(rect, bw / 2f, bw / 2f, paint)
        }
    }
}

/**
 * The floating card: a small panel at the bottom of the screen, over any app, that shows
 * what the assistant is doing (listening, heard, done). It lives inside the background
 * service. It also gives the app a visible window, which is what lets Android allow
 * "open camera" / "open WhatsApp" from the background.
 */
class OverlayCard(private val ctx: Context) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: FrameLayout? = null
    private var wave: WaveView? = null
    private var stateTv: TextView? = null
    private var heardTv: TextView? = null
    private var replyTv: TextView? = null
    private var stateDot: View? = null
    private var dismissed = false

    private val listener: () -> Unit = { update() }

    fun start() {
        AssistantBus.addListener(listener)
    }

    fun stop() {
        AssistantBus.removeListener(listener)
        hide()
    }

    fun canShow(): Boolean =
        AppPrefs.floatingCard(ctx) && Settings.canDrawOverlays(ctx)

    private fun update() {
        val s = AssistantBus.state
        val active = s == AState.LISTENING || s == AState.PROCESSING ||
            s == AState.EXECUTING || s == AState.SUCCESS || s == AState.ERROR
        if (!active || !canShow()) {
            hide()
            if (!active) dismissed = false
            return
        }
        if (dismissed) return
        show()
        bind(s)
    }

    private fun bind(s: AState) {
        val pal = Theme.c
        val (label, colour, energy) = when (s) {
            AState.LISTENING -> Triple("Listening", pal.accent, 2)
            AState.PROCESSING -> Triple("Thinking", pal.accent, 1)
            AState.EXECUTING -> Triple("Working", pal.accent, 1)
            AState.SUCCESS -> Triple("Done", pal.success, 0)
            else -> Triple("Didn't catch that", pal.error, 0)
        }
        stateTv?.text = label
        (stateDot?.background as? android.graphics.drawable.GradientDrawable)?.setColor(colour)
        wave?.color = colour
        wave?.energy = energy
        if (s == AState.LISTENING || s == AState.PROCESSING || s == AState.EXECUTING) {
            wave?.run(s == AState.LISTENING)
        } else {
            wave?.stop()
        }
        val heard = AssistantBus.heard
        heardTv?.text = if (heard.isEmpty()) "Say a command" else "“$heard”"
        heardTv?.setTextColor(if (heard.isEmpty()) pal.text2 else pal.text)
        replyTv?.text = AssistantBus.reply
        replyTv?.visibility = if (AssistantBus.reply.isEmpty() || s == AState.LISTENING) View.GONE else View.VISIBLE
        replyTv?.setTextColor(
            when (s) {
                AState.SUCCESS -> pal.success
                AState.ERROR -> pal.error
                else -> pal.text2
            }
        )
    }

    private fun show() {
        if (root != null) return
        Theme.apply(ctx)
        val pal = Theme.c

        val card = ctx.vbox()
        card.background = ctx.shape(pal.surface, 26f, pal.border, 1)
        card.setPadding(ctx.dp(18), ctx.dp(14), ctx.dp(18), ctx.dp(18))
        card.elevation = ctx.dpf(12f)

        // header: logo, name, state
        val head = ctx.hbox()
        val logo = LogoView(ctx, true)
        head.addView(logo, LinearLayout.LayoutParams(ctx.dp(22), ctx.dp(22)))
        head.addView(ctx.label("FexAi", 13f, pal.text, 2), ctx.lpd(w = WRAP, l = 8))
        head.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
        val dot = ctx.dot(pal.accent)
        val dl = LinearLayout.LayoutParams(ctx.dp(7), ctx.dp(7))
        dl.rightMargin = ctx.dp(6)
        head.addView(dot, dl)
        val st = ctx.label("Listening", 12f, pal.text2, 1)
        head.addView(st)
        card.addView(head, ctx.lpd())

        val w = WaveView(ctx)
        card.addView(w, ctx.lpd(h = ctx.dp(44), t = 10, b = 8))

        val heard = ctx.label("", 20f, pal.text, 2)
        heard.gravity = Gravity.CENTER
        card.addView(heard, ctx.lpd())
        val reply = ctx.label("", 14f, pal.text2, 0)
        reply.gravity = Gravity.CENTER
        card.addView(reply, ctx.lpd(t = 4))

        val frame = FrameLayout(ctx)
        frame.setPadding(ctx.dp(12), 0, ctx.dp(12), 0)
        frame.addView(card, FrameLayout.LayoutParams(MATCH, WRAP))
        card.isClickable = true
        card.setOnClickListener {
            dismissed = true // tap to put it away until the next wake word
            hide()
        }

        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val lp = WindowManager.LayoutParams(
            MATCH, WRAP, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM
        lp.y = ctx.dp(34)
        try {
            wm.addView(frame, lp)
        } catch (e: Exception) {
            return
        }
        card.alpha = 0f
        card.translationY = ctx.dpf(40f)
        card.animate().alpha(1f).translationY(0f).setDuration(180).start()

        root = frame
        wave = w
        stateTv = st
        heardTv = heard
        replyTv = reply
        stateDot = dot
    }

    private fun hide() {
        val r = root ?: return
        wave?.stop()
        try {
            wm.removeView(r)
        } catch (e: Exception) {
        }
        root = null
        wave = null
        stateTv = null
        heardTv = null
        replyTv = null
        stateDot = null
    }
}
