package com.felix.microassistant

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** A row of bars that dance while the assistant is listening or working. */
class WaveView(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var phase = 0f
    private var anim: ValueAnimator? = null
    private var speedMs = 1100L
    var color: Int = Color.parseColor("#B8F34A")
        set(v) {
            field = v
            invalidate()
        }
    /** 0 = flat, 1 = gentle, 2 = lively */
    var energy = 2
        set(v) {
            field = v
            invalidate()
        }
    var bars = 9

    fun run(fast: Boolean) {
        val ms = if (fast) 700L else 1100L
        if (anim != null && ms == speedMs) return
        stop()
        speedMs = ms
        val a = ValueAnimator.ofFloat(0f, (Math.PI * 2).toFloat())
        a.duration = ms
        a.repeatCount = ValueAnimator.INFINITE
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
        a.start()
        anim = a
    }

    fun stop() {
        anim?.cancel()
        anim = null
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val n = bars
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f) return
        val gap = w / (n * 2f)
        val bw = gap
        paint.color = color
        val amp = when (energy) {
            0 -> 0.08f
            1 -> 0.30f
            else -> 0.55f
        }
        for (i in 0 until n) {
            val centre = 1f - Math.abs(i - (n - 1) / 2f) / (n / 2f)
            val wob = (Math.sin(phase + i * 0.7).toFloat() + 1f) / 2f
            val bh = h * (0.14f + amp * centre * (0.35f + 0.65f * wob))
            val x = gap / 2f + i * 2f * gap
            rect.set(x, (h - bh) / 2f, x + bw, (h + bh) / 2f)
            c.drawRoundRect(rect, bw / 2f, bw / 2f, paint)
        }
    }
}

/**
 * Soft coloured light around the screen edges, like Gemini / Folax.
 * Two blurred edge images are prepared once (at quarter size, so it is cheap) and
 * cross-faded slowly, which makes the colours drift without heavy drawing.
 */
class GlowView(ctx: Context, private val colors: IntArray) : View(ctx) {
    private var a: Bitmap? = null
    private var b: Bitmap? = null
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dst = Rect()
    private var t = 0f
    private var anim: ValueAnimator? = null

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return
        a = make(w, h, 0f)
        b = make(w, h, 180f)
    }

    private fun make(w: Int, h: Int, rot: Float): Bitmap? {
        return try {
            val scale = 4
            val bw = maxOf(1, w / scale)
            val bh = maxOf(1, h / scale)
            val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            val d = resources.displayMetrics.density / scale
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 46f * d
            val sweep = SweepGradient(bw / 2f, bh / 2f, colors, null)
            val m = Matrix()
            m.setRotate(rot, bw / 2f, bh / 2f)
            sweep.setLocalMatrix(m)
            p.shader = sweep
            p.maskFilter = BlurMaskFilter(30f * d, BlurMaskFilter.Blur.NORMAL)
            c.drawRoundRect(RectF(0f, 0f, bw.toFloat(), bh.toFloat()), 44f * d, 44f * d, p)
            bmp
        } catch (e: Throwable) {
            null
        }
    }

    fun start() {
        if (anim != null) return
        val v = ValueAnimator.ofFloat(0f, 1f)
        v.duration = 2600
        v.repeatCount = ValueAnimator.INFINITE
        v.repeatMode = ValueAnimator.REVERSE
        v.interpolator = LinearInterpolator()
        v.addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
        v.start()
        anim = v
    }

    fun stop() {
        anim?.cancel()
        anim = null
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        dst.set(0, 0, width, height)
        val ba = a
        val bb = b
        if (ba != null) {
            paint.alpha = ((1f - t) * 255).toInt()
            c.drawBitmap(ba, null, dst, paint)
        }
        if (bb != null) {
            paint.alpha = (t * 255).toInt()
            c.drawBitmap(bb, null, dst, paint)
        }
    }
}

/**
 * The floating card. Lives inside the background service and shows, over any app, what the
 * assistant is doing. Styles: 0 Glow + pill, 1 Pill, 2 Panel, 3 Glow only.
 * Having a visible window is also what lets Android allow "open camera" etc. from the background.
 */
class OverlayCard(private val ctx: Context) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var glow: GlowView? = null
    private var pill: FrameLayout? = null
    private var panel: FrameLayout? = null
    private var wave: WaveView? = null
    private var primaryTv: TextView? = null
    private var secondaryTv: TextView? = null
    private var stateTv: TextView? = null
    private var heardTv: TextView? = null
    private var replyTv: TextView? = null
    private var stateDot: View? = null
    private var shownStyle = -1
    private var dismissed = false
    private var gradientColors = GLOW_THEMES[0]

    private val listener: () -> Unit = { update() }

    fun start() {
        AssistantBus.addListener(listener)
    }

    fun stop() {
        AssistantBus.removeListener(listener)
        main.removeCallbacksAndMessages(null)
        hide()
    }

    fun canShow(): Boolean = AppPrefs.floatingCard(ctx) && Settings.canDrawOverlays(ctx)

    private fun update() {
        val s = AssistantBus.state
        val active = s == AState.LISTENING || s == AState.PROCESSING ||
            s == AState.EXECUTING || s == AState.SUCCESS || s == AState.ERROR
        if (!active || !canShow() || AssistantBus.suppressCard) {
            hide()
            if (!active) dismissed = false
            return
        }
        if (dismissed) return
        render(s, AssistantBus.heard, AssistantBus.reply)
    }

    /** Shows a short demo so the user can see the chosen style (used by Settings). */
    fun preview() {
        if (!Settings.canDrawOverlays(ctx)) return
        main.removeCallbacksAndMessages(null)
        hide()
        dismissed = false
        render(AState.LISTENING, "", "")
        main.postDelayed({ render(AState.EXECUTING, "torch on", "Running...") }, 1800)
        main.postDelayed({ render(AState.SUCCESS, "torch on", "Torch on") }, 2800)
        main.postDelayed({ hide() }, 5000)
    }

    private fun render(s: AState, heard: String, reply: String) {
        val style = AppPrefs.cardStyle(ctx)
        val theme = AppPrefs.glowTheme(ctx).coerceIn(0, GLOW_THEMES.size - 1)
        gradientColors = GLOW_THEMES[theme]
        if (shownStyle != -1 && shownStyle != style) hide()
        show(style)
        bind(s, heard, reply)
    }

    // ------------------------------------------------------------ binding

    private fun setGradientText(tv: TextView, text: String) {
        tv.text = text
        val w = tv.paint.measureText(text).coerceAtLeast(1f)
        val cols = gradientColors.copyOf(gradientColors.size - 1)
        tv.paint.shader = LinearGradient(0f, 0f, w, 0f, cols, null, Shader.TileMode.CLAMP)
        tv.invalidate()
    }

    private fun setPlainText(tv: TextView, text: String, color: Int) {
        tv.paint.shader = null
        tv.text = text
        tv.setTextColor(color)
        tv.invalidate()
    }

    private fun bind(s: AState, heard: String, reply: String) {
        val pal = Theme.c
        val colour = when (s) {
            AState.SUCCESS -> pal.success
            AState.ERROR -> pal.error
            else -> pal.accent
        }
        val energy = when (s) {
            AState.LISTENING -> 2
            AState.PROCESSING, AState.EXECUTING -> 1
            else -> 0
        }
        wave?.color = if (s == AState.LISTENING || s == AState.PROCESSING || s == AState.EXECUTING)
            gradientColors[1] else colour
        wave?.energy = energy
        if (s == AState.LISTENING || s == AState.PROCESSING || s == AState.EXECUTING) {
            wave?.run(s == AState.LISTENING)
        } else {
            wave?.stop()
        }

        // ---- pill ----
        val p1 = primaryTv
        val p2 = secondaryTv
        if (p1 != null && p2 != null) {
            val quoted = if (heard.isEmpty()) "" else "“$heard”"
            when (s) {
                AState.LISTENING -> {
                    setGradientText(p1, "Go ahead, I'm listening…")
                    p2.visibility = View.GONE
                }
                AState.PROCESSING, AState.EXECUTING -> {
                    setPlainText(p1, if (quoted.isEmpty()) "Working…" else quoted, pal.text)
                    p2.text = "Working…"
                    p2.setTextColor(pal.text2)
                    p2.visibility = if (quoted.isEmpty()) View.GONE else View.VISIBLE
                }
                AState.SUCCESS -> {
                    setPlainText(p1, reply.ifEmpty { "Done" }, pal.success)
                    p2.text = quoted
                    p2.setTextColor(pal.text2)
                    p2.visibility = if (quoted.isEmpty()) View.GONE else View.VISIBLE
                }
                else -> {
                    setPlainText(p1, reply.ifEmpty { "Sorry, I didn't get that" }, pal.error)
                    p2.text = quoted
                    p2.setTextColor(pal.text2)
                    p2.visibility = if (quoted.isEmpty()) View.GONE else View.VISIBLE
                }
            }
        }

        // ---- panel ----
        val label = when (s) {
            AState.LISTENING -> "Listening"
            AState.PROCESSING -> "Thinking"
            AState.EXECUTING -> "Working"
            AState.SUCCESS -> "Done"
            else -> "Didn't catch that"
        }
        stateTv?.text = label
        (stateDot?.background as? GradientDrawable)?.setColor(colour)
        heardTv?.text = if (heard.isEmpty()) "Say a command" else "“$heard”"
        heardTv?.setTextColor(if (heard.isEmpty()) pal.text2 else pal.text)
        replyTv?.text = reply
        replyTv?.visibility = if (reply.isEmpty() || s == AState.LISTENING) View.GONE else View.VISIBLE
        replyTv?.setTextColor(
            when (s) {
                AState.SUCCESS -> pal.success
                AState.ERROR -> pal.error
                else -> pal.text2
            }
        )
    }

    // ------------------------------------------------------------- windows

    private fun show(style: Int) {
        if (shownStyle == style) return
        Theme.apply(ctx)
        if (style == 0 || style == 3) addGlow()
        when (style) {
            0, 1 -> addPill()
            2 -> addPanel()
        }
        shownStyle = style
    }

    private fun overlayParams(touchable: Boolean, full: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (full) flags = flags or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        flags = flags or if (touchable) WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            MATCH, if (full) MATCH else WRAP,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        )
    }

    private fun addGlow() {
        val g = GlowView(ctx, gradientColors)
        val lp = overlayParams(false, true)
        try {
            wm.addView(g, lp)
        } catch (e: Exception) {
            return
        }
        g.alpha = 0f
        g.animate().alpha(1f).setDuration(280).start()
        g.start()
        glow = g
    }

    private fun addPill() {
        val pal = Theme.c
        val bar = ctx.hbox()
        bar.background = ctx.shape(
            if (pal.dark) 0xF2121A21.toInt() else 0xF2FFFFFF.toInt(), 32f, pal.border, 1
        )
        bar.setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(16), ctx.dp(12))
        bar.elevation = ctx.dpf(10f)

        bar.addView(LogoView(ctx, true), LinearLayout.LayoutParams(ctx.dp(30), ctx.dp(30)))

        val col = ctx.vbox()
        val p1 = ctx.label("", 16f, pal.text, 2)
        p1.maxLines = 1
        p1.ellipsize = android.text.TextUtils.TruncateAt.END
        val p2 = ctx.label("", 12f, pal.text2, 0)
        p2.maxLines = 1
        p2.ellipsize = android.text.TextUtils.TruncateAt.END
        col.addView(p1)
        col.addView(p2, ctx.lpd(t = 1))
        bar.addView(col, ctx.lpd(w = 0, l = 12, r = 8, weight = 1f))

        val w = WaveView(ctx)
        w.bars = 7
        bar.addView(w, LinearLayout.LayoutParams(ctx.dp(52), ctx.dp(26)))

        val frame = FrameLayout(ctx)
        frame.setPadding(ctx.dp(14), 0, ctx.dp(14), 0)
        frame.addView(bar, FrameLayout.LayoutParams(MATCH, WRAP))
        bar.isClickable = true
        bar.setOnClickListener {
            dismissed = true
            hide()
        }

        val lp = overlayParams(true, false)
        lp.gravity = Gravity.BOTTOM
        lp.y = ctx.dp(30)
        try {
            wm.addView(frame, lp)
        } catch (e: Exception) {
            return
        }
        bar.alpha = 0f
        bar.translationY = ctx.dpf(30f)
        bar.animate().alpha(1f).translationY(0f).setDuration(200).start()

        pill = frame
        wave = w
        primaryTv = p1
        secondaryTv = p2
    }

    private fun addPanel() {
        val pal = Theme.c
        val card = ctx.vbox()
        card.background = ctx.shape(pal.surface, 26f, pal.border, 1)
        card.setPadding(ctx.dp(18), ctx.dp(14), ctx.dp(18), ctx.dp(18))
        card.elevation = ctx.dpf(12f)

        val head = ctx.hbox()
        head.addView(LogoView(ctx, true), LinearLayout.LayoutParams(ctx.dp(22), ctx.dp(22)))
        head.addView(ctx.label("FexAi", 13f, pal.text, 2), ctx.lpd(w = WRAP, l = 8))
        head.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
        val dot = ctx.dot(pal.accent)
        val dl = LinearLayout.LayoutParams(ctx.dp(7), ctx.dp(7))
        dl.rightMargin = ctx.dp(6)
        head.addView(dot, dl)
        val st = ctx.label("Listening", 12f, pal.text2, 1)
        head.addView(st)
        card.addView(head, ctx.lpd())

        val w = WaveView(ctx)
        card.addView(w, ctx.lpd(h = ctx.dp(44), t = 10, b = 8))
        val heard = ctx.label("", 20f, pal.text, 2)
        heard.gravity = Gravity.CENTER
        card.addView(heard, ctx.lpd())
        val reply = ctx.label("", 14f, pal.text2, 0)
        reply.gravity = Gravity.CENTER
        card.addView(reply, ctx.lpd(t = 4))

        val frame = FrameLayout(ctx)
        frame.setPadding(ctx.dp(12), 0, ctx.dp(12), 0)
        frame.addView(card, FrameLayout.LayoutParams(MATCH, WRAP))
        card.isClickable = true
        card.setOnClickListener {
            dismissed = true
            hide()
        }

        val lp = overlayParams(true, false)
        lp.gravity = Gravity.BOTTOM
        lp.y = ctx.dp(34)
        try {
            wm.addView(frame, lp)
        } catch (e: Exception) {
            return
        }
        card.alpha = 0f
        card.translationY = ctx.dpf(40f)
        card.animate().alpha(1f).translationY(0f).setDuration(180).start()

        panel = frame
        wave = w
        stateTv = st
        heardTv = heard
        replyTv = reply
        stateDot = dot
    }

    private fun hide() {
        wave?.stop()
        val g = glow
        glow = null
        if (g != null) {
            g.animate().alpha(0f).setDuration(180).withEndAction {
                g.stop()
                try { wm.removeView(g) } catch (e: Exception) { }
            }.start()
        }
        for (v in listOf(pill, panel)) {
            if (v != null) {
                try { wm.removeView(v) } catch (e: Exception) { }
            }
        }
        pill = null
        panel = null
        wave = null
        primaryTv = null
        secondaryTv = null
        stateTv = null
        heardTv = null
        replyTv = null
        stateDot = null
        shownStyle = -1
    }

    companion object {
        val STYLE_NAMES = listOf("Glow pill", "Pill", "Panel", "Glow")
        val THEME_NAMES = listOf("Aurora", "Lime", "Ocean")

        /** First colour must equal the last so the sweep loops smoothly. */
        val GLOW_THEMES: List<IntArray> = listOf(
            intArrayOf(
                Color.parseColor("#4F8CFF"), Color.parseColor("#A06BFF"),
                Color.parseColor("#FF6FA8"), Color.parseColor("#FFB86B"),
                Color.parseColor("#4F8CFF")
            ),
            intArrayOf(
                Color.parseColor("#B8F34A"), Color.parseColor("#55D69E"),
                Color.parseColor("#4FD1E8"), Color.parseColor("#D7FF7A"),
                Color.parseColor("#B8F34A")
            ),
            intArrayOf(
                Color.parseColor("#4FD1E8"), Color.parseColor("#4F8CFF"),
                Color.parseColor("#8A6BFF"), Color.parseColor("#4FE8C2"),
                Color.parseColor("#4FD1E8")
            )
        )
    }
}
