package com.felix.microassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class WakeWordService : Service() {

    private var porcupine: PorcupineManager? = null
    private var wakeCount = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        createChannel()
        val notification = buildNotification("Starting...")
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(
                    NOTIF_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIF_ID, notification)
            }
        } catch (e: Exception) {
            setStatus("Could not start in background: ${e.message}. Open the app and tap Start.")
            stopSelf()
            return START_NOT_STICKY
        }

        if (porcupine == null) startPorcupine()
        return START_STICKY
    }

    private fun startPorcupine() {
        val key = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ACCESS, "")?.trim().orEmpty()
        if (key.isEmpty()) {
            setStatus("No AccessKey saved. Paste it in the app first.")
            stopSelf()
            return
        }
        try {
            porcupine = PorcupineManager.Builder()
                .setAccessKey(key)
                .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .setSensitivity(0.7f)
                .build(applicationContext, PorcupineManagerCallback { _ -> onWakeWord() })
            porcupine?.start()
            setStatus("Listening. Say \"Jarvis\"")
            updateNotification("Listening for \"Jarvis\"")
        } catch (e: Exception) {
            setStatus("Error: ${e.message}")
            stopSelf()
        }
    }

    private fun onWakeWord() {
        wakeCount++
        vibrate()
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        setStatus("Heard \"Jarvis\" x$wakeCount (last at $time)")
        updateNotification("Heard \"Jarvis\" x$wakeCount")
    }

    @Suppress("DEPRECATION")
    private fun vibrate() {
        try {
            val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager)
                    .defaultVibrator
            } else {
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            vibrator.vibrate(
                VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE)
            )
        } catch (e: Exception) {
        }
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "Assistant listening", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Micro Assistant")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildNotification(text))
    }

    private fun setStatus(text: String) {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_STATUS, text).apply()
    }

    override fun onDestroy() {
        try {
            porcupine?.stop()
            porcupine?.delete()
        } catch (e: Exception) {
        }
        porcupine = null
        if (getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_STATUS, "")?.startsWith("Listening") == true ||
            getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_STATUS, "")?.startsWith("Heard") == true
        ) {
            setStatus("Stopped")
        }
        super.onDestroy()
    }

    companion object {
        const val PREFS = "micro"
        const val KEY_ACCESS = "access_key"
        const val KEY_STATUS = "status"
        const val ACTION_STOP = "com.felix.microassistant.STOP"
        private const val CHANNEL_ID = "listening"
        private const val NOTIF_ID = 1
    }
}
