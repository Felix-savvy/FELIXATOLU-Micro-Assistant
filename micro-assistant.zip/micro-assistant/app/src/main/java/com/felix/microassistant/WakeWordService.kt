package com.felix.microassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import org.vosk.Model
import org.vosk.Recognizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class WakeWordService : Service() {

    @Volatile private var running = false
    private var worker: Thread? = null
    private var wakeCount = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            running = false
            stopSelf()
            return START_NOT_STICKY
        }

        createChannel()
        val notification = buildNotification("Starting...")
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(
                    NOTIF_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIF_ID, notification)
            }
        } catch (e: Exception) {
            setStatus("Could not start in background: ${e.message}. Open the app and tap Start.")
            stopSelf()
            return START_NOT_STICKY
        }

        if (worker == null) {
            running = true
            worker = Thread { runLoop() }.also { it.start() }
        }
        return START_STICKY
    }

    private fun runLoop() {
        var model: Model? = null
        var rec: Recognizer? = null
        var audio: AudioRecord? = null
        var failed = false
        try {
            val modelDir = ModelDownloader.ensureModel(this) { msg ->
                setStatus(msg)
                updateNotification(msg)
            }
            if (!running) return

            setStatus("Loading speech model...")
            model = Model(modelDir.absolutePath)
            // Only listen for the wake word. Everything else is ignored.
            rec = Recognizer(model, SAMPLE_RATE.toFloat(), "[\"$WAKE_WORD\", \"[unk]\"]")

            val minBuf = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            audio = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, 8192)
            )
            if (audio.state != AudioRecord.STATE_INITIALIZED) {
                throw IllegalStateException("Microphone could not start (is another app using it?)")
            }
            audio.startRecording()

            setStatus("Listening. Say \"$WAKE_WORD\"")
            updateNotification("Listening for \"$WAKE_WORD\"")

            val buf = ShortArray(2048)
            var lastHit = 0L
            while (running) {
                val n = audio.read(buf, 0, buf.size)
                if (n <= 0) continue
                val done = rec.acceptWaveForm(buf, n)
                val json = if (done) rec.result else rec.partialResult
                val now = System.currentTimeMillis()
                if (json.contains(WAKE_WORD) && now - lastHit > 2000) {
                    lastHit = now
                    onWakeWord()
                    rec.reset()
                }
            }
        } catch (e: Throwable) {
            failed = true
            setStatus("Error: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            try { audio?.stop() } catch (e: Throwable) { }
            try { audio?.release() } catch (e: Throwable) { }
            try { rec?.close() } catch (e: Throwable) { }
            try { model?.close() } catch (e: Throwable) { }
            if (!failed) setStatus("Stopped")
            running = false
            worker = null
            stopSelf()
        }
    }

    private fun onWakeWord() {
        wakeCount++
        vibrate()
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        setStatus("Heard \"$WAKE_WORD\" x$wakeCount (last at $time)")
        updateNotification("Heard \"$WAKE_WORD\" x$wakeCount")
    }

    @Suppress("DEPRECATION")
    private fun vibrate() {
        try {
            val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager)
                    .defaultVibrator
            } else {
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            vibrator.vibrate(
                VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE)
            )
        } catch (e: Exception) {
        }
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "Assistant listening", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Micro Assistant")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildNotification(text))
    }

    private fun setStatus(text: String) {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_STATUS, text).apply()
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    companion object {
        const val PREFS = "micro"
        const val KEY_STATUS = "status"
        const val ACTION_STOP = "com.felix.microassistant.STOP"
        const val WAKE_WORD = "computer"
        private const val SAMPLE_RATE = 16000
        private const val CHANNEL_ID = "listening"
        private const val NOTIF_ID = 1
    }
}
