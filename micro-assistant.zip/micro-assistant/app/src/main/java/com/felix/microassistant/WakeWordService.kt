package com.felix.microassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.util.Locale

class WakeWordService : Service() {

    @Volatile private var running = false
    @Volatile private var ttsReady = false
    @Volatile private var manualRequest = false
    private var worker: Thread? = null
    private var tts: TextToSpeech? = null
    private var tone: ToneGenerator? = null
    private lateinit var runner: CommandRunner
    private var wakeCount = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.ENGLISH
                ttsReady = true
            }
        }
        runner = CommandRunner(applicationContext) { text -> speak(text) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            running = false
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_MANUAL) {
            // The mic button on Home: behave as if the wake word was just heard.
            manualRequest = true
            return START_STICKY
        }

        createChannels()
        val notification = buildNotification("Starting...")
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(
                    NOTIF_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIF_ID, notification)
            }
        } catch (e: Exception) {
            setStatus("Could not start in background: ${e.message}. Open the app and tap Start.")
            AssistantBus.update(state = AState.STOPPED)
            stopSelf()
            return START_NOT_STICKY
        }

        if (worker == null) {
            running = true
            AssistantBus.serviceRunning = true
            AssistantBus.update(state = AState.LOADING, detail = "Starting...")
            worker = Thread { runLoop() }.also { it.start() }
        }
        return START_STICKY
    }

    private fun runLoop() {
        var model: Model? = null
        var wakeRec: Recognizer? = null
        var cmdRec: Recognizer? = null
        var audio: AudioRecord? = null
        var failed = false
        try {
            val modelDir = ModelDownloader.ensureModel(this) { msg ->
                setStatus(msg)
                updateNotification(msg)
            }
            if (!running) return

            setStatus("Loading speech model...")
            model = Model(modelDir.absolutePath)
            // Two recognisers share one model: one only knows the wake word,
            // the other only knows the command phrases.
            wakeRec = Recognizer(model, SAMPLE_RATE.toFloat(), "[\"$WAKE_WORD\", \"[unk]\"]")
            cmdRec = Recognizer(model, SAMPLE_RATE.toFloat(), CommandRunner.grammarJson())
            cmdRec.setWords(true) // gives a confidence score per word
            tone = ToneGenerator(AudioManager.STREAM_MUSIC, 80)

            val minBuf = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            audio = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, 8192)
            )
            if (audio.state != AudioRecord.STATE_INITIALIZED) {
                throw IllegalStateException("Microphone could not start (is another app using it?)")
            }
            audio.startRecording()

            setStatus("Listening. Say \"$WAKE_WORD\"")
            updateNotification("Listening for \"$WAKE_WORD\"")
            AssistantBus.update(state = AState.WAITING)

            val buf = ShortArray(2048)
            var lastHit = 0L
            while (running) {
                if (manualRequest) {
                    manualRequest = false
                    runSession(audio, cmdRec, buf)
                    wakeRec.reset()
                    lastHit = System.currentTimeMillis()
                    continue
                }
                val n = audio.read(buf, 0, buf.size)
                if (n <= 0) continue
                // Only trust FINAL results (after you finish the word).
                if (!wakeRec.acceptWaveForm(buf, n)) continue
                val json = wakeRec.result
                val now = System.currentTimeMillis()
                if (json.contains("\"$WAKE_WORD\"") && now - lastHit > 2000) {
                    wakeCount++
                    runSession(audio, cmdRec, buf)
                    wakeRec.reset()
                    lastHit = System.currentTimeMillis()
                }
            }
        } catch (e: Throwable) {
            failed = true
            val msg = "Error: ${e.message ?: e.javaClass.simpleName}"
            setStatus(msg)
            AssistantBus.update(state = AState.STOPPED, detail = msg)
        } finally {
            try { audio?.stop() } catch (e: Throwable) { }
            try { audio?.release() } catch (e: Throwable) { }
            try { wakeRec?.close() } catch (e: Throwable) { }
            try { cmdRec?.close() } catch (e: Throwable) { }
            try { model?.close() } catch (e: Throwable) { }
            try { tone?.release() } catch (e: Throwable) { }
            tone = null
            if (!failed) {
                setStatus("Stopped")
                AssistantBus.update(state = AState.STOPPED)
            }
            running = false
            worker = null
            AssistantBus.serviceRunning = false
            stopSelf()
        }
    }

    /** One wake -> beep -> listen -> run cycle. Used by the wake word and by the mic button. */
    private fun runSession(audio: AudioRecord, cmdRec: Recognizer, buf: ShortArray) {
        signal()
        AssistantBus.update(state = AState.LISTENING, heard = "", reply = "Listening for a command...")
        drain(audio, buf, 450) // ignore our own beep
        handleCommand(audio, cmdRec, buf)
    }

    /** Throw away audio for a short time (so the beep isn't mistaken for speech). */
    private fun drain(audio: AudioRecord, buf: ShortArray, ms: Long) {
        val end = System.currentTimeMillis() + ms
        while (running && System.currentTimeMillis() < end) {
            audio.read(buf, 0, buf.size)
        }
    }

    /** Listen up to COMMAND_WINDOW_MS for ONE command, run it, then go back to the wake word. */
    private fun handleCommand(audio: AudioRecord, cmdRec: Recognizer, buf: ShortArray) {
        setStatus("Listening for a command...")
        updateNotification("Say a command now")

        cmdRec.reset()
        val end = System.currentTimeMillis() + COMMAND_WINDOW_MS
        var json: String? = null
        while (running && System.currentTimeMillis() < end) {
            val n = audio.read(buf, 0, buf.size)
            if (n <= 0) continue
            if (cmdRec.acceptWaveForm(buf, n)) {
                json = cmdRec.result // you finished speaking
                break
            }
        }
        if (json == null) json = cmdRec.finalResult // time ran out

        AssistantBus.update(state = AState.PROCESSING)

        val result = try { JSONObject(json) } catch (e: Exception) { JSONObject() }
        val text = result.optString("text").trim()
        var conf = 0.0
        val words = result.optJSONArray("result")
        if (words != null && words.length() > 0) {
            var sum = 0.0
            for (i in 0 until words.length()) sum += words.getJSONObject(i).optDouble("conf", 0.0)
            conf = sum / words.length()
        }
        val confTxt = String.format(Locale.US, "%.2f", conf)
        val command = CommandRunner.PHRASES[text]

        var ok = false
        var heardShown = text
        val replyShown: String
        val logResult: String
        val summary: String

        if (text.isEmpty()) {
            heardShown = ""
            summary = "No command heard"
            replyShown = "Sorry, I didn't get that."
            logResult = "No command heard"
        } else if (text.contains("[unk]") || command == null) {
            heardShown = text.replace("[unk]", "...").trim()
            summary = "Didn't understand \"$text\" (conf $confTxt)"
            replyShown = "Sorry, I didn't get that."
            logResult = "Not understood"
        } else if (conf < MIN_CONFIDENCE) {
            summary = "Not sure: \"$text\" (conf $confTxt, need $MIN_CONFIDENCE)"
            replyShown = "I wasn't sure. Please say it again."
            logResult = "Low confidence ($confTxt)"
        } else {
            AssistantBus.update(state = AState.EXECUTING, heard = text, reply = "Running...")
            val done = runner.run(command)
            ok = !CommandRunner.looksFailed(done)
            summary = "\"$text\" -> $done (conf $confTxt)"
            replyShown = done
            logResult = done
        }

        setStatus(summary)
        updateNotification(summary)
        HistoryStore.add(
            applicationContext,
            if (heardShown.isEmpty()) "(nothing heard)" else heardShown,
            logResult,
            ok
        )
        AssistantBus.update(
            state = if (ok) AState.SUCCESS else AState.ERROR,
            heard = heardShown,
            reply = replyShown
        )
        AssistantBus.settleLater()
    }

    /** Beep + vibrate so you know it heard you. */
    private fun signal() {
        try { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 150) } catch (e: Exception) { }
        vibrate()
    }

    @Suppress("DEPRECATION")
    private fun vibrate() {
        try {
            val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager)
                    .defaultVibrator
            } else {
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            val effect = VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE)
            // ALARM usage so silent / Do Not Disturb modes are less likely to block it
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            vibrator.vibrate(effect, attrs)
        } catch (e: Exception) {
        }
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "assistant")
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Assistant listening", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(
                CommandRunner.LAUNCH_CHANNEL, "Open app prompts", NotificationManager.IMPORTANCE_HIGH
            )
        )
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("FexAi Assistant")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildNotification(text))
    }

    private fun setStatus(text: String) {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_STATUS, text).apply()
        AssistantBus.update(detail = text)
    }

    override fun onDestroy() {
        running = false
        try { tts?.stop(); tts?.shutdown() } catch (e: Exception) { }
        tts = null
        super.onDestroy()
    }

    companion object {
        const val PREFS = "micro"
        const val KEY_STATUS = "status"
        const val ACTION_STOP = "com.felix.microassistant.STOP"
        const val ACTION_MANUAL = "com.felix.microassistant.MANUAL"
        const val WAKE_WORD = "computer"
        const val COMMAND_WINDOW_MS = 4000L
        const val MIN_CONFIDENCE = 0.6
        private const val SAMPLE_RATE = 16000
        private const val CHANNEL_ID = "listening"
        private const val NOTIF_ID = 1
    }
}
