package com.felix.microassistant

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.text.InputType
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class SettingsScreen(act: MainActivity) : Screen(act) {

    private val menuPage = 0
    private val appearancePage = 1
    private val assistantPage = 2
    private val aboutPage = 3
    private val voicePage = 4
    private val cardPage = 5
    private val chips = ArrayList<TextView>()

    private var page = menuPage
    private lateinit var scroll: ScrollView
    private lateinit var body: LinearLayout
    private var permBox: LinearLayout? = null
    private var serviceBtnBox: LinearLayout? = null

    override val view: View by lazy { build() }

    private fun build(): View {
        val ctx: Context = act
        body = ctx.vbox()
        body.setPadding(ctx.dp(20), ctx.dp(20), ctx.dp(20), ctx.dp(24))
        scroll = ScrollView(ctx)
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(body)
        showPage(menuPage)
        return scroll
    }

    /** Called by MainActivity on Back. Returns true if it handled it. */
    fun handleBack(): Boolean {
        if (page != menuPage) {
            showPage(menuPage)
            return true
        }
        return false
    }

    private fun showPage(p: Int) {
        page = p
        permBox = null
        serviceBtnBox = null
        body.removeAllViews()
        when (p) {
            appearancePage -> buildAppearance()
            assistantPage -> buildAssistant()
            aboutPage -> buildAbout()
            voicePage -> buildVoice()
            cardPage -> buildCard()
            else -> buildMenu()
        }
        scroll.scrollTo(0, 0)
    }

    // ------------------------------------------------------------ menu

    private fun buildMenu() {
        val ctx: Context = act
        val pal = Theme.c
        body.addView(ctx.label("Settings", 26f, pal.text, 2), ctx.lpd(b = 14))
        menuRow("Voice & wake word", "Wake word, spoken replies, follow-up") { showPage(voicePage) }
        menuRow("Floating card", "Pop-up over other apps") { showPage(cardPage) }
        menuRow("Appearance", "Theme and logo") { showPage(appearancePage) }
        menuRow("Assistant & permissions", "Service, microphone, special access") { showPage(assistantPage) }
        menuRow("About", "Version and welcome tour") { showPage(aboutPage) }

        val soon = ctx.card(16)
        soon.addView(ctx.label("Coming soon", 13f, pal.text2, 1))
        soon.addView(
            ctx.label(
                "Online AI  \u00B7  My commands  \u00B7  Voice choice  \u00B7  Only my voice",
                13f, pal.text2, 0
            ),
            ctx.lpd(t = 4)
        )
        body.addView(soon, ctx.lpd(t = 14))
    }

    private fun menuRow(name: String, desc: String, onClick: () -> Unit) {
        val ctx: Context = act
        val pal = Theme.c
        val row = ctx.hbox()
        row.background = ctx.pressable(pal.surface, 16f, pal.border, 1)
        row.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(10), ctx.dp(14))
        row.isClickable = true
        row.setOnClickListener { onClick() }
        val text = ctx.vbox()
        text.addView(ctx.label(name, 16f, pal.text, 1))
        text.addView(ctx.label(desc, 12f, pal.text2, 0), ctx.lpd(t = 2))
        row.addView(text, ctx.lpd(w = 0, weight = 1f))
        row.addView(GlyphView(ctx, G.CHEVRON, pal.text2), LinearLayout.LayoutParams(ctx.dp(24), ctx.dp(24)))
        body.addView(row, ctx.lpd(b = 8))
    }

    private fun subHeader(title: String) {
        val ctx: Context = act
        val pal = Theme.c
        val row = ctx.hbox()
        val back = GlyphView(ctx, G.CHEVRON, pal.text)
        back.rotation = 180f
        back.isClickable = true
        back.contentDescription = "Back"
        back.setOnClickListener { showPage(menuPage) }
        row.addView(back, LinearLayout.LayoutParams(ctx.dp(40), ctx.dp(40)))
        row.addView(ctx.label(title, 22f, pal.text, 2), ctx.lpd(w = WRAP, l = 4))
        body.addView(row, ctx.lpd(b = 12))
    }

    // ------------------------------------------------------ appearance

    private fun buildAppearance() {
        val ctx: Context = act
        val pal = Theme.c
        subHeader("Appearance")
        val seg = ctx.hbox()
        seg.background = ctx.shape(pal.surface, 14f, pal.border, 1)
        seg.setPadding(ctx.dp(4), ctx.dp(4), ctx.dp(4), ctx.dp(4))
        val current = Theme.mode(ctx)
        val names = listOf("Dark", "Light", "System")
        for (i in names.indices) {
            val selected = i == current
            val b = ctx.label(names[i], 14f, if (selected) pal.onAccent else pal.text, if (selected) 2 else 1)
            b.gravity = Gravity.CENTER
            b.setPadding(0, ctx.dp(10), 0, ctx.dp(10))
            b.background = if (selected) ctx.pressable(pal.accent, 11f) else ctx.pressable(0x00000000, 11f)
            b.isClickable = true
            b.setOnClickListener {
                if (i != Theme.mode(ctx)) {
                    Theme.setMode(ctx, i)
                    act.recreate()
                }
            }
            seg.addView(b, ctx.lpd(w = 0, weight = 1f))
        }
        body.addView(seg, ctx.lpd())

        body.addView(ctx.label("Logo (inside the app)", 14f, pal.text, 2), ctx.lpd(t = 22, b = 10))
        val tiles = ctx.hbox()
        val names3 = listOf("Signal F", "Aperture", "Voice F")
        val chosen = AppPrefs.logo(ctx)
        for (i in names3.indices) {
            val box = ctx.vbox()
            box.gravity = Gravity.CENTER_HORIZONTAL
            box.setPadding(ctx.dp(8), ctx.dp(12), ctx.dp(8), ctx.dp(10))
            box.background = if (i == chosen) ctx.shape(withAlpha(pal.accent, 30), 16f, pal.accent, 2)
            else ctx.shape(pal.surface, 16f, pal.border, 1)
            box.isClickable = true
            val lv = LogoView(ctx, true)
            lv.style = i
            box.addView(lv, LinearLayout.LayoutParams(ctx.dp(64), ctx.dp(64)))
            box.addView(ctx.label(names3[i], 12f, if (i == chosen) pal.accent else pal.text, 1), ctx.lpd(w = WRAP, t = 8))
            box.setOnClickListener {
                if (i != AppPrefs.logo(ctx)) {
                    AppPrefs.setLogo(ctx, i)
                    act.recreate()
                }
            }
            tiles.addView(box, ctx.lpd(w = 0, l = if (i == 0) 0 else 4, r = if (i == 2) 0 else 4, weight = 1f))
        }
        body.addView(tiles, ctx.lpd())
        body.addView(
            ctx.label("The home-screen app icon stays the Signal F for now.", 12f, pal.text2, 0),
            ctx.lpd(t = 10)
        )
    }

    // ------------------------------------------------------ floating card

    private fun buildCard() {
        val ctx: Context = act
        val pal = Theme.c
        subHeader("Floating card")
        body.addView(
            ctx.label(
                "A small card appears over any app while FexAi listens and answers. " +
                    "It also lets \"open camera\" and \"open WhatsApp\" work straight from the background.",
                13f, pal.text2, 0
            ),
            ctx.lpd(b = 14)
        )

        val granted = android.provider.Settings.canDrawOverlays(ctx)
        val row = ctx.hbox()
        row.background = ctx.shape(pal.surface, 16f, pal.border, 1)
        row.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(12), ctx.dp(14))
        val text = ctx.vbox()
        val top = ctx.hbox()
        val dl = LinearLayout.LayoutParams(ctx.dp(8), ctx.dp(8))
        dl.rightMargin = ctx.dp(8)
        top.addView(ctx.dot(if (granted) pal.success else pal.warning), dl)
        top.addView(ctx.label("Display over other apps", 15f, pal.text, 1))
        text.addView(top)
        text.addView(ctx.label("Android permission this card needs.", 12f, pal.text2, 0), ctx.lpd(t = 3))
        row.addView(text, ctx.lpd(w = 0, weight = 1f))
        if (!granted) {
            val b = ctx.button("Allow", false) {
                open(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + ctx.packageName)
                    )
                )
            }
            b.setPadding(ctx.dp(14), ctx.dp(8), ctx.dp(14), ctx.dp(8))
            row.addView(b, ctx.lpd(w = WRAP, l = 8))
        } else {
            row.addView(ctx.tag("On", pal.success, withAlpha(pal.success, 36)), ctx.lpd(w = WRAP, l = 8))
        }
        body.addView(row, ctx.lpd())

        body.addView(ctx.label("Show the card", 14f, pal.text, 2), ctx.lpd(t = 22, b = 8))
        chipsRow(listOf("On", "Off"), if (AppPrefs.floatingCard(ctx)) 0 else 1) { i ->
            AppPrefs.setFloatingCard(ctx, i == 0)
        }
        body.addView(
            ctx.label(
                "Tap the card to put it away. It doesn't show on the lock screen yet.",
                12f, pal.text2, 0
            ),
            ctx.lpd(t = 14)
        )
    }

    override fun onShow() {
        super.onShow()
        // coming back from the permission screen: redraw the card page so the status is fresh
        if (page == cardPage && this::body.isInitialized) showPage(cardPage)
    }

    // ---------------------------------------------------- voice & wake

    private fun buildVoice() {
        val ctx: Context = act
        val pal = Theme.c
        subHeader("Voice & wake word")

        // ---- wake word ----
        body.addView(ctx.label("Wake word", 14f, pal.text, 2), ctx.lpd(b = 4))
        val currentWake = AppPrefs.wakeWord(ctx)
        val status = ctx.label("Now: \"$currentWake\"", 13f, pal.text2, 0)
        body.addView(status, ctx.lpd(b = 8))

        val input = EditText(ctx)
        input.setText(currentWake)
        input.setSingleLine(true)
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        input.setTextColor(pal.text)
        input.setHintTextColor(pal.text2)
        input.hint = "one or two words"
        input.textSize = 16f
        input.setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
        input.background = ctx.shape(pal.surface, 14f, pal.border, 1)
        body.addView(input, ctx.lpd())

        val msg = ctx.label("", 12f, pal.text2, 0)
        val save = ctx.button("Save wake word", true) {
            val w = AppPrefs.clean(input.text.toString())
            if (w.isEmpty() || w.split(" ").size > 3) {
                msg.setTextColor(pal.error)
                msg.text = "Use one to three plain words."
            } else {
                val known = AppPrefs.inVocabulary(ctx, w)
                if (known == false) {
                    msg.setTextColor(pal.error)
                    msg.text = "\"$w\" is not in the offline speech model, so it can't be heard. Try a common English word."
                } else {
                    AppPrefs.setWakeWord(ctx, w)
                    status.text = "Now: \"$w\""
                    input.setText(w)
                    msg.setTextColor(pal.success)
                    msg.text = if (AssistantBus.serviceRunning) "Saved. Restarting the assistant..." else "Saved."
                    act.restartAssistant()
                }
            }
        }
        body.addView(save, ctx.lpd(t = 10))
        body.addView(msg, ctx.lpd(t = 8))
        body.addView(
            ctx.label(
                "Longer, distinctive words (2+ syllables) work best. Very short words trigger by mistake.",
                12f, pal.text2, 0
            ),
            ctx.lpd(t = 4)
        )

        // ---- spoken replies ----
        body.addView(ctx.label("Spoken replies", 14f, pal.text, 2), ctx.lpd(t = 24, b = 4))
        body.addView(
            ctx.label("Says \"Yes?\" when it wakes, and confirms what it did. Off means beep only.", 12f, pal.text2, 0),
            ctx.lpd(b = 8)
        )
        val voiceOn = AppPrefs.voiceReplies(ctx)
        chipsRow(listOf("On", "Off"), if (voiceOn) 0 else 1) { i ->
            AppPrefs.setVoiceReplies(ctx, i == 0)
            if (AssistantBus.serviceRunning) act.restartAssistant()
        }

        // ---- follow-up ----
        body.addView(ctx.label("Follow-up window", 14f, pal.text, 2), ctx.lpd(t = 24, b = 4))
        body.addView(
            ctx.label("After a command it keeps listening, so you don't repeat the wake word.", 12f, pal.text2, 0),
            ctx.lpd(b = 8)
        )
        val opts = listOf(0, 5, 8, 12)
        val cur = opts.indexOf(AppPrefs.followUpSec(ctx)).let { if (it < 0) 2 else it }
        chipsRow(listOf("Off", "5 s", "8 s", "12 s"), cur) { i ->
            AppPrefs.setFollowUpSec(ctx, opts[i])
            if (AssistantBus.serviceRunning) act.restartAssistant()
        }
    }

    /** A row of single-choice chips. */
    private fun chipsRow(names: List<String>, selected: Int, onPick: (Int) -> Unit) {
        val ctx: Context = act
        val row = ctx.hbox()
        val mine = ArrayList<TextView>()
        for (i in names.indices) {
            val chip = ctx.chipView(names[i])
            ctx.styleChip(chip, i == selected)
            chip.setOnClickListener {
                for (k in mine.indices) ctx.styleChip(mine[k], k == i)
                onPick(i)
            }
            mine.add(chip)
            row.addView(chip, ctx.lpd(w = WRAP, r = 8))
        }
        body.addView(row, ctx.lpd())
    }

    // ------------------------------------------------------- assistant

    private fun buildAssistant() {
        val ctx: Context = act
        val pal = Theme.c
        subHeader("Assistant & permissions")
        body.addView(ctx.label("Service", 14f, pal.text, 2), ctx.lpd(b = 10))
        val sb = ctx.vbox()
        serviceBtnBox = sb
        body.addView(sb, ctx.lpd())
        body.addView(ctx.label("Permissions", 14f, pal.text, 2), ctx.lpd(t = 22, b = 10))
        val pb = ctx.vbox()
        permBox = pb
        body.addView(pb, ctx.lpd())
        rebuildDynamic()
    }

    // ----------------------------------------------------------- about

    private fun buildAbout() {
        val ctx: Context = act
        val pal = Theme.c
        subHeader("About")
        val about = ctx.card(16)
        about.addView(ctx.label("FexAi Assistant", 16f, pal.text, 2))
        about.addView(ctx.label("Version " + versionName(), 13f, pal.text2, 0), ctx.lpd(t = 2))
        about.addView(
            ctx.label(
                "Offline speech recognition by Vosk (small English model). " +
                    "Your voice is processed on this phone.",
                13f, pal.text2, 0
            ),
            ctx.lpd(t = 8)
        )
        body.addView(about, ctx.lpd())
        body.addView(ctx.button("Replay welcome tour", false) { act.restartOnboarding() }, ctx.lpd(t = 12))
    }

    private fun versionName(): String = try {
        act.packageManager.getPackageInfo(act.packageName, 0).versionName ?: "?"
    } catch (e: Exception) {
        "?"
    }

    // ----------------------------------------------- permission helpers

    private fun permRow(name: String, why: String, granted: Boolean, action: String, onClick: () -> Unit) {
        val ctx: Context = act
        val pal = Theme.c
        val box = permBox ?: return
        val card = ctx.hbox()
        card.background = ctx.shape(pal.surface, 16f, pal.border, 1)
        card.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(12), ctx.dp(14))

        val text = ctx.vbox()
        val top = ctx.hbox()
        val dotLp = LinearLayout.LayoutParams(ctx.dp(8), ctx.dp(8))
        dotLp.rightMargin = ctx.dp(8)
        top.addView(ctx.dot(if (granted) pal.success else pal.warning), dotLp)
        top.addView(ctx.label(name, 15f, pal.text, 1))
        text.addView(top)
        text.addView(ctx.label(why, 12f, pal.text2, 0), ctx.lpd(t = 3))
        card.addView(text, ctx.lpd(w = 0, weight = 1f))

        if (!granted) {
            val b = ctx.button(action, false, onClick)
            b.setPadding(ctx.dp(14), ctx.dp(8), ctx.dp(14), ctx.dp(8))
            card.addView(b, ctx.lpd(w = WRAP, l = 8))
        } else {
            card.addView(ctx.tag("On", pal.success, withAlpha(pal.success, 36)), ctx.lpd(w = WRAP, l = 8))
        }
        box.addView(card, ctx.lpd(b = 8))
    }

    private fun open(intent: Intent) {
        try {
            act.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(act, "Open Android Settings > Apps > FexAi Assistant", Toast.LENGTH_LONG).show()
        }
    }

    // Statuses are re-read every time the tab shows or the bus changes.
    override fun refresh() {
        if (page == assistantPage && permBox != null) rebuildDynamic()
    }

    private fun rebuildServiceButtons() {
        val ctx: Context = act
        val box = serviceBtnBox ?: return
        box.removeAllViews()
        val b = if (AssistantBus.serviceRunning) {
            ctx.button("Stop assistant", false) { act.stopListening() }
        } else {
            ctx.button("Start assistant", true) { act.startListening() }
        }
        box.addView(b, ctx.lpd())
    }

    private fun rebuildDynamic() {
        val ctx: Context = act
        val box = permBox ?: return
        rebuildServiceButtons()
        box.removeAllViews()

        val mic = ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        permRow("Microphone", "Needed to hear the wake word.", mic, "Allow") { act.requestBasics() }

        if (Build.VERSION.SDK_INT >= 33) {
            val notif = ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            permRow("Notifications", "Keeps the listening service visible and running.", notif, "Allow") { act.requestBasics() }
        }

        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val battery = pm.isIgnoringBatteryOptimizations(ctx.packageName)
        permRow("Run in background", "Set battery to unrestricted so Android doesn't stop it.", battery, "Open") {
            open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }

        permRow("Accessibility (optional)", "Back, home, recents, screenshot, lock screen by voice.", Access.accessibilityOn(ctx), "Open") {
            open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        permRow("Notification access (optional)", "Only used for \"clear notifications\".", Access.notificationsOn(ctx), "Open") {
            open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        if (Build.VERSION.SDK_INT >= 34) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            val full = nm.canUseFullScreenIntent()
            permRow("Full-screen prompts (optional)", "Helps \"open camera\" and \"open WhatsApp\" appear from the background.", full, "Allow") {
                open(
                    Intent(
                        Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                        Uri.parse("package:" + ctx.packageName)
                    )
                )
            }
        }
        // Help for the "greyed out" switch on sideloaded apps (Android 13+)
        val tip = ctx.card(16)
        val pal2 = Theme.c
        tip.addView(ctx.label("Switch greyed out or blocked?", 14f, pal2.text, 2))
        tip.addView(
            ctx.label(
                "Android blocks Accessibility and Notification access for apps installed outside the Play Store. " +
                    "Tap the button, then the three dots at the top right, then \"Allow restricted settings\". " +
                    "Come back here and turn the switch on.",
                12f, pal2.text2, 0
            ),
            ctx.lpd(t = 6)
        )
        tip.addView(
            ctx.button("Open app info", false) {
                open(
                    Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + ctx.packageName)
                    )
                )
            },
            ctx.lpd(t = 12)
        )
        box.addView(tip, ctx.lpd(t = 4))
    }
}
