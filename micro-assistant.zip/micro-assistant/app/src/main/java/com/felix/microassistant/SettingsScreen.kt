package com.felix.microassistant

import android.Manifest
import android.app.NotificationManager
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.text.InputType
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class SettingsScreen(act: MainActivity) : Screen(act) {

    private val menuPage = 0
    private val appearancePage = 1
    private val assistantPage = 2
    private val aboutPage = 3
    private val voicePage = 4
    private val cardPage = 5
    private val myCmdPage = 6
    private val addCmdPage = 7
    private val appsPage = 8
    private val callsPage = 9
    private val chips = ArrayList<TextView>()
    private var previewCard: OverlayCard? = null

    private var page = menuPage
    private lateinit var scroll: ScrollView
    private lateinit var body: LinearLayout
    private var permBox: LinearLayout? = null
    private var serviceBtnBox: LinearLayout? = null

    override val view: View by lazy { build() }

    private fun build(): View {
        val ctx: Context = act
        body = ctx.vbox()
        body.setPadding(ctx.dp(20), ctx.dp(20), ctx.dp(20), ctx.dp(24))
        scroll = ScrollView(ctx)
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(body)
        showPage(menuPage)
        return scroll
    }

    /** Called by MainActivity on Back. Returns true if it handled it. */
    fun handleBack(): Boolean {
        if (page == addCmdPage) {
            showPage(myCmdPage)
            return true
        }
        if (page != menuPage) {
            showPage(menuPage)
            return true
        }
        return false
    }

    fun openPage(p: Int) {
        if (this::body.isInitialized) showPage(p)
    }

    private fun showPage(p: Int) {
        page = p
        permBox = null
        serviceBtnBox = null
        body.removeAllViews()
        when (p) {
            appearancePage -> buildAppearance()
            assistantPage -> buildAssistant()
            aboutPage -> buildAbout()
            voicePage -> buildVoice()
            cardPage -> buildCard()
            myCmdPage -> buildMyCommands()
            addCmdPage -> buildAddCmd()
            appsPage -> buildApps()
            callsPage -> buildCalls()
            else -> buildMenu()
        }
        scroll.scrollTo(0, 0)
    }

    // ------------------------------------------------------------ menu

    private fun buildMenu() {
        val ctx: Context = act
        val pal = Theme.c
        body.addView(ctx.label("Settings", 26f, pal.text, 2), ctx.lpd(b = 14))
        menuRow("Voice & wake word", "Wake word, spoken replies, follow-up") { showPage(voicePage) }
        menuRow("Floating card", "Pop-up over other apps") { showPage(cardPage) }
        menuRow("My commands", "Your own phrases and actions") { showPage(myCmdPage) }
        menuRow("Apps by voice", "Say \"open\" and an app's name") { showPage(appsPage) }
        menuRow("Calls & contacts", "Call, answer, end by voice") { showPage(callsPage) }
        menuRow("Appearance", "Theme and logo") { showPage(appearancePage) }
        menuRow("Assistant & permissions", "Service, microphone, special access") { showPage(assistantPage) }
        menuRow("About", "Version and welcome tour") { showPage(aboutPage) }

        val soon = ctx.card(16)
        soon.addView(ctx.label("Coming soon", 13f, pal.text2, 1))
        soon.addView(
            ctx.label(
                "Online AI  \u00B7  Voice choice  \u00B7  Only my voice  \u00B7  Default assistant",
                13f, pal.text2, 0
            ),
            ctx.lpd(t = 4)
        )
        body.addView(soon, ctx.lpd(t = 14))
    }

    private fun menuRow(name: String, desc: String, onClick: () -> Unit) {
        val ctx: Context = act
        val pal = Theme.c
        val row = ctx.hbox()
        row.background = ctx.pressable(pal.surface, 16f, pal.border, 1)
        row.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(10), ctx.dp(14))
        row.isClickable = true
        row.setOnClickListener { onClick() }
        val text = ctx.vbox()
        text.addView(ctx.label(name, 16f, pal.text, 1))
        text.addView(ctx.label(desc, 12f, pal.text2, 0), ctx.lpd(t = 2))
        row.addView(text, ctx.lpd(w = 0, weight = 1f))
        row.addView(GlyphView(ctx, G.CHEVRON, pal.text2), LinearLayout.LayoutParams(ctx.dp(24), ctx.dp(24)))
        body.addView(row, ctx.lpd(b = 8))
    }

    private fun subHeader(title: String, backTo: Int = menuPage) {
        val ctx: Context = act
        val pal = Theme.c
        val row = ctx.hbox()
        val back = GlyphView(ctx, G.CHEVRON, pal.text)
        back.rotation = 180f
        back.isClickable = true
        back.contentDescription = "Back"
        back.setOnClickListener { showPage(backTo) }
        row.addView(back, LinearLayout.LayoutParams(ctx.dp(40), ctx.dp(40)))
        row.addView(ctx.label(title, 22f, pal.text, 2), ctx.lpd(w = WRAP, l = 4))
        body.addView(row, ctx.lpd(b = 12))
    }

    // ------------------------------------------------------ appearance

    private fun buildAppearance() {
        val ctx: Context = act
        val pal = Theme.c
        subHeader("Appearance")
        val seg = ctx.hbox()
        seg.background = ctx.shape(pal.surface, 14f, pal.border, 1)
        seg.setPadding(ctx.dp(4), ctx.dp(4), ctx.dp(4), ctx.dp(4))
        val current = Theme.mode(ctx)
        val names = listOf("Dark", "Light", "System")
        for (i in names.indices) {
            val selected = i == current
            val b = ctx.label(names[i], 14f, if (selected) pal.onAccent else pal.text, if (selected) 2 else 1)
            b.gravity = Gravity.CENTER
            b.setPadding(0, ctx.dp(10), 0, ctx.dp(10))
            b.background = if (selected) ctx.pressable(pal.accent, 11f) else ctx.pressable(0x00000000, 11f)
            b.isClickable = true
            b.setOnClickListener {
                if (i != Theme.mode(ctx)) {
                    Theme.setMode(ctx, i)
                    act.recreate()
                }
            }
            seg.addView(b, ctx.lpd(w = 0, weight = 1f))
        }
        body.addView(seg, ctx.lpd())

        body.addView(ctx.label("Logo (inside the app)", 14f, pal.text, 2), ctx.lpd(t = 22, b = 10))
        val tiles = ctx.hbox()
        val names3 = listOf("Signal F", "Aperture", "Voice F")
        val chosen = AppPrefs.logo(ctx)
        for (i in names3.indices) {
            val box = ctx.vbox()
            box.gravity = Gravity.CENTER_HORIZONTAL
            box.setPadding(ctx.dp(8), ctx.dp(12), ctx.dp(8), ctx.dp(10))
            box.background = if (i == chosen) ctx.shape(withAlpha(pal.accent, 30), 16f, pal.accent, 2)
            else ctx.shape(pal.surface, 16f, pal.border, 1)
            box.isClickable = true
            val lv = LogoView(ctx, true)
            lv.style = i
            box.addView(lv, LinearLayout.LayoutParams(ctx.dp(64), ctx.dp(64)))
            box.addView(ctx.label(names3[i], 12f, if (i == chosen) pal.accent else pal.text, 1), ctx.lpd(w = WRAP, t = 8))
            box.setOnClickListener {
                if (i != AppPrefs.logo(ctx)) {
                    AppPrefs.setLogo(ctx, i)
                    act.recreate()
                }
            }
            tiles.addView(box, ctx.lpd(w = 0, l = if (i == 0) 0 else 4, r = if (i == 2) 0 else 4, weight = 1f))
        }
        body.addView(tiles, ctx.lpd())
        body.addView(
            ctx.label("The home-screen app icon stays the Signal F for now.", 12f, pal.text2, 0),
            ctx.lpd(t = 10)
        )
    }

    // ------------------------------------------------------ floating card

    private fun buildCard() {
        val ctx: Context = act
        val pal = Theme.c
        subHeader("Floating card")
        body.addView(
            ctx.label(
                "A small card appears over any app while FexAi listens and answers. " +
                    "It also lets \"open camera\" and \"open WhatsApp\" work straight from the background.",
                13f, pal.text2, 0
            ),
            ctx.lpd(b = 14)
        )

        val granted = android.provider.Settings.canDrawOverlays(ctx)
        val row = ctx.hbox()
        row.background = ctx.shape(pal.surface, 16f, pal.border, 1)
        row.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(12), ctx.dp(14))
        val text = ctx.vbox()
        val top = ctx.hbox()
        val dl = LinearLayout.LayoutParams(ctx.dp(8), ctx.dp(8))
        dl.rightMargin = ctx.dp(8)
        top.addView(ctx.dot(if (granted) pal.success else pal.warning), dl)
        top.addView(ctx.label("Display over other apps", 15f, pal.text, 1))
        text.addView(top)
        text.addView(ctx.label("Android permission this card needs.", 12f, pal.text2, 0), ctx.lpd(t = 3))
        row.addView(text, ctx.lpd(w = 0, weight = 1f))
        if (!granted) {
            val b = ctx.button("Allow", false) {
                open(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + ctx.packageName)
                    )
                )
            }
            b.setPadding(ctx.dp(14), ctx.dp(8), ctx.dp(14), ctx.dp(8))
            row.addView(b, ctx.lpd(w = WRAP, l = 8))
        } else {
            row.addView(ctx.tag("On", pal.success, withAlpha(pal.success, 36)), ctx.lpd(w = WRAP, l = 8))
        }
        body.addView(row, ctx.lpd())

        body.addView(ctx.label("Show the card", 14f, pal.text, 2), ctx.lpd(t = 22, b = 8))
        chipsRow(listOf("On", "Off"), if (AppPrefs.floatingCard(ctx)) 0 else 1) { i ->
            AppPrefs.setFloatingCard(ctx, i == 0)
        }
        body.addView(ctx.label("Hide the card in screenshots", 14f, pal.text, 2), ctx.lpd(t = 22, b = 4))
        body.addView(
            ctx.label("When you say \"take screen shot\", the card hides for a moment so it isn't in the picture.", 12f, pal.text2, 0),
            ctx.lpd(b = 8)
        )
        chipsRow(listOf("On", "Off"), if (AppPrefs.hideCardForShots(ctx)) 0 else 1) { i ->
            AppPrefs.setHideCardForShots(ctx, i == 0)
        }

        body.addView(ctx.label("Style", 14f, pal.text, 2), ctx.lpd(t = 22, b = 8))
        chipsRow(OverlayCard.STYLE_NAMES, AppPrefs.cardStyle(ctx)) { i ->
            AppPrefs.setCardStyle(ctx, i)
        }
        body.addView(ctx.label("Glow colours", 14f, pal.text, 2), ctx.lpd(t = 22, b = 8))
        chipsRow(OverlayCard.THEME_NAMES, AppPrefs.glowTheme(ctx)) { i ->
            AppPrefs.setGlowTheme(ctx, i)
        }
        body.addView(
            ctx.button("Preview", true) {
                if (!android.provider.Settings.canDrawOverlays(ctx)) {
                    Toast.makeText(ctx, "Allow \"Display over other apps\" first", Toast.LENGTH_SHORT).show()
                } else {
                    val pc = previewCard ?: OverlayCard(ctx.applicationContext).also { previewCard = it }
                    pc.preview()
                }
            },
            ctx.lpd(t = 22)
        )
        body.addView(
            ctx.label(
                "Tap the card to put it away. It doesn't show on the lock screen yet.",
                12f, pal.text2, 0
            ),
            ctx.lpd(t = 14)
        )
    }

    override fun onShow() {
        super.onShow()
        // coming back from the permission screen: redraw the card page so the status is fresh
        if ((page == cardPage || page == callsPage) && this::body.isInitialized) showPage(page)
    }

    // ---------------------------------------------------- voice & wake

    private fun buildVoice() {
        val ctx: Context = act
        val pal = Theme.c
        subHeader("Voice & wake word")

        // ---- wake word ----
        body.addView(ctx.label("Wake word", 14f, pal.text, 2), ctx.lpd(b = 4))
        val currentWake = AppPrefs.wakeWord(ctx)
        val status = ctx.label("Now: \"$currentWake\"", 13f, pal.text2, 0)
        body.addView(status, ctx.lpd(b = 8))

        val input = EditText(ctx)
        input.setText(currentWake)
        input.setSingleLine(true)
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        input.setTextColor(pal.text)
        input.setHintTextColor(pal.text2)
        input.hint = "one or two words"
        input.textSize = 16f
        input.setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
        input.background = ctx.shape(pal.surface, 14f, pal.border, 1)
        body.addView(input, ctx.lpd())

        val msg = ctx.label("", 12f, pal.text2, 0)
        val save = ctx.button("Save wake word", true) {
            val w = AppPrefs.clean(input.text.toString())
            if (w.isEmpty() || w.split(" ").size > 3) {
                msg.setTextColor(pal.error)
                msg.text = "Use one to three plain words."
            } else {
                val known = AppPrefs.inVocabulary(ctx, w)
                if (known == false) {
                    msg.setTextColor(pal.error)
                    msg.text = "\"$w\" is not in the offline speech model, so it can't be heard. Try a common English word."
                } else {
                    AppPrefs.setWakeWord(ctx, w)
                    status.text = "Now: \"$w\""
                    input.setText(w)
                    msg.setTextColor(pal.success)
                    msg.text = if (AssistantBus.serviceRunning) "Saved. Restarting the assistant..." else "Saved."
                    act.restartAssistant()
                }
            }
        }
        body.addView(save, ctx.lpd(t = 10))
        body.addView(msg, ctx.lpd(t = 8))
        body.addView(
            ctx.label(
                "Longer, distinctive words (2+ syllables) work best. Very short words trigger by mistake.",
                12f, pal.text2, 0
            ),
            ctx.lpd(t = 4)
        )

        // ---- spoken replies ----
        body.addView(ctx.label("Spoken replies", 14f, pal.text, 2), ctx.lpd(t = 24, b = 4))
        body.addView(
            ctx.label("Says \"Yes?\" when it wakes, and confirms what it did. Off means beep only.", 12f, pal.text2, 0),
            ctx.lpd(b = 8)
        )
        val voiceOn = AppPrefs.voiceReplies(ctx)
        chipsRow(listOf("On", "Off"), if (voiceOn) 0 else 1) { i ->
            AppPrefs.setVoiceReplies(ctx, i == 0)
            if (AssistantBus.serviceRunning) act.restartAssistant()
        }

        // ---- follow-up ----
        body.addView(ctx.label("Follow-up window", 14f, pal.text, 2), ctx.lpd(t = 24, b = 4))
        body.addView(
            ctx.label("After a command it keeps listening, so you don't repeat the wake word.", 12f, pal.text2, 0),
            ctx.lpd(b = 8)
        )
        val opts = listOf(0, 5, 8, 12)
        val cur = opts.indexOf(AppPrefs.followUpSec(ctx)).let { if (it < 0) 2 else it }
        chipsRow(listOf("Off", "5 s", "8 s", "12 s"), cur) { i ->
            AppPrefs.setFollowUpSec(ctx, opts[i])
            if (AssistantBus.serviceRunning) act.restartAssistant()
        }

        // ---- sensitivity ----
        body.addView(ctx.label("Microphone sensitivity", 14f, pal.text, 2), ctx.lpd(t = 24, b = 4))
        body.addView(
            ctx.label(
                "Raise it if FexAi can't hear you from across the room. Higher levels also pick up more noise, so it may trigger by mistake.",
                12f, pal.text2, 0
            ),
            ctx.lpd(b = 8)
        )
        chipsRow(listOf("Normal", "High", "Very high", "Max"), AppPrefs.sensitivity(ctx).coerceIn(0, 3)) { i ->
            AppPrefs.setSensitivity(ctx, i)
            if (AssistantBus.serviceRunning) act.restartAssistant()
        }

        // ---- other audio ----
        body.addView(ctx.label("Music and videos while listening", 14f, pal.text, 2), ctx.lpd(t = 24, b = 4))
        body.addView(
            ctx.label("Lower or pause what's playing so it can hear you, and you can hear it.", 12f, pal.text2, 0),
            ctx.lpd(b = 8)
        )
        chipsRow(listOf("Leave", "Lower", "Pause"), AppPrefs.duckMode(ctx).coerceIn(0, 2)) { i ->
            AppPrefs.setDuckMode(ctx, i)
            if (AssistantBus.serviceRunning) act.restartAssistant()
        }
    }

    // ------------------------------------------------------------ my commands

    private var fType = 0 // 0 app, 1 website, 2 call, 3 say, 4 advanced
    private var fPhrase = ""
    private var fA = ""
    private var fB = ""
    private var fC = ""
    private var fLabel = ""
    private var inPhrase: EditText? = null
    private var inA: EditText? = null
    private var inB: EditText? = null
    private var inC: EditText? = null
    private val tText = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS

    private fun resetForm() {
        fType = 0
        fPhrase = ""
        fA = ""
        fB = ""
        fC = ""
        fLabel = ""
    }

    private fun captureForm() {
        inPhrase?.let { fPhrase = it.text.toString() }
        inA?.let { fA = it.text.toString() }
        inB?.let { fB = it.text.toString() }
        inC?.let { fC = it.text.toString() }
    }

    private fun styledInput(hint: String, text: String, inputType: Int): EditText {
        val ctx: Context = act
        val pal = Theme.c
        val e = EditText(ctx)
        e.setText(text)
        e.hint = hint
        e.setSingleLine(true)
        e.inputType = inputType
        e.setTextColor(pal.text)
        e.setHintTextColor(pal.text2)
        e.textSize = 16f
        e.setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
        e.background = ctx.shape(pal.surface, 14f, pal.border, 1)
        return e
    }

    private fun buildMyCommands() {
        val ctx: Context = act
        val pal = Theme.c
        subHeader("My commands")
        body.addView(
            ctx.label(
                "Say a phrase and FexAi does what you choose: open an app or website, call someone, say something back, or run a custom Android action.",
                13f, pal.text2, 0
            ),
            ctx.lpd(b = 12)
        )
        body.addView(ctx.button("Add a command", true) {
            resetForm()
            showPage(addCmdPage)
        }, ctx.lpd())
        val list = CustomStore.all(ctx)
        if (list.isEmpty()) {
            body.addView(
                ctx.label("Nothing here yet. For example: \"my notes\" opens your notes app.", 13f, pal.text2, 0),
                ctx.lpd(t = 16)
            )
        }
        for (c in list) body.addView(myCmdRow(c), ctx.lpd(t = 8))
    }

    private fun myCmdRow(c: CustomCmd): View {
        val ctx: Context = act
        val pal = Theme.c
        val card = ctx.hbox()
        card.background = ctx.shape(pal.surface, 14f, pal.border, 1)
        card.setPadding(ctx.dp(14), ctx.dp(10), ctx.dp(6), ctx.dp(10))
        val text = ctx.vbox()
        text.addView(ctx.label("\"" + c.phrase + "\"", 15f, pal.text, 2))
        text.addView(ctx.label(c.summary(), 12f, pal.text2, 0), ctx.lpd(t = 1))
        card.addView(text, ctx.lpd(w = 0, weight = 1f))
        val del = GlyphView(ctx, G.TRASH, pal.text2)
        del.isClickable = true
        del.contentDescription = "Delete"
        del.setOnClickListener {
            AlertDialog.Builder(act)
                .setTitle("Delete \"" + c.phrase + "\"?")
                .setPositiveButton("Delete") { _, _ ->
                    CustomStore.remove(ctx, c.phrase)
                    showPage(myCmdPage)
                    act.restartAssistant()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        card.addView(del, LinearLayout.LayoutParams(ctx.dp(44), ctx.dp(44)))
        return card
    }

    private fun buildAddCmd() {
        val ctx: Context = act
        val pal = Theme.c
        inA = null
        inB = null
        inC = null
        subHeader("New command", myCmdPage)

        body.addView(ctx.label("When I say", 14f, pal.text, 2), ctx.lpd(b = 6))
        val ip = styledInput("e.g. my notes", fPhrase, tText)
        inPhrase = ip
        body.addView(ip, ctx.lpd())
        body.addView(
            ctx.label(
                "Use plain English words the offline model knows. FexAi checks this when you save.",
                12f, pal.text2, 0
            ),
            ctx.lpd(t = 6)
        )

        body.addView(ctx.label("It should", 14f, pal.text, 2), ctx.lpd(t = 20, b = 8))
        val names = listOf("Open app", "Website", "Call", "Say", "Advanced")
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        val row = ctx.hbox()
        val mine = ArrayList<TextView>()
        for (i in names.indices) {
            val chip = ctx.chipView(names[i])
            ctx.styleChip(chip, i == fType)
            chip.setOnClickListener {
                captureForm()
                if (i != fType) {
                    fType = i
                    fA = ""
                    fB = ""
                    fC = ""
                    fLabel = ""
                }
                showPage(addCmdPage)
            }
            mine.add(chip)
            row.addView(chip, ctx.lpd(w = WRAP, r = 8))
        }
        hs.addView(row)
        body.addView(hs, ctx.lpd())

        val gap = ctx.lpd(t = 14)
        when (fType) {
            0 -> {
                body.addView(
                    ctx.label(if (fLabel.isEmpty()) "No app chosen yet" else "App: $fLabel", 14f, pal.text, 1),
                    gap
                )
                body.addView(ctx.button("Choose app", false) {
                    captureForm()
                    val apps = AppIndex.list(ctx)
                    AlertDialog.Builder(act)
                        .setTitle("Choose an app")
                        .setItems(apps.map { it.label }.toTypedArray()) { _, which ->
                            fA = apps[which].pkg
                            fLabel = apps[which].label
                            showPage(addCmdPage)
                        }
                        .show()
                }, ctx.lpd(t = 8))
            }
            1 -> {
                val a = styledInput("https://example.com", fA, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
                inA = a
                body.addView(a, gap)
            }
            2 -> {
                if (fLabel.isNotEmpty()) body.addView(ctx.label("Contact: $fLabel", 14f, pal.text, 1), gap)
                val a = styledInput("Phone number", fA, InputType.TYPE_CLASS_PHONE)
                inA = a
                body.addView(a, ctx.lpd(t = 8))
                body.addView(ctx.button("Pick from contacts", false) {
                    captureForm()
                    act.pickContact()
                }, ctx.lpd(t = 8))
            }
            3 -> {
                val a = styledInput("What it should say", fA, tText)
                inA = a
                body.addView(a, gap)
            }
            else -> {
                val a = styledInput("Action, e.g. android.intent.action.VIEW", fA, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS)
                val b = styledInput("Data (optional), e.g. https://...", fB, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
                val c = styledInput("App package (optional)", fC, tText)
                inA = a
                inB = b
                inC = c
                body.addView(a, gap)
                body.addView(b, ctx.lpd(t = 8))
                body.addView(c, ctx.lpd(t = 8))
            }
        }

        val msg = ctx.label("", 12f, pal.error, 0)
        body.addView(ctx.button("Save command", true) { saveCommand(msg) }, ctx.lpd(t = 20))
        body.addView(msg, ctx.lpd(t = 8))
    }

    private fun saveCommand(msg: TextView) {
        captureForm()
        val ctx: Context = act
        val pal = Theme.c
        msg.setTextColor(pal.error)

        val phrase = AppPrefs.clean(fPhrase)
        if (phrase.isEmpty()) {
            msg.text = "Type what you will say."
            return
        }
        if (CommandRunner.PHRASES.containsKey(phrase)) {
            msg.text = "\"$phrase\" is already a built-in command."
            return
        }
        val missing = AppPrefs.missingWords(ctx, phrase)
        if (missing != null && missing.isNotEmpty()) {
            msg.text = "Not in the offline speech model: " + missing.joinToString(", ") +
                ". Try common English words."
            return
        }

        val result: Triple<String, String, String>? = when (fType) {
            0 -> if (fA.isEmpty()) null else Triple("app", fA, fLabel)
            1 -> if (fA.trim().isEmpty()) null else {
                val u = fA.trim()
                Triple("url", u, u.removePrefix("https://").removePrefix("http://").substringBefore('/'))
            }
            2 -> {
                val n = fA.filter { it.isDigit() || it == '+' }
                if (n.length < 3) null else Triple("call", n, fLabel)
            }
            3 -> if (fA.trim().isEmpty()) null else Triple("say", fA.trim(), "")
            else -> if (fA.trim().isEmpty()) null else Triple("intent", fA.trim() + "\n" + fB.trim() + "\n" + fC.trim(), "")
        }
        if (result == null) {
            msg.text = when (fType) {
                0 -> "Choose an app."
                1 -> "Type the website address."
                2 -> "Type a phone number or pick a contact."
                3 -> "Type what it should say."
                else -> "Type the Android action."
            }
            return
        }
        CustomStore.add(ctx, CustomCmd(phrase, result.first, result.second, result.third))
        Toast.makeText(ctx, "Saved", Toast.LENGTH_SHORT).show()
        resetForm()
        showPage(myCmdPage)
        act.restartAssistant()
    }

    /** Called by MainActivity after the contact picker closes. */
    fun onContactPicked(uri: Uri?) {
        if (uri == null) return
        val ctx: Context = act
        try {
            ctx.contentResolver.query(
                uri,
                arrayOf(
                    android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER,
                    android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                ),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    fA = c.getString(0) ?: ""
                    fLabel = c.getString(1) ?: ""
                }
            }
        } catch (e: Exception) {
        }
        fType = 2
        if (this::body.isInitialized) showPage(addCmdPage)
    }

    // ------------------------------------------------------------ apps by voice

    private fun buildApps() {
        val ctx: Context = act
        val pal = Theme.c
        subHeader("Apps by voice")
        body.addView(
            ctx.label(
                "Say \"open\" and an app's name, like \"open chrome\". The offline model only knows common words, " +
                    "so some app names can't be heard. For those, tap the app and give it a spoken name that sounds " +
                    "like it, for example WhatsApp as \"what's up\".",
                13f, pal.text2, 0
            ),
            ctx.lpd(b = 12)
        )
        chipsRow(listOf("On", "Off"), if (AppPrefs.appsByVoice(ctx)) 0 else 1) { i ->
            AppPrefs.setAppsByVoice(ctx, i == 0)
            act.restartAssistant()
        }

        val vocab = Vocab.get(ctx)
        if (vocab == null) {
            body.addView(
                ctx.label("Start the assistant once so the speech model downloads, then come back here.", 13f, pal.warning, 0),
                ctx.lpd(t = 14)
            )
        }
        val apps = AppIndex.list(ctx)
        val rows = apps.map { e ->
            val name = AppIndex.spokenName(ctx, e)
            Triple(e, name, vocab != null && DynamicCommands.ready(name, vocab))
        }.sortedByDescending { it.third }
        val readyCount = rows.count { it.third }
        body.addView(
            ctx.label("$readyCount of ${rows.size} apps can be opened by voice", 13f, pal.text, 1),
            ctx.lpd(t = 16, b = 8)
        )
        for (r in rows) {
            val card = ctx.hbox()
            card.background = ctx.pressable(pal.surface, 14f, pal.border, 1)
            card.setPadding(ctx.dp(14), ctx.dp(10), ctx.dp(12), ctx.dp(10))
            card.isClickable = true
            card.setOnClickListener { renameApp(r.first) }
            val text = ctx.vbox()
            text.addView(ctx.label(r.first.label, 15f, pal.text, 1))
            text.addView(
                ctx.label(if (r.third) "open ${r.second}" else "Can't be heard. Tap to set a spoken name.", 12f,
                    if (r.third) pal.text2 else pal.warning, 0),
                ctx.lpd(t = 1)
            )
            card.addView(text, ctx.lpd(w = 0, weight = 1f))
            card.addView(
                if (r.third) ctx.tag("Ready", pal.success, withAlpha(pal.success, 36))
                else ctx.tag("Rename", pal.text2, pal.elevated),
                ctx.lpd(w = WRAP, l = 8)
            )
            body.addView(card, ctx.lpd(b = 6))
        }
    }

    private fun renameApp(e: AppEntry) {
        val ctx: Context = act
        val input = styledInput("e.g. what's up", AppIndex.spokenName(ctx, e), tText)
        val wrap = FrameLayout(ctx)
        wrap.setPadding(ctx.dp(20), ctx.dp(8), ctx.dp(20), 0)
        wrap.addView(input, FrameLayout.LayoutParams(MATCH, WRAP))
        AlertDialog.Builder(act)
            .setTitle("Spoken name for " + e.label)
            .setMessage("You will say \"open ...\" and this name.")
            .setView(wrap)
            .setPositiveButton("Save") { _, _ ->
                val n = AppPrefs.clean(input.text.toString())
                val missing = if (n.isEmpty()) null else AppPrefs.missingWords(ctx, n)
                if (missing != null && missing.isNotEmpty()) {
                    Toast.makeText(ctx, "Not in the speech model: " + missing.joinToString(", "), Toast.LENGTH_LONG).show()
                } else {
                    AppIndex.setAlias(ctx, e.pkg, n)
                    showPage(appsPage)
                    act.restartAssistant()
                }
            }
            .setNeutralButton("Reset") { _, _ ->
                AppIndex.setAlias(ctx, e.pkg, "")
                showPage(appsPage)
                act.restartAssistant()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ------------------------------------------------------------ calls & contacts

    private fun buildCalls() {
        val ctx: Context = act
        val pal = Theme.c
        subHeader("Calls & contacts")
        body.addView(
            ctx.label("Start calls by voice, answer or decline an incoming call, and call people by name.", 13f, pal.text2, 0),
            ctx.lpd(b = 12)
        )
        val pb = ctx.vbox()
        permBox = pb
        body.addView(pb, ctx.lpd())

        fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
        permRow("Contacts", "Lets FexAi say \"call <name>\" for the people in your contacts.", has(Manifest.permission.READ_CONTACTS), "Allow") {
            act.askPerms(Manifest.permission.READ_CONTACTS)
        }
        permRow("Make calls", "Starts a call straight away. Without it, the dialer opens instead.", has(Manifest.permission.CALL_PHONE), "Allow") {
            act.askPerms(Manifest.permission.CALL_PHONE)
        }
        permRow("Answer & end calls", "For \"answer call\", \"pick up\", \"hang up\" and \"reject call\".", has(Manifest.permission.ANSWER_PHONE_CALLS), "Allow") {
            act.askPerms(Manifest.permission.ANSWER_PHONE_CALLS)
        }

        body.addView(ctx.label("Call contacts by name", 14f, pal.text, 2), ctx.lpd(t = 20, b = 4))
        body.addView(
            ctx.label("Adds \"call <name>\" for contacts whose names the offline model can hear.", 12f, pal.text2, 0),
            ctx.lpd(b = 8)
        )
        chipsRow(listOf("On", "Off"), if (AppPrefs.contactsByVoice(ctx)) 0 else 1) { i ->
            AppPrefs.setContactsByVoice(ctx, i == 0)
            act.restartAssistant()
            showPage(callsPage)
        }
        if (AppPrefs.contactsByVoice(ctx) && has(Manifest.permission.READ_CONTACTS)) {
            val n = try { ContactIndex.build(ctx).size } catch (e: Exception) { 0 }
            body.addView(
                ctx.label("$n contacts can be called by name", 13f, pal.text, 1),
                ctx.lpd(t = 12)
            )
        }

        val tip = ctx.card(16)
        tip.addView(ctx.label("Good to know", 14f, pal.text, 2))
        tip.addView(
            ctx.label(
                "The offline model knows common English names (John, Mary, David) but not most Nigerian names. " +
                    "For anyone else, make a nickname in My commands, choose Call, then pick the contact. " +
                    "Example: say \"boss\" to call Mr Ade.\n\n" +
                    "During a call, Android gives the microphone to the call, so \"hang up\" usually can't be heard " +
                    "once you are talking. \"Answer call\" and \"reject call\" work while the phone is ringing.",
                12f, pal.text2, 0
            ),
            ctx.lpd(t = 6)
        )
        body.addView(tip, ctx.lpd(t = 20))
    }

    /** A row of single-choice chips. */
    private fun chipsRow(names: List<String>, selected: Int, onPick: (Int) -> Unit) {
        val ctx: Context = act
        val row = ctx.hbox()
        val mine = ArrayList<TextView>()
        for (i in names.indices) {
            val chip = ctx.chipView(names[i])
            ctx.styleChip(chip, i == selected)
            chip.setOnClickListener {
                for (k in mine.indices) ctx.styleChip(mine[k], k == i)
                onPick(i)
            }
            mine.add(chip)
            row.addView(chip, ctx.lpd(w = WRAP, r = 8))
        }
        body.addView(row, ctx.lpd())
    }

    // ------------------------------------------------------- assistant

    private fun buildAssistant() {
        val ctx: Context = act
        val pal = Theme.c
        subHeader("Assistant & permissions")
        body.addView(ctx.label("Service", 14f, pal.text, 2), ctx.lpd(b = 10))
        val sb = ctx.vbox()
        serviceBtnBox = sb
        body.addView(sb, ctx.lpd())
        body.addView(ctx.label("Permissions", 14f, pal.text, 2), ctx.lpd(t = 22, b = 10))
        val pb = ctx.vbox()
        permBox = pb
        body.addView(pb, ctx.lpd())
        rebuildDynamic()
    }

    // ----------------------------------------------------------- about

    private fun buildAbout() {
        val ctx: Context = act
        val pal = Theme.c
        subHeader("About")
        val about = ctx.card(16)
        about.addView(ctx.label("FexAi Assistant", 16f, pal.text, 2))
        about.addView(ctx.label("Version " + versionName(), 13f, pal.text2, 0), ctx.lpd(t = 2))
        about.addView(
            ctx.label(
                "Offline speech recognition by Vosk (small English model). " +
                    "Your voice is processed on this phone.",
                13f, pal.text2, 0
            ),
            ctx.lpd(t = 8)
        )
        body.addView(about, ctx.lpd())
        body.addView(ctx.button("Replay welcome tour", false) { act.restartOnboarding() }, ctx.lpd(t = 12))
    }

    private fun versionName(): String = try {
        act.packageManager.getPackageInfo(act.packageName, 0).versionName ?: "?"
    } catch (e: Exception) {
        "?"
    }

    // ----------------------------------------------- permission helpers

    private fun permRow(name: String, why: String, granted: Boolean, action: String, onClick: () -> Unit) {
        val ctx: Context = act
        val pal = Theme.c
        val box = permBox ?: return
        val card = ctx.hbox()
        card.background = ctx.shape(pal.surface, 16f, pal.border, 1)
        card.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(12), ctx.dp(14))

        val text = ctx.vbox()
        val top = ctx.hbox()
        val dotLp = LinearLayout.LayoutParams(ctx.dp(8), ctx.dp(8))
        dotLp.rightMargin = ctx.dp(8)
        top.addView(ctx.dot(if (granted) pal.success else pal.warning), dotLp)
        top.addView(ctx.label(name, 15f, pal.text, 1))
        text.addView(top)
        text.addView(ctx.label(why, 12f, pal.text2, 0), ctx.lpd(t = 3))
        card.addView(text, ctx.lpd(w = 0, weight = 1f))

        if (!granted) {
            val b = ctx.button(action, false, onClick)
            b.setPadding(ctx.dp(14), ctx.dp(8), ctx.dp(14), ctx.dp(8))
            card.addView(b, ctx.lpd(w = WRAP, l = 8))
        } else {
            card.addView(ctx.tag("On", pal.success, withAlpha(pal.success, 36)), ctx.lpd(w = WRAP, l = 8))
        }
        box.addView(card, ctx.lpd(b = 8))
    }

    private fun open(intent: Intent) {
        try {
            act.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(act, "Open Android Settings > Apps > FexAi Assistant", Toast.LENGTH_LONG).show()
        }
    }

    // Statuses are re-read every time the tab shows or the bus changes.
    override fun refresh() {
        if (page == assistantPage && permBox != null) rebuildDynamic()
    }

    private fun rebuildServiceButtons() {
        val ctx: Context = act
        val box = serviceBtnBox ?: return
        box.removeAllViews()
        val b = if (AssistantBus.serviceRunning) {
            ctx.button("Stop assistant", false) { act.stopListening() }
        } else {
            ctx.button("Start assistant", true) { act.startListening() }
        }
        box.addView(b, ctx.lpd())
    }

    private fun rebuildDynamic() {
        val ctx: Context = act
        val box = permBox ?: return
        rebuildServiceButtons()
        box.removeAllViews()

        val mic = ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        permRow("Microphone", "Needed to hear the wake word.", mic, "Allow") { act.requestBasics() }

        if (Build.VERSION.SDK_INT >= 33) {
            val notif = ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            permRow("Notifications", "Keeps the listening service visible and running.", notif, "Allow") { act.requestBasics() }
        }

        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val battery = pm.isIgnoringBatteryOptimizations(ctx.packageName)
        permRow("Run in background", "Set battery to unrestricted so Android doesn't stop it.", battery, "Open") {
            open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }

        permRow("Accessibility (optional)", "Back, home, recents, screenshot, lock screen by voice.", Access.accessibilityOn(ctx), "Open") {
            open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        permRow("Notification access (optional)", "Only used for \"clear notifications\".", Access.notificationsOn(ctx), "Open") {
            open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        if (Build.VERSION.SDK_INT >= 34) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            val full = nm.canUseFullScreenIntent()
            permRow("Full-screen prompts (optional)", "Helps \"open camera\" and \"open WhatsApp\" appear from the background.", full, "Allow") {
                open(
                    Intent(
                        Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                        Uri.parse("package:" + ctx.packageName)
                    )
                )
            }
        }
        // Help for the "greyed out" switch on sideloaded apps (Android 13+)
        val tip = ctx.card(16)
        val pal2 = Theme.c
        tip.addView(ctx.label("Switch greyed out or blocked?", 14f, pal2.text, 2))
        tip.addView(
            ctx.label(
                "Android blocks Accessibility and Notification access for apps installed outside the Play Store. " +
                    "Tap the button, then the three dots at the top right, then \"Allow restricted settings\". " +
                    "Come back here and turn the switch on.",
                12f, pal2.text2, 0
            ),
            ctx.lpd(t = 6)
        )
        tip.addView(
            ctx.button("Open app info", false) {
                open(
                    Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + ctx.packageName)
                    )
                )
            },
            ctx.lpd(t = 12)
        )
        box.addView(tip, ctx.lpd(t = 4))
    }
}
