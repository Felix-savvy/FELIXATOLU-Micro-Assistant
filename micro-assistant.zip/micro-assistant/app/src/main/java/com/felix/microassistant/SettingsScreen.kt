package com.felix.microassistant

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class SettingsScreen(act: MainActivity) : Screen(act) {

    private lateinit var permBox: LinearLayout
    private lateinit var serviceBtnBox: LinearLayout

    override val view: View by lazy { build() }

    private fun build(): View {
        val ctx: Context = act
        val pal = Theme.c

        val col = ctx.vbox()
        col.setPadding(ctx.dp(20), ctx.dp(20), ctx.dp(20), ctx.dp(24))
        col.addView(ctx.label("Settings", 26f, pal.text, 2), ctx.lpd(b = 4))

        // ---- Appearance ----
        heading(col, "Appearance")
        val seg = ctx.hbox()
        seg.background = ctx.shape(pal.surface, 14f, pal.border, 1)
        seg.setPadding(ctx.dp(4), ctx.dp(4), ctx.dp(4), ctx.dp(4))
        val current = Theme.mode(ctx)
        val names = listOf("Dark", "Light", "System")
        for (i in names.indices) {
            val selected = i == current
            val b = ctx.label(names[i], 14f, if (selected) pal.onAccent else pal.text, if (selected) 2 else 1)
            b.gravity = Gravity.CENTER
            b.setPadding(0, ctx.dp(10), 0, ctx.dp(10))
            b.background = if (selected) ctx.pressable(pal.accent, 11f) else ctx.pressable(0x00000000, 11f)
            b.isClickable = true
            b.setOnClickListener {
                if (i != Theme.mode(ctx)) {
                    Theme.setMode(ctx, i)
                    act.recreate()
                }
            }
            seg.addView(b, ctx.lpd(w = 0, weight = 1f))
        }
        col.addView(seg, ctx.lpd())

        // ---- Service ----
        heading(col, "Assistant service")
        serviceBtnBox = ctx.vbox()
        col.addView(serviceBtnBox, ctx.lpd())

        // ---- Permissions ----
        heading(col, "Permissions")
        permBox = ctx.vbox()
        col.addView(permBox, ctx.lpd())

        // ---- Coming soon ----
        heading(col, "Coming soon")
        soon(col, "Wake & listening", "Custom wake word, sensitivity, follow-up window.")
        soon(col, "Voice", "Spoken replies, voice choice, speed.")
        soon(col, "Floating card", "Pop-up assistant over other apps.")
        soon(col, "Online brain", "AI answers when you are online. Off by default.")

        // ---- About ----
        heading(col, "About")
        val about = ctx.card(16)
        about.addView(ctx.label("FexAi Assistant", 16f, pal.text, 2))
        about.addView(ctx.label("Version " + versionName(), 13f, pal.text2, 0), ctx.lpd(t = 2))
        about.addView(
            ctx.label(
                "Offline speech recognition by Vosk (small English model). " +
                    "Your voice is processed on this phone.",
                13f, pal.text2, 0
            ),
            ctx.lpd(t = 8)
        )
        col.addView(about, ctx.lpd())
        val replay = ctx.button("Replay welcome tour", false) { act.restartOnboarding() }
        col.addView(replay, ctx.lpd(t = 12))

        val scroll = ScrollView(ctx)
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(col)
        return scroll
    }

    private fun versionName(): String = try {
        act.packageManager.getPackageInfo(act.packageName, 0).versionName ?: "?"
    } catch (e: Exception) {
        "?"
    }

    private fun heading(col: LinearLayout, text: String) {
        val ctx: Context = act
        col.addView(ctx.label(text, 14f, Theme.c.text, 2), ctx.lpd(t = 24, b = 10))
    }

    private fun soon(col: LinearLayout, name: String, desc: String) {
        val ctx: Context = act
        val pal = Theme.c
        val card = ctx.hbox()
        card.background = ctx.shape(pal.surface, 16f, pal.border, 1)
        card.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(16), ctx.dp(14))
        card.alpha = 0.75f
        val text = ctx.vbox()
        text.addView(ctx.label(name, 15f, pal.text, 1))
        text.addView(ctx.label(desc, 12f, pal.text2, 0), ctx.lpd(t = 2))
        card.addView(text, ctx.lpd(w = 0, weight = 1f))
        card.addView(ctx.tag("Soon", pal.text2, pal.elevated), ctx.lpd(w = WRAP))
        col.addView(card, ctx.lpd(b = 8))
    }

    /** One permission row: name, why, status dot and an action button when not granted. */
    private fun permRow(name: String, why: String, granted: Boolean, action: String, onClick: () -> Unit) {
        val ctx: Context = act
        val pal = Theme.c
        val card = ctx.hbox()
        card.background = ctx.shape(pal.surface, 16f, pal.border, 1)
        card.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(12), ctx.dp(14))

        val text = ctx.vbox()
        val top = ctx.hbox()
        val dotLp = LinearLayout.LayoutParams(ctx.dp(8), ctx.dp(8))
        dotLp.rightMargin = ctx.dp(8)
        top.addView(ctx.dot(if (granted) pal.success else pal.warning), dotLp)
        top.addView(ctx.label(name, 15f, pal.text, 1))
        text.addView(top)
        text.addView(ctx.label(why, 12f, pal.text2, 0), ctx.lpd(t = 3))
        card.addView(text, ctx.lpd(w = 0, weight = 1f))

        if (!granted) {
            val b = ctx.button(action, false, onClick)
            b.setPadding(ctx.dp(14), ctx.dp(8), ctx.dp(14), ctx.dp(8))
            card.addView(b, ctx.lpd(w = WRAP, l = 8))
        } else {
            card.addView(ctx.tag("On", pal.success, withAlpha(pal.success, 36)), ctx.lpd(w = WRAP, l = 8))
        }
        permBox.addView(card, ctx.lpd(b = 8))
    }

    private fun open(intent: Intent) {
        try {
            act.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(act, "Open Android Settings > Apps > FexAi Assistant", Toast.LENGTH_LONG).show()
        }
    }

    // Rebuilt every time the tab is shown, so statuses are fresh after returning from system settings.
    override fun onShow() {
        super.onShow()
        rebuildDynamic()
    }

    override fun refresh() {
        // Bus updates only matter for the service buttons.
        if (this::serviceBtnBox.isInitialized) rebuildServiceButtons()
    }

    private fun rebuildServiceButtons() {
        val ctx: Context = act
        serviceBtnBox.removeAllViews()
        val running = AssistantBus.serviceRunning
        val b = if (running) {
            ctx.button("Stop assistant", false) { act.stopListening() }
        } else {
            ctx.button("Start assistant", true) { act.startListening() }
        }
        serviceBtnBox.addView(b, ctx.lpd())
    }

    private fun rebuildDynamic() {
        val ctx: Context = act
        rebuildServiceButtons()
        permBox.removeAllViews()

        val mic = ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        permRow("Microphone", "Needed to hear the wake word.", mic, "Allow") { act.requestBasics() }

        if (Build.VERSION.SDK_INT >= 33) {
            val notif = ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            permRow("Notifications", "Keeps the listening service visible and running.", notif, "Allow") { act.requestBasics() }
        }

        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val battery = pm.isIgnoringBatteryOptimizations(ctx.packageName)
        permRow("Run in background", "Set battery to unrestricted so Android doesn't stop it.", battery, "Open") {
            open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }

        if (Build.VERSION.SDK_INT >= 34) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            val full = nm.canUseFullScreenIntent()
            permRow("Full-screen prompts", "Helps \"open camera\" and \"open WhatsApp\" appear from the background.", full, "Allow") {
                open(
                    Intent(
                        Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                        Uri.parse("package:" + ctx.packageName)
                    )
                )
            }
        }
    }
}
