package com.felix.microassistant

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

class SettingsScreen(act: MainActivity) : Screen(act) {

    private val menuPage = 0
    private val appearancePage = 1
    private val assistantPage = 2
    private val aboutPage = 3

    private var page = menuPage
    private lateinit var scroll: ScrollView
    private lateinit var body: LinearLayout
    private var permBox: LinearLayout? = null
    private var serviceBtnBox: LinearLayout? = null

    override val view: View by lazy { build() }

    private fun build(): View {
        val ctx: Context = act
        body = ctx.vbox()
        body.setPadding(ctx.dp(20), ctx.dp(20), ctx.dp(20), ctx.dp(24))
        scroll = ScrollView(ctx)
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(body)
        showPage(menuPage)
        return scroll
    }

    /** Called by MainActivity on Back. Returns true if it handled it. */
    fun handleBack(): Boolean {
        if (page != menuPage) {
            showPage(menuPage)
            return true
        }
        return false
    }

    private fun showPage(p: Int) {
        page = p
        permBox = null
        serviceBtnBox = null
        body.removeAllViews()
        when (p) {
            appearancePage -> buildAppearance()
            assistantPage -> buildAssistant()
            aboutPage -> buildAbout()
            else -> buildMenu()
        }
        scroll.scrollTo(0, 0)
    }

    // ------------------------------------------------------------ menu

    private fun buildMenu() {
        val ctx: Context = act
        val pal = Theme.c
        body.addView(ctx.label("Settings", 26f, pal.text, 2), ctx.lpd(b = 14))
        menuRow("Appearance", "Dark, light or follow system") { showPage(appearancePage) }
        menuRow("Assistant & permissions", "Service, microphone, background") { showPage(assistantPage) }
        menuRow("About", "Version and welcome tour") { showPage(aboutPage) }

        val soon = ctx.card(16)
        soon.addView(ctx.label("Coming soon", 13f, pal.text2, 1))
        soon.addView(
            ctx.label(
                "Custom wake word  ·  Voice replies  ·  Floating card  ·  Online AI  ·  My commands",
                13f, pal.text2, 0
            ),
            ctx.lpd(t = 4)
        )
        body.addView(soon, ctx.lpd(t = 14))
    }

    private fun menuRow(name: String, desc: String, onClick: () -> Unit) {
        val ctx: Context = act
        val pal = Theme.c
        val row = ctx.hbox()
        row.background = ctx.pressable(pal.surface, 16f, pal.border, 1)
        row.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(10), ctx.dp(14))
        row.isClickable = true
        row.setOnClickListener { onClick() }
        val text = ctx.vbox()
        text.addView(ctx.label(name, 16f, pal.text, 1))
        text.addView(ctx.label(desc, 12f, pal.text2, 0), ctx.lpd(t = 2))
        row.addView(text, ctx.lpd(w = 0, weight = 1f))
        row.addView(GlyphView(ctx, G.CHEVRON, pal.text2), LinearLayout.LayoutParams(ctx.dp(24), ctx.dp(24)))
        body.addView(row, ctx.lpd(b = 8))
    }

    private fun subHeader(title: String) {
        val ctx: Context = act
        val pal = Theme.c
        val row = ctx.hbox()
        val back = GlyphView(ctx, G.CHEVRON, pal.text)
        back.rotation = 180f
        back.isClickable = true
        back.contentDescription = "Back"
        back.setOnClickListener { showPage(menuPage) }
        row.addView(back, LinearLayout.LayoutParams(ctx.dp(40), ctx.dp(40)))
        row.addView(ctx.label(title, 22f, pal.text, 2), ctx.lpd(w = WRAP, l = 4))
        body.addView(row, ctx.lpd(b = 12))
    }

    // ------------------------------------------------------ appearance

    private fun buildAppearance() {
        val ctx: Context = act
        val pal = Theme.c
        subHeader("Appearance")
        val seg = ctx.hbox()
        seg.background = ctx.shape(pal.surface, 14f, pal.border, 1)
        seg.setPadding(ctx.dp(4), ctx.dp(4), ctx.dp(4), ctx.dp(4))
        val current = Theme.mode(ctx)
        val names = listOf("Dark", "Light", "System")
        for (i in names.indices) {
            val selected = i == current
            val b = ctx.label(names[i], 14f, if (selected) pal.onAccent else pal.text, if (selected) 2 else 1)
            b.gravity = Gravity.CENTER
            b.setPadding(0, ctx.dp(10), 0, ctx.dp(10))
            b.background = if (selected) ctx.pressable(pal.accent, 11f) else ctx.pressable(0x00000000, 11f)
            b.isClickable = true
            b.setOnClickListener {
                if (i != Theme.mode(ctx)) {
                    Theme.setMode(ctx, i)
                    act.recreate()
                }
            }
            seg.addView(b, ctx.lpd(w = 0, weight = 1f))
        }
        body.addView(seg, ctx.lpd())
    }

    // ------------------------------------------------------- assistant

    private fun buildAssistant() {
        val ctx: Context = act
        val pal = Theme.c
        subHeader("Assistant & permissions")
        body.addView(ctx.label("Service", 14f, pal.text, 2), ctx.lpd(b = 10))
        val sb = ctx.vbox()
        serviceBtnBox = sb
        body.addView(sb, ctx.lpd())
        body.addView(ctx.label("Permissions", 14f, pal.text, 2), ctx.lpd(t = 22, b = 10))
        val pb = ctx.vbox()
        permBox = pb
        body.addView(pb, ctx.lpd())
        rebuildDynamic()
    }

    // ----------------------------------------------------------- about

    private fun buildAbout() {
        val ctx: Context = act
        val pal = Theme.c
        subHeader("About")
        val about = ctx.card(16)
        about.addView(ctx.label("FexAi Assistant", 16f, pal.text, 2))
        about.addView(ctx.label("Version " + versionName(), 13f, pal.text2, 0), ctx.lpd(t = 2))
        about.addView(
            ctx.label(
                "Offline speech recognition by Vosk (small English model). " +
                    "Your voice is processed on this phone.",
                13f, pal.text2, 0
            ),
            ctx.lpd(t = 8)
        )
        body.addView(about, ctx.lpd())
        body.addView(ctx.button("Replay welcome tour", false) { act.restartOnboarding() }, ctx.lpd(t = 12))
    }

    private fun versionName(): String = try {
        act.packageManager.getPackageInfo(act.packageName, 0).versionName ?: "?"
    } catch (e: Exception) {
        "?"
    }

    // ----------------------------------------------- permission helpers

    private fun permRow(name: String, why: String, granted: Boolean, action: String, onClick: () -> Unit) {
        val ctx: Context = act
        val pal = Theme.c
        val box = permBox ?: return
        val card = ctx.hbox()
        card.background = ctx.shape(pal.surface, 16f, pal.border, 1)
        card.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(12), ctx.dp(14))

        val text = ctx.vbox()
        val top = ctx.hbox()
        val dotLp = LinearLayout.LayoutParams(ctx.dp(8), ctx.dp(8))
        dotLp.rightMargin = ctx.dp(8)
        top.addView(ctx.dot(if (granted) pal.success else pal.warning), dotLp)
        top.addView(ctx.label(name, 15f, pal.text, 1))
        text.addView(top)
        text.addView(ctx.label(why, 12f, pal.text2, 0), ctx.lpd(t = 3))
        card.addView(text, ctx.lpd(w = 0, weight = 1f))

        if (!granted) {
            val b = ctx.button(action, false, onClick)
            b.setPadding(ctx.dp(14), ctx.dp(8), ctx.dp(14), ctx.dp(8))
            card.addView(b, ctx.lpd(w = WRAP, l = 8))
        } else {
            card.addView(ctx.tag("On", pal.success, withAlpha(pal.success, 36)), ctx.lpd(w = WRAP, l = 8))
        }
        box.addView(card, ctx.lpd(b = 8))
    }

    private fun open(intent: Intent) {
        try {
            act.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(act, "Open Android Settings > Apps > FexAi Assistant", Toast.LENGTH_LONG).show()
        }
    }

    // Statuses are re-read every time the tab shows or the bus changes.
    override fun refresh() {
        if (page == assistantPage && permBox != null) rebuildDynamic()
    }

    private fun rebuildServiceButtons() {
        val ctx: Context = act
        val box = serviceBtnBox ?: return
        box.removeAllViews()
        val b = if (AssistantBus.serviceRunning) {
            ctx.button("Stop assistant", false) { act.stopListening() }
        } else {
            ctx.button("Start assistant", true) { act.startListening() }
        }
        box.addView(b, ctx.lpd())
    }

    private fun rebuildDynamic() {
        val ctx: Context = act
        val box = permBox ?: return
        rebuildServiceButtons()
        box.removeAllViews()

        val mic = ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        permRow("Microphone", "Needed to hear the wake word.", mic, "Allow") { act.requestBasics() }

        if (Build.VERSION.SDK_INT >= 33) {
            val notif = ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            permRow("Notifications", "Keeps the listening service visible and running.", notif, "Allow") { act.requestBasics() }
        }

        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val battery = pm.isIgnoringBatteryOptimizations(ctx.packageName)
        permRow("Run in background", "Set battery to unrestricted so Android doesn't stop it.", battery, "Open") {
            open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }

        if (Build.VERSION.SDK_INT >= 34) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            val full = nm.canUseFullScreenIntent()
            permRow("Full-screen prompts (optional)", "Helps \"open camera\" and \"open WhatsApp\" appear from the background.", full, "Allow") {
                open(
                    Intent(
                        Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                        Uri.parse("package:" + ctx.packageName)
                    )
                )
            }
        }
    }
}
