package com.felix.microassistant

import android.content.Context
import java.io.File

/** Small user settings, kept in the same SharedPreferences file as everything else. */
object AppPrefs {
    const val DEFAULT_WAKE = "computer"

    private fun p(ctx: Context) =
        ctx.getSharedPreferences(WakeWordService.PREFS, Context.MODE_PRIVATE)

    fun wakeWord(ctx: Context): String =
        p(ctx).getString("wake_word", DEFAULT_WAKE)?.takeIf { it.isNotBlank() } ?: DEFAULT_WAKE

    fun setWakeWord(ctx: Context, w: String) {
        p(ctx).edit().putString("wake_word", w).apply()
    }

    fun voiceReplies(ctx: Context): Boolean = p(ctx).getBoolean("voice_replies", true)
    fun setVoiceReplies(ctx: Context, on: Boolean) {
        p(ctx).edit().putBoolean("voice_replies", on).apply()
    }

    /** Seconds the assistant keeps listening after a command, without the wake word. 0 = off. */
    fun followUpSec(ctx: Context): Int = p(ctx).getInt("followup_sec", 8)
    fun setFollowUpSec(ctx: Context, s: Int) {
        p(ctx).edit().putInt("followup_sec", s).apply()
    }

    fun floatingCard(ctx: Context): Boolean = p(ctx).getBoolean("floating_card", true)
    fun setFloatingCard(ctx: Context, on: Boolean) {
        p(ctx).edit().putBoolean("floating_card", on).apply()
    }

    /** 0 = Signal F, 1 = Aperture, 2 = Voice F (in-app logo only). */
    fun logo(ctx: Context): Int = p(ctx).getInt("logo_style", 0)
    fun setLogo(ctx: Context, s: Int) {
        p(ctx).edit().putInt("logo_style", s).apply()
    }

    /** Lower-case, letters / apostrophes / single spaces only. Empty if nothing usable. */
    fun clean(raw: String): String =
        raw.lowercase().replace(Regex("[^a-z' ]"), " ").trim().replace(Regex("\\s+"), " ")

    /**
     * Does the speech model know every word? true / false, or null if the model
     * is not downloaded yet (so we can't tell).
     */
    fun inVocabulary(ctx: Context, phrase: String): Boolean? {
        val words = File(ctx.filesDir, "vosk-model-small-en-us-0.15/graph/words.txt")
        if (!words.exists()) return null
        val need = phrase.split(" ").filter { it.isNotEmpty() }.toMutableSet()
        try {
            words.bufferedReader().useLines { lines ->
                for (line in lines) {
                    val w = line.substringBefore(' ')
                    if (need.remove(w) && need.isEmpty()) return true
                }
            }
        } catch (e: Exception) {
            return null
        }
        return need.isEmpty()
    }
}
