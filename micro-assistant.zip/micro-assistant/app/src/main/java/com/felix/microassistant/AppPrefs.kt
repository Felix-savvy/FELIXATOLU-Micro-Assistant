package com.felix.microassistant

import android.content.Context
import java.io.File

/** Small user settings, kept in the same SharedPreferences file as everything else. */
object AppPrefs {
    const val DEFAULT_WAKE = "computer"

    private fun p(ctx: Context) =
        ctx.getSharedPreferences(WakeWordService.PREFS, Context.MODE_PRIVATE)

    fun wakeWord(ctx: Context): String =
        p(ctx).getString("wake_word", DEFAULT_WAKE)?.takeIf { it.isNotBlank() } ?: DEFAULT_WAKE

    fun setWakeWord(ctx: Context, w: String) {
        p(ctx).edit().putString("wake_word", w).apply()
    }

    fun voiceReplies(ctx: Context): Boolean = p(ctx).getBoolean("voice_replies", true)
    fun setVoiceReplies(ctx: Context, on: Boolean) {
        p(ctx).edit().putBoolean("voice_replies", on).apply()
    }

    /** Seconds the assistant keeps listening after a command, without the wake word. 0 = off. */
    fun followUpSec(ctx: Context): Int = p(ctx).getInt("followup_sec", 8)
    fun setFollowUpSec(ctx: Context, s: Int) {
        p(ctx).edit().putInt("followup_sec", s).apply()
    }

    fun floatingCard(ctx: Context): Boolean = p(ctx).getBoolean("floating_card", true)
    fun setFloatingCard(ctx: Context, on: Boolean) {
        p(ctx).edit().putBoolean("floating_card", on).apply()
    }

    /** Microphone sensitivity: 0 Normal, 1 High, 2 Very high, 3 Max. */
    fun sensitivity(ctx: Context): Int = p(ctx).getInt("sensitivity", 1)
    fun setSensitivity(ctx: Context, v: Int) {
        p(ctx).edit().putInt("sensitivity", v).apply()
    }

    /** What to do with other audio while listening: 0 nothing, 1 lower it, 2 pause it. */
    fun duckMode(ctx: Context): Int = p(ctx).getInt("duck_mode", 1)
    fun setDuckMode(ctx: Context, v: Int) {
        p(ctx).edit().putInt("duck_mode", v).apply()
    }

    fun hideCardForShots(ctx: Context): Boolean = p(ctx).getBoolean("hide_card_shots", true)
    fun setHideCardForShots(ctx: Context, on: Boolean) {
        p(ctx).edit().putBoolean("hide_card_shots", on).apply()
    }

    /** 0 Glow + pill, 1 Pill, 2 Panel, 3 Glow only */
    fun cardStyle(ctx: Context): Int = p(ctx).getInt("card_style", 0)
    fun setCardStyle(ctx: Context, v: Int) {
        p(ctx).edit().putInt("card_style", v).apply()
    }

    /** 0 Aurora, 1 Lime, 2 Ocean */
    fun glowTheme(ctx: Context): Int = p(ctx).getInt("glow_theme", 0)
    fun setGlowTheme(ctx: Context, v: Int) {
        p(ctx).edit().putInt("glow_theme", v).apply()
    }

    /** 0 = Signal F, 1 = Aperture, 2 = Voice F (in-app logo only). */
    fun logo(ctx: Context): Int = p(ctx).getInt("logo_style", 0)
    fun setLogo(ctx: Context, s: Int) {
        p(ctx).edit().putInt("logo_style", s).apply()
    }

    /** Lower-case, letters / apostrophes / single spaces only. Empty if nothing usable. */
    fun clean(raw: String): String =
        raw.lowercase().replace(Regex("[^a-z' ]"), " ").trim().replace(Regex("\\s+"), " ")

    fun appsByVoice(ctx: Context): Boolean = p(ctx).getBoolean("apps_by_voice", true)
    fun setAppsByVoice(ctx: Context, on: Boolean) {
        p(ctx).edit().putBoolean("apps_by_voice", on).apply()
    }

    fun contactsByVoice(ctx: Context): Boolean = p(ctx).getBoolean("contacts_by_voice", false)
    fun setContactsByVoice(ctx: Context, on: Boolean) {
        p(ctx).edit().putBoolean("contacts_by_voice", on).apply()
    }

    /** Words from the phrase that the offline model doesn't know, or null if we can't tell yet. */
    fun missingWords(ctx: Context, phrase: String): List<String>? {
        val v = Vocab.get(ctx) ?: return null
        return phrase.split(" ").filter { it.isNotEmpty() && it !in v }
    }

    /** true / false, or null if the speech model is not downloaded yet. */
    fun inVocabulary(ctx: Context, phrase: String): Boolean? = missingWords(ctx, phrase)?.isEmpty()
}

/** The list of words the offline speech model can hear. Loaded once, then kept in memory. */
object Vocab {
    @Volatile private var cache: HashSet<String>? = null

    fun get(ctx: Context): Set<String>? {
        cache?.let { return it }
        val file = File(ctx.filesDir, "vosk-model-small-en-us-0.15/graph/words.txt")
        if (!file.exists()) return null
        return try {
            val set = HashSet<String>(100_000)
            file.bufferedReader().useLines { lines ->
                for (line in lines) set.add(line.substringBefore(' '))
            }
            cache = set
            set
        } catch (e: Exception) {
            null
        }
    }
}
